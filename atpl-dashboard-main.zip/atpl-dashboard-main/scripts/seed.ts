/**
 * Seed script — populates Supabase with sample data matching the prototype.
 * Run: npm run seed
 * Requires .env.local to be configured first.
 */
import { createClient } from '@supabase/supabase-js';
import bcrypt from 'bcryptjs';
import * as dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

const db = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const today = new Date();
const d = (offset: number) => {
  const dt = new Date(today);
  dt.setDate(dt.getDate() + offset);
  return dt.toISOString().split('T')[0];
};

// ── Employees ────────────────────────────────────────────────
const EMPLOYEES = [
  { id:'EMP001', full_name:'Vinayak Agarwal',   username:'vinayak',     role:'Super Master', departments:['GST','Income Tax','Audit','TDS','Company Law','NGO','Accounts'], avatar:'VA', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2020-01-01' },
  { id:'EMP002', full_name:'Priya Sharma',       username:'priya.gst',   role:'Admin',        departments:['GST'], avatar:'PS', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2021-03-15' },
  { id:'EMP003', full_name:'Rakesh Mehta',       username:'rakesh.it',   role:'Admin',        departments:['Income Tax'], avatar:'RM', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2021-05-01' },
  { id:'EMP004', full_name:'Sunita Joshi',       username:'sunita.audit',role:'Admin',        departments:['Audit'], avatar:'SJ', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2021-07-10' },
  { id:'EMP005', full_name:'Arjun Kapoor',       username:'arjun.lead',  role:'Team Lead',    departments:['GST'], avatar:'AK', is_team_lead:true, team_lead_scope:['EMP007','EMP008','EMP009'], status:'Active', date_of_joining:'2022-01-20', reporting_to:'EMP002' },
  { id:'EMP006', full_name:'Deepa Nair',         username:'deepa.lead',  role:'Team Lead',    departments:['Income Tax'], avatar:'DN', is_team_lead:true, team_lead_scope:['EMP010','EMP011'], status:'Active', date_of_joining:'2022-03-01', reporting_to:'EMP003' },
  { id:'EMP007', full_name:'Rahul Verma',        username:'rahul.gst',   role:'Employee',     departments:['GST'], avatar:'RV', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2022-06-01', reporting_to:'EMP005' },
  { id:'EMP008', full_name:'Kavya Reddy',        username:'kavya.gst',   role:'Employee',     departments:['GST'], avatar:'KR', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2022-08-15', reporting_to:'EMP005' },
  { id:'EMP009', full_name:'Manish Gupta',       username:'manish.gst',  role:'Employee',     departments:['GST'], avatar:'MG', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2023-01-10', reporting_to:'EMP005' },
  { id:'EMP010', full_name:'Neha Singh',         username:'neha.it',     role:'Employee',     departments:['Income Tax'], avatar:'NS', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2023-02-01', reporting_to:'EMP006' },
  { id:'EMP011', full_name:'Tarun Bose',         username:'tarun.it',    role:'Employee',     departments:['Income Tax'], avatar:'TB', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2023-04-01', reporting_to:'EMP006' },
  { id:'EMP012', full_name:'Pooja Iyer',         username:'pooja.audit', role:'Employee',     departments:['Audit'], avatar:'PI', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2023-06-01', reporting_to:'EMP004' },
  { id:'EMP013', full_name:'Sameer Khan',        username:'sameer.tds',  role:'Employee',     departments:['TDS'], avatar:'SK', is_team_lead:false, team_lead_scope:[], status:'Active', date_of_joining:'2023-07-15' },
];

// ── Login Registry ────────────────────────────────────────────
async function buildLoginRegistry() {
  const hash = await bcrypt.hash('password123', 12);
  return EMPLOYEES.map(e => ({
    employee_id:             e.id,
    username:                e.username,
    password_hash:           hash,
    force_password_reset:    false,
    role:                    e.role,
    is_team_lead:            e.is_team_lead,
    department_access:       e.departments,
    client_visibility:       e.role === 'Employee' ? 'Assigned Clients Only' : e.role === 'Team Lead' ? 'Team Scope Only' : 'All Clients',
    dashboard_my_tasks:      true,
    dashboard_my_team:       e.role === 'Team Lead',
    dashboard_dept_overview: ['Admin','Super Master'].includes(e.role),
    dashboard_firm_wide:     e.role === 'Super Master',
    can_onboard_clients:     ['Admin','Super Master'].includes(e.role),
    can_edit_compliance_master: e.role === 'Super Master',
    can_generate_reports:    ['Admin','Super Master'].includes(e.role),
    can_export_data:         e.role === 'Super Master',
    account_status:          'Active',
    failed_login_attempts:   0,
    access_grant_date:       new Date().toISOString(),
  }));
}

// ── Clients ───────────────────────────────────────────────────
const CLIENTS = [
  { id:'CL001', code:'GRP-MEHTA-01', name:'Mehta Industries Pvt Ltd',  pan:'AAACM1234F', tan:'MUMM12345F', cin:'U74999MH2010PTC200123', client_group:'Mehta Group', constitution:'Pvt Ltd',       status:'Active', pan_status:'Confirmed', created_by:'EMP002' },
  { id:'CL002', code:'GRP-MEHTA-02', name:'Mehta Exports LLP',         pan:'AABFM2345G', tan:'MUMM23456G', cin:'AAB-1234',              client_group:'Mehta Group', constitution:'LLP',           status:'Active', pan_status:'Confirmed', created_by:'EMP002' },
  { id:'CL003', code:'GRP-MEHTA-03', name:'Mehta Real Estate Ltd',     pan:'AACCM3456H', tan:null,         cin:'U70100MH2015PLC272345', client_group:'Mehta Group', constitution:'Pvt Ltd',       status:'Active', pan_status:'Confirmed', created_by:'EMP003' },
  { id:'CL004', code:'SINGL-GUPTA-01',name:'Gupta & Sons (Prop.)',     pan:'ADCPG4567I', tan:'DELG45678I', cin:null,                    client_group:null,          constitution:'Proprietorship',status:'Active', pan_status:'Confirmed', created_by:'EMP002' },
  { id:'CL005', code:'SINGL-SHARMA-01',name:'Sharma Tech Pvt Ltd',     pan:'AAQCS5678J', tan:'HRSS56789J', cin:'U72200HR2018PTC073219', client_group:null,          constitution:'Pvt Ltd',       status:'Active', pan_status:'Confirmed', created_by:'EMP002' },
  { id:'CL006', code:'NGO-TRUST-01',  name:'Aashray Foundation Trust', pan:'AAAAT6789K', tan:null,         cin:null,                    client_group:null,          constitution:'Trust',         status:'Active', pan_status:'Confirmed', created_by:'EMP004' },
  { id:'CL007', code:'GRP-VERMA-01',  name:'Verma Holdings Pvt Ltd',   pan:'AABCV7890L', tan:'UPKV78901L', cin:'U65100UP2012PTC053421', client_group:'Verma Group', constitution:'Pvt Ltd',       status:'Active', pan_status:'Confirmed', created_by:'EMP002' },
  { id:'CL008', code:'GRP-VERMA-02',  name:'Verma Logistics Ltd',      pan:'AABDV8901M', tan:'UPKV89012M', cin:'U60300UP2016PLC087654', client_group:'Verma Group', constitution:'Pvt Ltd',       status:'Active', pan_status:'Confirmed', created_by:'EMP002' },
  { id:'CL009', code:'SINGL-REDDY-01',name:'Reddy Pharma Pvt Ltd',     pan:'AAECR9012N', tan:'HYDR90123N', cin:'U24230TG2019PTC131415', client_group:null,          constitution:'Pvt Ltd',       status:'Active', pan_status:'Confirmed', created_by:'EMP002' },
  { id:'CL010', code:'SINGL-JAIN-01', name:'Jain Textiles (P) Ltd',    pan:'AABCJ0123O', tan:'SURJ01234O', cin:'U17111GJ2008PTC053219', client_group:null,          constitution:'Pvt Ltd',       status:'Inactive',pan_status:'Confirmed', created_by:'EMP003' },
];

const CLIENT_DEPTS: { client_id: string; department: string }[] = [
  { client_id:'CL001', department:'GST' }, { client_id:'CL001', department:'Income Tax' }, { client_id:'CL001', department:'Audit' },
  { client_id:'CL002', department:'GST' }, { client_id:'CL002', department:'TDS' },
  { client_id:'CL003', department:'Income Tax' }, { client_id:'CL003', department:'Company Law' },
  { client_id:'CL004', department:'GST' }, { client_id:'CL004', department:'Income Tax' },
  { client_id:'CL005', department:'GST' }, { client_id:'CL005', department:'TDS' }, { client_id:'CL005', department:'Company Law' },
  { client_id:'CL006', department:'NGO' }, { client_id:'CL006', department:'Accounts' },
  { client_id:'CL007', department:'GST' }, { client_id:'CL007', department:'Income Tax' }, { client_id:'CL007', department:'Audit' }, { client_id:'CL007', department:'TDS' },
  { client_id:'CL008', department:'GST' }, { client_id:'CL008', department:'TDS' },
  { client_id:'CL009', department:'GST' }, { client_id:'CL009', department:'Income Tax' }, { client_id:'CL009', department:'Audit' },
  { client_id:'CL010', department:'GST' }, { client_id:'CL010', department:'Income Tax' },
];

const GSTINS = [
  { id:'GST001', client_id:'CL001', gstin:'27AAACM1234F1Z5', state:'Maharashtra', registration_type:'Regular', return_frequency:'Monthly', gst_status:'Active' },
  { id:'GST002', client_id:'CL002', gstin:'27AABFM2345G1Z4', state:'Maharashtra', registration_type:'Regular', return_frequency:'Monthly', gst_status:'Active' },
  { id:'GST003', client_id:'CL003', gstin:'27AACCM3456H1Z3', state:'Maharashtra', registration_type:'Regular', return_frequency:'Monthly', gst_status:'Active' },
  { id:'GST004', client_id:'CL004', gstin:'07ADCPG4567I1Z2', state:'Delhi',       registration_type:'Regular', return_frequency:'Quarterly', gst_status:'Active' },
  { id:'GST005', client_id:'CL005', gstin:'06AAQCS5678J1Z1', state:'Haryana',     registration_type:'Regular', return_frequency:'Monthly', gst_status:'Active' },
  { id:'GST006', client_id:'CL007', gstin:'09AABCV7890L1Z0', state:'UP',          registration_type:'Regular', return_frequency:'Monthly', gst_status:'Active' },
  { id:'GST007', client_id:'CL008', gstin:'09AABDV8901M1Z9', state:'UP',          registration_type:'Regular', return_frequency:'Monthly', gst_status:'Active' },
  { id:'GST008', client_id:'CL009', gstin:'36AAECR9012N1Z8', state:'Telangana',   registration_type:'Regular', return_frequency:'Monthly', gst_status:'Active' },
  { id:'GST009', client_id:'CL010', gstin:'24AABCJ0123O1Z7', state:'Gujarat',     registration_type:'Regular', return_frequency:'Monthly', gst_status:'Active' },
];

// ── Compliance Types ──────────────────────────────────────────
const COMPLIANCE_TYPES = [
  { id:'COMP001', filing_category:'GST',         filing_type:'GSTR-3B',            frequency:'Monthly',   due_date_rule:'20th of following month',      applicability_rules:'Active GSTIN required', status:'Active' },
  { id:'COMP002', filing_category:'GST',         filing_type:'GSTR-1',             frequency:'Monthly',   due_date_rule:'11th of following month',      applicability_rules:'Active GSTIN required', status:'Active' },
  { id:'COMP003', filing_category:'GST',         filing_type:'GSTR-9',             frequency:'Annual',    due_date_rule:'31st December',                applicability_rules:'Active GSTIN required', status:'Active' },
  { id:'COMP004', filing_category:'GST',         filing_type:'GSTR-9C',            frequency:'Annual',    due_date_rule:'31st December',                applicability_rules:'Turnover > 5 Cr', status:'Active' },
  { id:'COMP005', filing_category:'TDS',         filing_type:'TDS Return 26Q',     frequency:'Quarterly', due_date_rule:'31st of month after quarter', applicability_rules:'TAN required', status:'Active' },
  { id:'COMP006', filing_category:'TDS',         filing_type:'TDS Return 24Q',     frequency:'Quarterly', due_date_rule:'31st of month after quarter', applicability_rules:'Salary TDS', status:'Active' },
  { id:'COMP007', filing_category:'TDS',         filing_type:'Form 16 Issuance',   frequency:'Annual',    due_date_rule:'15th June',                    applicability_rules:'Salary TDS only', status:'Active' },
  { id:'COMP008', filing_category:'Income Tax',  filing_type:'Advance Tax',        frequency:'Quarterly', due_date_rule:'Jun 15, Sep 15, Dec 15, Mar 15', applicability_rules:null, status:'Active' },
  { id:'COMP009', filing_category:'Income Tax',  filing_type:'ITR-6',              frequency:'Annual',    due_date_rule:'31st October',                 applicability_rules:'Companies', status:'Active' },
  { id:'COMP010', filing_category:'Income Tax',  filing_type:'ITR-4',              frequency:'Annual',    due_date_rule:'31st July',                    applicability_rules:'Individuals/HUF/Firms', status:'Active' },
  { id:'COMP011', filing_category:'Company Law', filing_type:'DIR-3 KYC',          frequency:'Annual',    due_date_rule:'30th September',               applicability_rules:'All directors', status:'Active' },
  { id:'COMP012', filing_category:'Company Law', filing_type:'Annual Return MGT-7',frequency:'Annual',    due_date_rule:'60 days from AGM',             applicability_rules:'All companies', status:'Active' },
  { id:'COMP013', filing_category:'Company Law', filing_type:'Form AOC-4',         frequency:'Annual',    due_date_rule:'30th October',                 applicability_rules:'All companies', status:'Active' },
  { id:'COMP014', filing_category:'Company Law', filing_type:'Form 8 LLP Filing',  frequency:'Annual',    due_date_rule:'30th October',                 applicability_rules:'LLP only', status:'Active' },
  { id:'COMP015', filing_category:'Audit',       filing_type:'Tax Audit Report 3CD',frequency:'Annual',   due_date_rule:'30th September',               applicability_rules:'Turnover > 1 Cr', status:'Active' },
  { id:'COMP016', filing_category:'Audit',       filing_type:'Statutory Audit',    frequency:'Annual',    due_date_rule:'30th September',               applicability_rules:'Companies Act 2013', status:'Active' },
  { id:'COMP017', filing_category:'NGO',         filing_type:'Form 10B Audit',     frequency:'Annual',    due_date_rule:'30th September',               applicability_rules:'80G trusts', status:'Active' },
];

// ── Tasks ──────────────────────────────────────────────────────
const TASKS = [
  { id:'TASK00001', client_id:'CL001', dept:'GST',         type:'GSTR-3B Filing',           assigned_to:'EMP007', assigned_by:'EMP005', priority:'High',   status:'T2', t0:d(-15), t1:d(-14), t2:d(-5),  t3:null,   due:d(1),   remarks:'', compliance_type_id:'COMP001' },
  { id:'TASK00002', client_id:'CL001', dept:'Income Tax',  type:'ITR-6 Filing',             assigned_to:'EMP010', assigned_by:'EMP003', priority:'High',   status:'T1', t0:d(-5),  t1:d(-4),  t2:null,   t3:null,   due:d(15),  remarks:'', compliance_type_id:'COMP009' },
  { id:'TASK00003', client_id:'CL002', dept:'GST',         type:'GSTR-1 Filing',            assigned_to:'EMP008', assigned_by:'EMP005', priority:'Medium', status:'T3', t0:d(-20), t1:d(-19), t2:d(-10), t3:d(-2),  due:d(-2),  remarks:'', compliance_type_id:'COMP002' },
  { id:'TASK00004', client_id:'CL003', dept:'Company Law', type:'DIR-3 KYC',                assigned_to:'EMP012', assigned_by:'EMP004', priority:'High',   status:'T2', t0:d(-8),  t1:d(-7),  t2:d(-3),  t3:null,   due:d(3),   remarks:'', compliance_type_id:'COMP011' },
  { id:'TASK00005', client_id:'CL004', dept:'Income Tax',  type:'Advance Tax Calculation',  assigned_to:'EMP011', assigned_by:'EMP006', priority:'Medium', status:'T1', t0:d(-3),  t1:d(-2),  t2:null,   t3:null,   due:d(10),  remarks:'', compliance_type_id:'COMP008' },
  { id:'TASK00006', client_id:'CL005', dept:'TDS',         type:'TDS Return Q4',            assigned_to:'EMP013', assigned_by:'EMP002', priority:'High',   status:'T2', t0:d(-10), t1:d(-9),  t2:d(-4),  t3:null,   due:d(0),   remarks:'Pending from Client', pending_from_client:true, compliance_type_id:'COMP005' },
  { id:'TASK00007', client_id:'CL006', dept:'NGO',         type:'Form 10B Audit',           assigned_to:'EMP012', assigned_by:'EMP004', priority:'Low',    status:'T1', t0:d(-6),  t1:d(-5),  t2:null,   t3:null,   due:d(20),  remarks:'', compliance_type_id:'COMP017' },
  { id:'TASK00008', client_id:'CL007', dept:'Audit',       type:'Statutory Audit FY25',     assigned_to:'EMP012', assigned_by:'EMP004', priority:'High',   status:'T0', t0:d(-1),  t1:null,   t2:null,   t3:null,   due:d(30),  remarks:'', compliance_type_id:'COMP016' },
  { id:'TASK00009', client_id:'CL007', dept:'GST',         type:'GSTR-9 Annual Return',     assigned_to:'EMP009', assigned_by:'EMP005', priority:'High',   status:'T2', t0:d(-25), t1:d(-24), t2:d(-10), t3:null,   due:d(-1),  remarks:'', compliance_type_id:'COMP003' },
  { id:'TASK00010', client_id:'CL008', dept:'TDS',         type:'Form 16 Issuance',         assigned_to:'EMP013', assigned_by:'EMP002', priority:'Medium', status:'T3', t0:d(-30), t1:d(-29), t2:d(-20), t3:d(-5),  due:d(-5),  remarks:'', compliance_type_id:'COMP007' },
  { id:'TASK00011', client_id:'CL009', dept:'GST',         type:'GSTR-3B Filing',           assigned_to:'EMP007', assigned_by:'EMP005', priority:'Medium', status:'T1', t0:d(-4),  t1:d(-3),  t2:null,   t3:null,   due:d(8),   remarks:'', compliance_type_id:'COMP001' },
  { id:'TASK00012', client_id:'CL009', dept:'Audit',       type:'Tax Audit Report 3CD',     assigned_to:'EMP012', assigned_by:'EMP004', priority:'High',   status:'T2', t0:d(-12), t1:d(-11), t2:d(-6),  t3:null,   due:d(5),   remarks:'', compliance_type_id:'COMP015' },
  { id:'TASK00013', client_id:'CL001', dept:'TDS',         type:'TDS Return Q4',            assigned_to:'EMP013', assigned_by:'EMP002', priority:'High',   status:'T2', t0:d(-9),  t1:d(-8),  t2:d(-4),  t3:null,   due:d(0),   remarks:'', compliance_type_id:'COMP005' },
  { id:'TASK00014', client_id:'CL004', dept:'GST',         type:'GSTR-1 Filing',            assigned_to:'EMP008', assigned_by:'EMP005', priority:'Low',    status:'T3', t0:d(-18), t1:d(-17), t2:d(-10), t3:d(-3),  due:d(-3),  remarks:'', compliance_type_id:'COMP002' },
  { id:'TASK00015', client_id:'CL005', dept:'Company Law', type:'Annual Return MGT-7',      assigned_to:'EMP012', assigned_by:'EMP004', priority:'Medium', status:'T0', t0:d(0),   t1:null,   t2:null,   t3:null,   due:d(25),  remarks:'', compliance_type_id:'COMP012' },
];

// ── Compliance Schedule ───────────────────────────────────────
const COMPLIANCE_SCHEDULE = [
  { id:'SCH00001', client_id:'CL001', compliance_type_id:'COMP001', period:'Mar 2026', due_date:d(0),  status:'In Progress', assigned_employee:'EMP007' },
  { id:'SCH00002', client_id:'CL005', compliance_type_id:'COMP005', period:'Q4 FY26',  due_date:d(1),  status:'In Progress', assigned_employee:'EMP013' },
  { id:'SCH00003', client_id:'CL003', compliance_type_id:'COMP011', period:'FY26',     due_date:d(3),  status:'In Progress', assigned_employee:'EMP012' },
  { id:'SCH00004', client_id:'CL009', compliance_type_id:'COMP015', period:'FY25',     due_date:d(5),  status:'In Progress', assigned_employee:'EMP012' },
  { id:'SCH00005', client_id:'CL002', compliance_type_id:'COMP002', period:'Mar 2026', due_date:d(7),  status:'Unassigned',  assigned_employee:null },
  { id:'SCH00006', client_id:'CL004', compliance_type_id:'COMP008', period:'Jun 2026', due_date:d(10), status:'Assigned',    assigned_employee:'EMP011' },
  { id:'SCH00007', client_id:'CL007', compliance_type_id:'COMP006', period:'Q4 FY26',  due_date:d(11), status:'Unassigned',  assigned_employee:null },
  { id:'SCH00008', client_id:'CL001', compliance_type_id:'COMP009', period:'FY25',     due_date:d(15), status:'Assigned',    assigned_employee:'EMP010' },
  { id:'SCH00009', client_id:'CL006', compliance_type_id:'COMP017', period:'FY25',     due_date:d(20), status:'Assigned',    assigned_employee:'EMP012' },
  { id:'SCH00010', client_id:'CL005', compliance_type_id:'COMP012', period:'FY25',     due_date:d(25), status:'Unassigned',  assigned_employee:null },
  { id:'SCH00011', client_id:'CL007', compliance_type_id:'COMP016', period:'FY25',     due_date:d(30), status:'Assigned',    assigned_employee:'EMP012' },
];

// ── Team Composition ─────────────────────────────────────────
const TEAM_COMPOSITION = [
  { id:'TC001', team_lead_id:'EMP005', member_id:'EMP007', effective_from:d(-365), status:'Active', designated_by:'EMP001' },
  { id:'TC002', team_lead_id:'EMP005', member_id:'EMP008', effective_from:d(-365), status:'Active', designated_by:'EMP001' },
  { id:'TC003', team_lead_id:'EMP005', member_id:'EMP009', effective_from:d(-365), status:'Active', designated_by:'EMP001' },
  { id:'TC004', team_lead_id:'EMP006', member_id:'EMP010', effective_from:d(-300), status:'Active', designated_by:'EMP001' },
  { id:'TC005', team_lead_id:'EMP006', member_id:'EMP011', effective_from:d(-300), status:'Active', designated_by:'EMP001' },
];

// ── Audit Log ────────────────────────────────────────────────
const AUDIT_LOG = [
  { id:'LOG00001', timestamp:`${d(0)}T09:42:11Z`, actor_employee_id:'EMP001', actor_name:'Vinayak Agarwal', actor_role:'Super Master', action_type:'Profile Created',      action_description:'Created new employee profile: Tarun Bose (EMP011) with role Employee',   ip_address:'192.168.1.1' },
  { id:'LOG00002', timestamp:`${d(0)}T09:15:03Z`, actor_employee_id:'EMP002', actor_name:'Priya Sharma',    actor_role:'Admin',        action_type:'Task Created',          action_description:'Assigned task GSTR-3B Filing to Rahul Verma for Reddy Pharma',          ip_address:'192.168.1.5' },
  { id:'LOG00003', timestamp:`${d(0)}T08:58:47Z`, actor_employee_id:'EMP005', actor_name:'Arjun Kapoor',    actor_role:'Team Lead',    action_type:'Task Advanced',         action_description:'Task TASK00003 advanced to T3 — GSTR-1 Filing for Mehta Exports LLP', ip_address:'192.168.1.8' },
  { id:'LOG00004', timestamp:`${d(-1)}T17:32:20Z`,actor_employee_id:'EMP007', actor_name:'Rahul Verma',     actor_role:'Employee',     action_type:'Task Advanced',         action_description:'Task TASK00001 advanced to T2 — GSTR-3B Filing (Mehta Industries)',    ip_address:'192.168.1.12' },
  { id:'LOG00005', timestamp:`${d(-1)}T16:45:09Z`,actor_employee_id:'EMP003', actor_name:'Rakesh Mehta',    actor_role:'Admin',        action_type:'Task Created',          action_description:'Flagged ITR-6 Filing as High Priority for Mehta Industries',          ip_address:'192.168.1.6' },
  { id:'LOG00006', timestamp:`${d(-1)}T15:20:33Z`,actor_employee_id:'EMP013', actor_name:'Sameer Khan',     actor_role:'Employee',     action_type:'Task Advanced',         action_description:'Flagged TDS Return Q4 as Pending from Client — Sharma Tech',          ip_address:'192.168.1.15' },
  { id:'LOG00007', timestamp:`${d(-1)}T14:11:55Z`,actor_employee_id:'EMP001', actor_name:'Vinayak Agarwal', actor_role:'Super Master', action_type:'Team Lead Designated',  action_description:'Designated Arjun Kapoor as Team Lead for GST team [EMP007, EMP008, EMP009]', ip_address:'192.168.1.1' },
  { id:'LOG00008', timestamp:`${d(-1)}T11:05:30Z`,actor_employee_id:'EMP004', actor_name:'Sunita Joshi',    actor_role:'Admin',        action_type:'Client Onboarded',      action_description:'Onboarded new client: Aashray Foundation Trust (NGO-TRUST-01)',      ip_address:'192.168.1.7' },
  { id:'LOG00009', timestamp:`${d(-2)}T17:00:00Z`,actor_employee_id:'EMP006', actor_name:'Deepa Nair',      actor_role:'Team Lead',    action_type:'Task Created',          action_description:'Delegated Advance Tax Calculation sub-task to Tarun Bose',           ip_address:'192.168.1.9' },
  { id:'LOG00010', timestamp:`${d(-2)}T14:30:11Z`,actor_employee_id:'EMP002', actor_name:'Priya Sharma',    actor_role:'Admin',        action_type:'Client Modified',       action_description:'Added GSTIN 09AABCV7890L1Z0 to Verma Holdings client record',       ip_address:'192.168.1.5' },
  { id:'LOG00011', timestamp:`${d(-2)}T10:22:44Z`,actor_employee_id:'EMP001', actor_name:'Vinayak Agarwal', actor_role:'Super Master', action_type:'Compliance Master Edited', action_description:'Modified statutory deadline: GSTR-9 due date updated to Apr 30',  ip_address:'192.168.1.1' },
  { id:'LOG00012', timestamp:`${d(-3)}T16:55:12Z`,actor_employee_id:'EMP005', actor_name:'Arjun Kapoor',    actor_role:'Team Lead',    action_type:'Task Reverted',         action_description:'Task TASK00009 reverted with remarks: "Figures mismatch in table 6A"', ip_address:'192.168.1.8' },
];

// ── Main ─────────────────────────────────────────────────────
async function seed() {
  console.log('🌱 Starting seed…');

  // Clear existing data (in order to avoid FK violations)
  const tables = ['audit_log','subtask_checklist','tasks','compliance_schedule','team_composition','gstins','client_departments','clients','login_registry','employees','compliance_types'];
  for (const t of tables) {
    await db.from(t).delete().neq('id','__never__');
    console.log(`  ✓ Cleared ${t}`);
  }

  // Insert employees
  const { error: empErr } = await db.from('employees').insert(EMPLOYEES);
  if (empErr) { console.error('employees:', empErr); process.exit(1); }
  console.log(`  ✓ Inserted ${EMPLOYEES.length} employees`);

  // Insert login registry
  const loginData = await buildLoginRegistry();
  const { error: lrErr } = await db.from('login_registry').insert(loginData);
  if (lrErr) { console.error('login_registry:', lrErr); process.exit(1); }
  console.log(`  ✓ Inserted ${loginData.length} login records`);
  console.log('    Default password for all users: password123');

  // Insert clients
  const { error: clErr } = await db.from('clients').insert(CLIENTS);
  if (clErr) { console.error('clients:', clErr); process.exit(1); }
  console.log(`  ✓ Inserted ${CLIENTS.length} clients`);

  const { error: cdErr } = await db.from('client_departments').insert(CLIENT_DEPTS);
  if (cdErr) { console.error('client_departments:', cdErr); process.exit(1); }
  console.log(`  ✓ Inserted ${CLIENT_DEPTS.length} client-department links`);

  const { error: gErr } = await db.from('gstins').insert(GSTINS);
  if (gErr) { console.error('gstins:', gErr); process.exit(1); }
  console.log(`  ✓ Inserted ${GSTINS.length} GSTINs`);

  const { error: ctErr } = await db.from('compliance_types').insert(COMPLIANCE_TYPES);
  if (ctErr) { console.error('compliance_types:', ctErr); process.exit(1); }
  console.log(`  ✓ Inserted ${COMPLIANCE_TYPES.length} compliance types`);

  const { error: tcErr } = await db.from('team_composition').insert(TEAM_COMPOSITION);
  if (tcErr) { console.error('team_composition:', tcErr); process.exit(1); }
  console.log(`  ✓ Inserted ${TEAM_COMPOSITION.length} team composition records`);

  // Insert tasks (handle nullable fields)
  const tasksToInsert = TASKS.map(t => ({ ...t, pending_from_client: (t as any).pending_from_client ?? false, recurring: false }));
  const { error: tErr } = await db.from('tasks').insert(tasksToInsert);
  if (tErr) { console.error('tasks:', tErr); process.exit(1); }
  console.log(`  ✓ Inserted ${TASKS.length} tasks`);

  const { error: csErr } = await db.from('compliance_schedule').insert(COMPLIANCE_SCHEDULE);
  if (csErr) { console.error('compliance_schedule:', csErr); process.exit(1); }
  console.log(`  ✓ Inserted ${COMPLIANCE_SCHEDULE.length} compliance schedule entries`);

  const { error: alErr } = await db.from('audit_log').insert(AUDIT_LOG);
  if (alErr) { console.error('audit_log:', alErr); process.exit(1); }
  console.log(`  ✓ Inserted ${AUDIT_LOG.length} audit log entries`);

  console.log('\n✅ Seed complete!');
  console.log('\n📋 Login credentials:');
  console.log('  Username: vinayak     | Role: Super Master');
  console.log('  Username: priya.gst   | Role: Admin (GST)');
  console.log('  Username: rakesh.it   | Role: Admin (Income Tax)');
  console.log('  Username: arjun.lead  | Role: Team Lead (GST)');
  console.log('  Username: rahul.gst   | Role: Employee (GST)');
  console.log('  Password for all: password123');
}

seed().catch(console.error);
