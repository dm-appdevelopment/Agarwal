'use client';
import { useEffect, useState } from 'react';
import { DEPT_BG, DEPT_COLOR, DEPARTMENTS as STATIC_DEPTS } from './utils';

export interface DepartmentRecord {
  id: string;
  name: string;
  color_bg: string;
  color_text: string;
  status: string;
}

// Module-level cache so all hook instances share the same data
let _cache: DepartmentRecord[] | null = null;
let _promise: Promise<DepartmentRecord[]> | null = null;

async function fetchDepts(): Promise<DepartmentRecord[]> {
  if (_cache) return _cache;
  if (!_promise) {
    _promise = fetch('/api/departments')
      .then(r => r.json())
      .then(d => { _cache = d.departments ?? []; return _cache!; })
      .catch(() => { _promise = null; return [] as DepartmentRecord[]; });
  }
  return _promise;
}

export function invalidateDeptCache() {
  _cache   = null;
  _promise = null;
}

export function useDepartments() {
  const [data, setData]       = useState<DepartmentRecord[]>(_cache ?? []);
  const [loading, setLoading] = useState(!_cache);

  useEffect(() => {
    if (_cache) { setData(_cache); setLoading(false); return; }
    fetchDepts().then(d => { setData(d); setLoading(false); });
  }, []);

  const active = data.filter(d => d.status === 'Active');

  const departments: string[] = active.length > 0
    ? active.map(d => d.name)
    : [...STATIC_DEPTS];

  const deptBg: Record<string, string> = active.length > 0
    ? Object.fromEntries(active.map(d => [d.name, d.color_bg]))
    : { ...DEPT_BG };

  const deptColor: Record<string, string> = active.length > 0
    ? Object.fromEntries(active.map(d => [d.name, d.color_text]))
    : { ...DEPT_COLOR };

  return { departments, deptBg, deptColor, loading, raw: active };
}
