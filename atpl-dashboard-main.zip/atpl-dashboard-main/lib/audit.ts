import { createServerClient } from '@/lib/supabase-server';
import type { SessionUser } from '@/types';

type ActionType =
  | 'Profile Created' | 'Profile Modified' | 'Profile Deleted'
  | 'Team Lead Designated' | 'Team Composition Changed'
  | 'Access Level Changed' | 'Compliance Master Edited'
  | 'Task Transferred' | 'Task Created' | 'Task Advanced' | 'Task Reverted'
  | 'Client Onboarded' | 'Client Modified'
  | 'Data Export' | 'Bulk Operation' | 'Configuration Change'
  | 'Password Reset' | 'Account Locked' | 'Account Unlocked' | 'Login';

interface AuditParams {
  actor: SessionUser;
  actionType: ActionType;
  targetEntityType?: string;
  targetEntityId?: string;
  description: string;
  previousValue?: string;
  newValue?: string;
  ipAddress?: string;
  sessionId?: string;
}

export async function writeAuditLog(params: AuditParams) {
  const db = createServerClient();
  const { count } = await db.from('audit_log').select('*', { count: 'exact', head: true });
  const seq = (count ?? 0) + 1;
  const id  = `LOG${String(seq).padStart(5, '0')}`;

  await db.from('audit_log').insert({
    id,
    actor_employee_id:  params.actor.id,
    actor_name:         params.actor.full_name,
    actor_role:         params.actor.role,
    action_type:        params.actionType,
    target_entity_type: params.targetEntityType ?? null,
    target_entity_id:   params.targetEntityId ?? null,
    action_description: params.description,
    previous_value:     params.previousValue ?? null,
    new_value:          params.newValue ?? null,
    ip_address:         params.ipAddress ?? null,
    session_id:         params.sessionId ?? null,
  });
}
