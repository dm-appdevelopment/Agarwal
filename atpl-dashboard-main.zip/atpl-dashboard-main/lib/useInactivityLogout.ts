'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';

const TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes
const WARNING_MS =  5 * 60 * 1000; // warn at 25-minute mark

export function useInactivityLogout() {
  const router = useRouter();
  const lastActivityRef = useRef<number>(Date.now());
  const loggedOutRef    = useRef(false);
  const [showWarning,      setShowWarning]      = useState(false);
  const [remainingSeconds, setRemainingSeconds] = useState(0);

  const doLogout = useCallback(async () => {
    if (loggedOutRef.current) return;
    loggedOutRef.current = true;
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
    router.refresh();
  }, [router]);

  const resetTimer = useCallback(() => {
    lastActivityRef.current = Date.now();
    setShowWarning(false);
  }, []);

  useEffect(() => {
    const EVENTS = ['mousedown', 'keydown', 'touchstart', 'scroll', 'mousemove'] as const;
    const onActivity = () => { lastActivityRef.current = Date.now(); };
    EVENTS.forEach(e => window.addEventListener(e, onActivity, { passive: true }));

    const tick = setInterval(() => {
      if (loggedOutRef.current) return;
      const elapsed   = Date.now() - lastActivityRef.current;
      const remaining = TIMEOUT_MS - elapsed;

      if (remaining <= 0) {
        doLogout();
        return;
      }

      if (remaining <= WARNING_MS) {
        setShowWarning(true);
        setRemainingSeconds(Math.ceil(remaining / 1000));
      } else {
        setShowWarning(false);
      }
    }, 1000);

    return () => {
      EVENTS.forEach(e => window.removeEventListener(e, onActivity));
      clearInterval(tick);
    };
  }, [doLogout]);

  return { showWarning, remainingSeconds, resetTimer, doLogout };
}
