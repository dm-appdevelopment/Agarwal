export const GSTIN_REG_TYPES   = ['Regular','Composition','SEZ Developer','SEZ Unit','ISD','Non-Resident','OIDAR','Other'] as const;
export const GSTIN_RETURN_FREQS = ['Monthly','Quarterly'] as const;
export const GSTIN_STATUSES    = ['Active','Cancelled','Suspended'] as const;

const STATE_CODES: Record<string, string> = {
  '01': 'Jammu & Kashmir',    '02': 'Himachal Pradesh',  '03': 'Punjab',
  '04': 'Chandigarh',         '05': 'Uttarakhand',       '06': 'Haryana',
  '07': 'Delhi',              '08': 'Rajasthan',         '09': 'Uttar Pradesh',
  '10': 'Bihar',              '11': 'Sikkim',            '12': 'Arunachal Pradesh',
  '13': 'Nagaland',           '14': 'Manipur',           '15': 'Mizoram',
  '16': 'Tripura',            '17': 'Meghalaya',         '18': 'Assam',
  '19': 'West Bengal',        '20': 'Jharkhand',         '21': 'Odisha',
  '22': 'Chhattisgarh',       '23': 'Madhya Pradesh',    '24': 'Gujarat',
  '26': 'Dadra & NH / D&D',   '27': 'Maharashtra',       '28': 'Andhra Pradesh (old)',
  '29': 'Karnataka',          '30': 'Goa',               '31': 'Lakshadweep',
  '32': 'Kerala',             '33': 'Tamil Nadu',        '34': 'Puducherry',
  '35': 'Andaman & Nicobar',  '36': 'Telangana',         '37': 'Andhra Pradesh',
  '38': 'Ladakh',             '96': 'Foreign',           '97': 'Other Territory',
  '99': 'Centre Jurisdiction',
};

export function stateFromGstin(gstin: string): string {
  return STATE_CODES[gstin.slice(0, 2)] ?? '';
}

export function validateGstin(gstin: string): string {
  const g = gstin.trim().toUpperCase();
  if (g.length !== 15) return 'GSTIN must be exactly 15 characters';
  if (!/^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]$/.test(g)) return 'GSTIN format is invalid';
  return '';
}
