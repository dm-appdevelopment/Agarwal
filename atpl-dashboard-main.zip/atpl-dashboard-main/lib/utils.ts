import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, differenceInCalendarDays, parseISO } from 'date-fns';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | null | undefined): string {
  if (!date) return '—';
  try { return format(parseISO(date), 'dd MMM yyyy'); } catch { return date; }
}

export function formatDateTime(date: string | null | undefined): string {
  if (!date) return '—';
  try { return format(parseISO(date), 'dd MMM yyyy HH:mm'); } catch { return date; }
}

/** Days until a date from today. Negative = overdue. */
export function daysUntil(dateStr: string | null | undefined): { label: string; color: string } {
  if (!dateStr) return { label: '—', color: '#94A3B8' };
  const diff = differenceInCalendarDays(parseISO(dateStr), new Date());
  if (diff < 0) return { label: `${Math.abs(diff)}d overdue`, color: '#EF4444' };
  if (diff === 0) return { label: 'Due today', color: '#F59E0B' };
  return { label: `${diff}d left`, color: diff <= 3 ? '#F97316' : '#64748B' };
}

export function today(): string {
  return format(new Date(), 'yyyy-MM-dd');
}

// Sequential ID generators
export function genId(prefix: string, seq: number): string {
  const digits = prefix === 'EMP' ? 3 : 5;
  return `${prefix}${String(seq).padStart(digits, '0')}`;
}

// Role colours
export const ROLE_COLOR: Record<string, string> = {
  'Super Master': '#1D4ED8',
  Admin:          '#7C3AED',
  'Team Lead':    '#0891B2',
  Employee:       '#059669',
};

export const ROLE_BG: Record<string, string> = {
  'Super Master': '#EFF6FF',
  Admin:          '#F5F3FF',
  'Team Lead':    '#ECFEFF',
  Employee:       '#F0FDF4',
};

export const DEPT_BG: Record<string, string> = {
  GST:           '#DBEAFE',
  'Income Tax':  '#D1FAE5',
  Audit:         '#FEF3C7',
  TDS:           '#EDE9FE',
  'Company Law': '#FCE7F3',
  NGO:           '#DCFCE7',
  Accounts:      '#F1F5F9',
};

export const DEPT_COLOR: Record<string, string> = {
  GST:           '#3B82F6',
  'Income Tax':  '#10B981',
  Audit:         '#F59E0B',
  TDS:           '#8B5CF6',
  'Company Law': '#EC4899',
  NGO:           '#14B8A6',
  Accounts:      '#64748B',
};

export const STATUS_COLOR: Record<string, string> = {
  T0: '#94A3B8',
  T1: '#3B82F6',
  T2: '#F59E0B',
  T3: '#10B981',
};

export const STATUS_LABEL: Record<string, string> = {
  T0: 'Received',
  T1: 'Allocated',
  T2: 'Submitted for Review',
  T3: 'Approved',
};

export const PRIO_COLOR: Record<string, string> = {
  High:   '#EF4444',
  Medium: '#F59E0B',
  Low:    '#10B981',
};

export const DEPARTMENTS = ['GST','Income Tax','Audit','TDS','Company Law','NGO','Accounts'] as const;

// Palette cycled for dynamically-added departments
export const COLOR_PALETTE = [
  { bg: '#FEE2E2', text: '#EF4444' },
  { bg: '#FEF9C3', text: '#CA8A04' },
  { bg: '#ECFDF5', text: '#059669' },
  { bg: '#FFF7ED', text: '#EA580C' },
  { bg: '#F0FDF4', text: '#16A34A' },
  { bg: '#FDF2F8', text: '#DB2777' },
  { bg: '#F0F9FF', text: '#0284C7' },
  { bg: '#FDF4FF', text: '#A21CAF' },
];

export const ROLES = ['Super Master','Admin','Team Lead','Employee'] as const;

/** Audit log helper — generates the next LOG id from current count */
export function nextLogId(count: number): string {
  return `LOG${String(count + 1).padStart(5, '0')}`;
}
