'use client';
import { useEffect, useRef } from 'react';
import { supabase } from './supabase';

export function useTasksRealtime(onRefresh: () => void) {
  const callbackRef = useRef(onRefresh);

  // Keep ref current every render so the subscription never goes stale
  useEffect(() => { callbackRef.current = onRefresh; });

  useEffect(() => {
    let debounce: ReturnType<typeof setTimeout>;

    const trigger = () => {
      clearTimeout(debounce);
      debounce = setTimeout(() => callbackRef.current(), 300);
    };

    const channel = supabase
      .channel('tasks-realtime')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'tasks' }, trigger)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'tasks' }, trigger)
      .subscribe();

    return () => {
      clearTimeout(debounce);
      supabase.removeChannel(channel);
    };
  }, []); // subscribe once; fresh callback always available via ref
}
