
// ─── Agarwal Taxcon — Mock Data Store ───────────────────────────────────────

window.AppData = (() => {

const DEPTS = ['GST','Income Tax','Audit','TDS','Company Law','NGO','Accounts'];
const PRIORITIES = ['High','Medium','Low'];
const STATUSES = ['T0','T1','T2','T3'];
const STATUS_LABELS = { T0:'Received', T1:'Allocated', T2:'In Progress', T3:'Approved' };

const USERS = [
  { id:'u1', name:'Vinayak Agarwal',   role:'Super Master', dept:'Management',   avatar:'VA' },
  { id:'u2', name:'Priya Sharma',       role:'Admin',        dept:'GST',          avatar:'PS' },
  { id:'u3', name:'Rakesh Mehta',       role:'Admin',        dept:'Income Tax',   avatar:'RM' },
  { id:'u4', name:'Sunita Joshi',       role:'Admin',        dept:'Audit',        avatar:'SJ' },
  { id:'u5', name:'Arjun Kapoor',       role:'Team Lead',    dept:'GST',          avatar:'AK', teamMembers:['u7','u8','u9'] },
  { id:'u6', name:'Deepa Nair',         role:'Team Lead',    dept:'Income Tax',   avatar:'DN', teamMembers:['u10','u11'] },
  { id:'u7', name:'Rahul Verma',        role:'Employee',     dept:'GST',          avatar:'RV', leadId:'u5' },
  { id:'u8', name:'Kavya Reddy',        role:'Employee',     dept:'GST',          avatar:'KR', leadId:'u5' },
  { id:'u9', name:'Manish Gupta',       role:'Employee',     dept:'GST',          avatar:'MG', leadId:'u5' },
  { id:'u10',name:'Neha Singh',         role:'Employee',     dept:'Income Tax',   avatar:'NS', leadId:'u6' },
  { id:'u11',name:'Tarun Bose',         role:'Employee',     dept:'Income Tax',   avatar:'TB', leadId:'u6' },
  { id:'u12',name:'Pooja Iyer',         role:'Employee',     dept:'Audit',        avatar:'PI' },
  { id:'u13',name:'Sameer Khan',        role:'Employee',     dept:'TDS',          avatar:'SK' },
];

const CLIENTS = [
  { id:'c1',  code:'GRP-MEHTA-01', name:'Mehta Industries Pvt Ltd',  pan:'AAACM1234F', gstin:'27AAACM1234F1Z5',  tan:'MUMM12345F', cin:'U74999MH2010PTC200123', depts:['GST','Income Tax','Audit'], group:'Mehta Group', status:'Active' },
  { id:'c2',  code:'GRP-MEHTA-02', name:'Mehta Exports LLP',         pan:'AABFM2345G', gstin:'27AABFM2345G1Z4',  tan:'MUMM23456G', cin:'AAB-1234',               depts:['GST','TDS'],                group:'Mehta Group', status:'Active' },
  { id:'c3',  code:'GRP-MEHTA-03', name:'Mehta Real Estate Ltd',     pan:'AACCM3456H', gstin:'27AACCM3456H1Z3',  tan:'',           cin:'U70100MH2015PLC272345',  depts:['Income Tax','Company Law'], group:'Mehta Group', status:'Active' },
  { id:'c4',  code:'SINGL-GUPTA-01',name:'Gupta & Sons (Prop.)',     pan:'ADCPG4567I', gstin:'07ADCPG4567I1Z2',  tan:'DELG45678I', cin:'',                       depts:['GST','Income Tax'],         group:'',            status:'Active' },
  { id:'c5',  code:'SINGL-SHARMA-01',name:'Sharma Tech Pvt Ltd',     pan:'AAQCS5678J', gstin:'06AAQCS5678J1Z1',  tan:'HRSS56789J', cin:'U72200HR2018PTC073219',  depts:['GST','TDS','Company Law'],  group:'',            status:'Active' },
  { id:'c6',  code:'NGO-TRUST-01',  name:'Aashray Foundation Trust', pan:'AAAAT6789K', gstin:'',                  tan:'',           cin:'',                       depts:['NGO','Accounts'],           group:'',            status:'Active' },
  { id:'c7',  code:'GRP-VERMA-01',  name:'Verma Holdings Pvt Ltd',   pan:'AABCV7890L', gstin:'09AABCV7890L1Z0',  tan:'UPKV78901L', cin:'U65100UP2012PTC053421',  depts:['GST','Income Tax','Audit','TDS'], group:'Verma Group', status:'Active' },
  { id:'c8',  code:'GRP-VERMA-02',  name:'Verma Logistics Ltd',      pan:'AABDV8901M', gstin:'09AABDV8901M1Z9',  tan:'UPKV89012M', cin:'U60300UP2016PLC087654',  depts:['GST','TDS'],                group:'Verma Group', status:'Active' },
  { id:'c9',  code:'SINGL-REDDY-01',name:'Reddy Pharma Pvt Ltd',     pan:'AAECR9012N', gstin:'36AAECR9012N1Z8',  tan:'HYDR90123N', cin:'U24230TG2019PTC131415',  depts:['GST','Income Tax','Audit'], group:'',            status:'Active' },
  { id:'c10', code:'SINGL-JAIN-01', name:'Jain Textiles (P) Ltd',    pan:'AABCJ0123O', gstin:'24AABCJ0123O1Z7',  tan:'SURJ01234O', cin:'U17111GJ2008PTC053219',  depts:['GST','Income Tax'],         group:'',            status:'Inactive' },
];

const today = new Date('2026-04-20');
const d = (offset) => {
  const dt = new Date(today);
  dt.setDate(dt.getDate() + offset);
  return dt.toISOString().split('T')[0];
};

const TASKS = [
  { id:'t1',  clientId:'c1', clientName:'Mehta Industries Pvt Ltd',  dept:'GST',          type:'GSTR-3B Filing',          assignedTo:'u7',  assignedBy:'u5',  priority:'High',   status:'T2', t0:d(-15), t1:d(-14), t2:null,   t3:null,  due:d(1),  remarks:'' },
  { id:'t2',  clientId:'c1', clientName:'Mehta Industries Pvt Ltd',  dept:'Income Tax',   type:'ITR-6 Filing',            assignedTo:'u10', assignedBy:'u3',  priority:'High',   status:'T1', t0:d(-5),  t1:d(-4),  t2:null,   t3:null,  due:d(15), remarks:'' },
  { id:'t3',  clientId:'c2', clientName:'Mehta Exports LLP',         dept:'GST',          type:'GSTR-1 Filing',           assignedTo:'u8',  assignedBy:'u5',  priority:'Medium', status:'T3', t0:d(-20), t1:d(-19), t2:d(-10), t3:d(-2), due:d(-2), remarks:'' },
  { id:'t4',  clientId:'c3', clientName:'Mehta Real Estate Ltd',     dept:'Company Law',  type:'DIR-3 KYC',               assignedTo:'u12', assignedBy:'u4',  priority:'High',   status:'T2', t0:d(-8),  t1:d(-7),  t2:null,   t3:null,  due:d(3),  remarks:'' },
  { id:'t5',  clientId:'c4', clientName:'Gupta & Sons (Prop.)',      dept:'Income Tax',   type:'Advance Tax Calculation', assignedTo:'u11', assignedBy:'u6',  priority:'Medium', status:'T1', t0:d(-3),  t1:d(-2),  t2:null,   t3:null,  due:d(10), remarks:'' },
  { id:'t6',  clientId:'c5', clientName:'Sharma Tech Pvt Ltd',       dept:'TDS',          type:'TDS Return Q4',           assignedTo:'u13', assignedBy:'u2',  priority:'High',   status:'T2', t0:d(-10), t1:d(-9),  t2:null,   t3:null,  due:d(0),  remarks:'Pending from Client' },
  { id:'t7',  clientId:'c6', clientName:'Aashray Foundation Trust',  dept:'NGO',          type:'Form 10B Audit',          assignedTo:'u12', assignedBy:'u4',  priority:'Low',    status:'T1', t0:d(-6),  t1:d(-5),  t2:null,   t3:null,  due:d(20), remarks:'' },
  { id:'t8',  clientId:'c7', clientName:'Verma Holdings Pvt Ltd',    dept:'Audit',        type:'Statutory Audit FY25',    assignedTo:'u12', assignedBy:'u4',  priority:'High',   status:'T0', t0:d(-1),  t1:null,   t2:null,   t3:null,  due:d(30), remarks:'' },
  { id:'t9',  clientId:'c7', clientName:'Verma Holdings Pvt Ltd',    dept:'GST',          type:'GSTR-9 Annual Return',    assignedTo:'u9',  assignedBy:'u5',  priority:'High',   status:'T2', t0:d(-25), t1:d(-24), t2:null,   t3:null,  due:d(-1), remarks:'' },
  { id:'t10', clientId:'c8', clientName:'Verma Logistics Ltd',       dept:'TDS',          type:'Form 16 Issuance',        assignedTo:'u13', assignedBy:'u2',  priority:'Medium', status:'T3', t0:d(-30), t1:d(-29), t2:d(-20), t3:d(-5), due:d(-5), remarks:'' },
  { id:'t11', clientId:'c9', clientName:'Reddy Pharma Pvt Ltd',      dept:'GST',          type:'GSTR-3B Filing',          assignedTo:'u7',  assignedBy:'u5',  priority:'Medium', status:'T1', t0:d(-4),  t1:d(-3),  t2:null,   t3:null,  due:d(8),  remarks:'' },
  { id:'t12', clientId:'c9', clientName:'Reddy Pharma Pvt Ltd',      dept:'Audit',        type:'Tax Audit Report 3CD',    assignedTo:'u12', assignedBy:'u4',  priority:'High',   status:'T2', t0:d(-12), t1:d(-11), t2:null,   t3:null,  due:d(5),  remarks:'' },
  { id:'t13', clientId:'c1', clientName:'Mehta Industries Pvt Ltd',  dept:'TDS',          type:'TDS Return Q4',           assignedTo:'u13', assignedBy:'u2',  priority:'High',   status:'T2', t0:d(-9),  t1:d(-8),  t2:null,   t3:null,  due:d(0),  remarks:'' },
  { id:'t14', clientId:'c4', clientName:'Gupta & Sons (Prop.)',      dept:'GST',          type:'GSTR-1 Filing',           assignedTo:'u8',  assignedBy:'u5',  priority:'Low',    status:'T3', t0:d(-18), t1:d(-17), t2:d(-10), t3:d(-3), due:d(-3), remarks:'' },
  { id:'t15', clientId:'c5', clientName:'Sharma Tech Pvt Ltd',       dept:'Company Law',  type:'Annual Return MGT-7',     assignedTo:'u12', assignedBy:'u4',  priority:'Medium', status:'T0', t0:d(0),   t1:null,   t2:null,   t3:null,  due:d(25), remarks:'' },
];

const COMPLIANCE = [
  { id:'comp1', date:d(0),  type:'GSTR-3B', period:'Mar 2026', dept:'GST',        clients:['c1','c9','c13'], desc:'Monthly GSTR-3B filing deadline' },
  { id:'comp2', date:d(1),  type:'TDS Return Q4', period:'Q4 FY26', dept:'TDS',   clients:['c5','c1'],       desc:'Q4 TDS Return (26Q / 24Q)' },
  { id:'comp3', date:d(3),  type:'DIR-3 KYC', period:'FY26',    dept:'Company Law',clients:['c3'],            desc:'Director KYC filing with MCA' },
  { id:'comp4', date:d(5),  type:'Tax Audit 3CD', period:'FY25',dept:'Audit',      clients:['c9'],            desc:'Tax Audit Report submission' },
  { id:'comp5', date:d(7),  type:'GSTR-1',   period:'Mar 2026', dept:'GST',        clients:['c2','c7'],       desc:'GSTR-1 outward supplies' },
  { id:'comp6', date:d(10), type:'Advance Tax', period:'Jun 2026',dept:'Income Tax',clients:['c4'],           desc:'1st installment advance tax FY27' },
  { id:'comp7', date:d(11), type:'Form 24Q',  period:'Q4 FY26', dept:'TDS',        clients:['c7','c8'],       desc:'Salary TDS quarterly return' },
  { id:'comp8', date:d(15), type:'ITR-6',     period:'FY25',    dept:'Income Tax', clients:['c1'],            desc:'Corporate ITR-6 filing (extended)' },
  { id:'comp9', date:d(20), type:'Form 10B',  period:'FY25',    dept:'NGO',        clients:['c6'],            desc:'Audit report for 80G trust' },
  { id:'comp10',date:d(25), type:'MGT-7',     period:'FY25',    dept:'Company Law',clients:['c5'],            desc:'Annual return MCA filing' },
  { id:'comp11',date:d(30), type:'Statutory Audit',period:'FY25',dept:'Audit',     clients:['c7'],            desc:'Statutory audit completion deadline' },
  { id:'comp12',date:d(-2), type:'GSTR-3B',  period:'Feb 2026', dept:'GST',        clients:['c2'],            desc:'Monthly GSTR-3B filing deadline' },
];

const AUDIT_LOG = [
  { id:'a1',  ts:'2026-04-20 09:42:11', userId:'u1', user:'Vinayak Agarwal', role:'Super Master', action:'Created new employee profile: Tarun Bose (u11)', module:'User Management', ip:'192.168.1.1' },
  { id:'a2',  ts:'2026-04-20 09:15:03', userId:'u2', user:'Priya Sharma',    role:'Admin',        action:'Assigned task GSTR-3B Filing to Rahul Verma for Reddy Pharma', module:'Task Management', ip:'192.168.1.5' },
  { id:'a3',  ts:'2026-04-20 08:58:47', userId:'u5', user:'Arjun Kapoor',    role:'Team Lead',    action:'Approved (T3) GSTR-1 Filing for Mehta Exports LLP', module:'Task Lifecycle', ip:'192.168.1.8' },
  { id:'a4',  ts:'2026-04-19 17:32:20', userId:'u7', user:'Rahul Verma',     role:'Employee',     action:'Updated status to T2 on GSTR-3B Filing (Mehta Industries)', module:'Task Management', ip:'192.168.1.12' },
  { id:'a5',  ts:'2026-04-19 16:45:09', userId:'u3', user:'Rakesh Mehta',    role:'Admin',        action:'Flagged ITR-6 Filing as High Priority for Mehta Industries', module:'Task Management', ip:'192.168.1.6' },
  { id:'a6',  ts:'2026-04-19 15:20:33', userId:'u13',user:'Sameer Khan',     role:'Employee',     action:'Flagged TDS Return Q4 as "Pending from Client" — Sharma Tech', module:'Task Management', ip:'192.168.1.15' },
  { id:'a7',  ts:'2026-04-19 14:11:55', userId:'u1', user:'Vinayak Agarwal', role:'Super Master', action:'Designated Arjun Kapoor as Team Lead for GST team [u7, u8, u9]', module:'User Management', ip:'192.168.1.1' },
  { id:'a8',  ts:'2026-04-19 11:05:30', userId:'u4', user:'Sunita Joshi',    role:'Admin',        action:'Onboarded new client: Aashray Foundation Trust (NGO-TRUST-01)', module:'Client Management', ip:'192.168.1.7' },
  { id:'a9',  ts:'2026-04-18 17:00:00', userId:'u6', user:'Deepa Nair',      role:'Team Lead',    action:'Delegated Advance Tax Calculation sub-task to Tarun Bose', module:'Task Management', ip:'192.168.1.9' },
  { id:'a10', ts:'2026-04-18 14:30:11', userId:'u2', user:'Priya Sharma',    role:'Admin',        action:'Added GSTIN 09AABCV7890L1Z0 to Verma Holdings client record', module:'Client Management', ip:'192.168.1.5' },
  { id:'a11', ts:'2026-04-18 10:22:44', userId:'u1', user:'Vinayak Agarwal', role:'Super Master', action:'Modified statutory deadline: GSTR-9 due date updated to Apr 30', module:'Compliance DB', ip:'192.168.1.1' },
  { id:'a12', ts:'2026-04-17 16:55:12', userId:'u5', user:'Arjun Kapoor',    role:'Team Lead',    action:'Reverted GSTR-9 submission with remarks: "Figures mismatch in table 6A"', module:'Task Lifecycle', ip:'192.168.1.8' },
];

return { DEPTS, PRIORITIES, STATUSES, STATUS_LABELS, USERS, CLIENTS, TASKS, COMPLIANCE, AUDIT_LOG };
})();
