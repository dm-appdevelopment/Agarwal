
// ─── Team Management ──────────────────────────────────────────────────────────
function TeamManagement({ currentUser }) {
  const { USERS, TASKS } = window.AppData;
  const [selected, setSelected] = React.useState(null);
  const [tab, setTab] = React.useState('hierarchy');

  const admins = USERS.filter(u => u.role === 'Admin');
  const leads  = USERS.filter(u => u.role === 'Team Lead');
  const emps   = USERS.filter(u => u.role === 'Employee');

  const taskCount = (uid) => TASKS.filter(t => t.assignedTo === uid && t.status !== 'T3').length;
  const completedCount = (uid) => TASKS.filter(t => t.assignedTo === uid && t.status === 'T3').length;

  const roleColor = { 'Super Master':'#1D4ED8', 'Admin':'#7C3AED', 'Team Lead':'#0891B2', 'Employee':'#059669' };
  const roleBg    = { 'Super Master':'#EFF6FF', 'Admin':'#F5F3FF', 'Team Lead':'#ECFEFF', 'Employee':'#F0FDF4' };

  const UserCard = ({ user, indent = 0 }) => {
    const active = selected?.id === user.id;
    return (
      <div style={{marginLeft: indent * 24, marginBottom:4}}>
        <div style={{...tmStyles.userCard, border: active ? '1.5px solid #1D4ED8' : '1px solid #E2E8F0', background: active ? '#EFF6FF' : '#fff'}}
             onClick={() => setSelected(active ? null : user)}>
          <div style={{...tmStyles.avatar, background: roleColor[user.role]}}>{user.avatar}</div>
          <div style={{flex:1}}>
            <div style={{fontWeight:600, fontSize:12, color:'#0F172A'}}>{user.name}</div>
            <div style={{fontSize:10, color:'#64748B'}}>{user.dept}</div>
          </div>
          <span style={{...tmStyles.roleBadge, background: roleBg[user.role], color: roleColor[user.role]}}>{user.role}</span>
          <div style={{display:'flex', gap:6, fontSize:10}}>
            <span style={{color:'#F59E0B', fontWeight:700}}>{taskCount(user.id)} active</span>
            <span style={{color:'#10B981', fontWeight:700}}>{completedCount(user.id)} done</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div style={tmStyles.page}>
      {/* Tab bar */}
      <div style={tmStyles.tabBar}>
        {['hierarchy','table'].map(t => (
          <button key={t} style={{...tmStyles.tab, borderBottom: tab===t ? '2px solid #1D4ED8' : '2px solid transparent', color: tab===t ? '#1D4ED8' : '#64748B'}}
                  onClick={() => setTab(t)}>
            {t === 'hierarchy' ? '⎇ Hierarchy View' : '☰ Table View'}
          </button>
        ))}
      </div>

      <div style={{display:'flex', flex:1, overflow:'hidden'}}>
        <div style={{flex:1, overflowY:'auto', padding:16}}>
          {tab === 'hierarchy' ? (
            <>
              {/* Super Master */}
              <UserCard user={USERS.find(u => u.role === 'Super Master')} />
              <div style={{paddingLeft:12, borderLeft:'2px dashed #E2E8F0', marginLeft:16, marginTop:4}}>
                {admins.map(admin => (
                  <div key={admin.id} style={{marginBottom:12}}>
                    <UserCard user={admin} indent={0} />
                    {/* Team Leads under this Admin's dept */}
                    {leads.filter(l => l.dept === admin.dept).map(lead => (
                      <div key={lead.id} style={{paddingLeft:12, borderLeft:'2px dashed #E2E8F0', marginLeft:24, marginTop:4}}>
                        <UserCard user={lead} indent={0} />
                        {/* Employees under this Team Lead */}
                        {(lead.teamMembers||[]).map(eid => {
                          const emp = USERS.find(u => u.id === eid);
                          return emp ? <UserCard key={emp.id} user={emp} indent={1} /> : null;
                        })}
                      </div>
                    ))}
                    {/* Direct employees not under a lead */}
                    {emps.filter(e => e.dept === admin.dept && !leads.some(l => (l.teamMembers||[]).includes(e.id))).map(emp => (
                      <UserCard key={emp.id} user={emp} indent={1} />
                    ))}
                  </div>
                ))}
                {/* Employees in other depts */}
                {emps.filter(e => !admins.some(a => a.dept === e.dept)).map(emp => (
                  <UserCard key={emp.id} user={emp} indent={0} />
                ))}
              </div>
            </>
          ) : (
            <table style={tmStyles.table}>
              <thead>
                <tr>{['Name','Role','Department','Active Tasks','Completed','Team Lead',''].map(h=>(
                  <th key={h} style={tmStyles.th}>{h}</th>
                ))}</tr>
              </thead>
              <tbody>
                {USERS.map(u => {
                  const lead = USERS.find(l => (l.teamMembers||[]).includes(u.id));
                  return (
                    <tr key={u.id} style={{...tmStyles.tr, background: selected?.id===u.id?'#EFF6FF':undefined}} onClick={()=>setSelected(selected?.id===u.id?null:u)}>
                      <td style={tmStyles.td}>
                        <div style={{display:'flex', alignItems:'center', gap:7}}>
                          <div style={{...tmStyles.avatar, background: roleColor[u.role], width:26, height:26, fontSize:9}}>{u.avatar}</div>
                          <span style={{fontWeight:600}}>{u.name}</span>
                        </div>
                      </td>
                      <td style={tmStyles.td}><span style={{...tmStyles.roleBadge, background:roleBg[u.role], color:roleColor[u.role]}}>{u.role}</span></td>
                      <td style={tmStyles.td}>{u.dept}</td>
                      <td style={{...tmStyles.td, color:'#F59E0B', fontWeight:700}}>{taskCount(u.id)}</td>
                      <td style={{...tmStyles.td, color:'#10B981', fontWeight:700}}>{completedCount(u.id)}</td>
                      <td style={tmStyles.td}>{lead ? lead.name : <span style={{color:'#94A3B8'}}>—</span>}</td>
                      <td style={tmStyles.td} onClick={e=>e.stopPropagation()}>
                        {currentUser.role === 'Super Master' && <button style={tmStyles.editBtn}>Edit</button>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* User detail panel */}
        {selected && (
          <div style={tmStyles.detailPanel}>
            <div style={tmStyles.detailHeader}>
              <div style={{...tmStyles.avatar, background: roleColor[selected.role], width:40, height:40, fontSize:14}}>{selected.avatar}</div>
              <div style={{flex:1}}>
                <div style={{fontWeight:700, fontSize:14, color:'#0F172A'}}>{selected.name}</div>
                <span style={{...tmStyles.roleBadge, background:roleBg[selected.role], color:roleColor[selected.role]}}>{selected.role}</span>
              </div>
              <button onClick={()=>setSelected(null)} style={{background:'none',border:'none',cursor:'pointer',color:'#94A3B8',fontSize:16}}>✕</button>
            </div>
            <div style={{padding:14, display:'flex', flexDirection:'column', gap:10}}>
              {[['Department', selected.dept], ['User ID', selected.id], ['Active Tasks', taskCount(selected.id)], ['Completed Tasks', completedCount(selected.id)]].map(([l,v]) => (
                <div key={l} style={{display:'flex', justifyContent:'space-between', padding:'5px 0', borderBottom:'1px solid #F1F5F9'}}>
                  <span style={{fontSize:11, fontWeight:600, color:'#94A3B8'}}>{l}</span>
                  <span style={{fontSize:12, fontWeight:600, color:'#1E293B'}}>{v}</span>
                </div>
              ))}
              {selected.teamMembers && (
                <div>
                  <div style={{fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', marginBottom:6}}>Team Members</div>
                  {selected.teamMembers.map(eid => {
                    const e = USERS.find(u => u.id === eid);
                    return e ? (
                      <div key={eid} style={{display:'flex', alignItems:'center', gap:6, padding:'4px 0', borderBottom:'1px solid #F8FAFC'}}>
                        <div style={{...tmStyles.avatar, background:'#059669', width:22, height:22, fontSize:8}}>{e.avatar}</div>
                        <span style={{fontSize:12}}>{e.name}</span>
                      </div>
                    ) : null;
                  })}
                </div>
              )}
              {currentUser.role === 'Super Master' && (
                <div style={{display:'flex', flexDirection:'column', gap:6, marginTop:4}}>
                  <button style={{background:'#1D4ED8', color:'#fff', border:'none', borderRadius:6, padding:'7px 12px', fontSize:12, fontWeight:600, cursor:'pointer'}}>Edit Profile</button>
                  <button style={{background:'#FEF2F2', color:'#DC2626', border:'1px solid #FECACA', borderRadius:6, padding:'7px 12px', fontSize:12, fontWeight:600, cursor:'pointer'}}>Deactivate User</button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const tmStyles = {
  page:       { display:'flex', flexDirection:'column', height:'100%', background:'#F8FAFC' },
  tabBar:     { display:'flex', gap:0, background:'#fff', borderBottom:'1px solid #E2E8F0', padding:'0 16px', flexShrink:0 },
  tab:        { padding:'10px 16px', fontSize:12, fontWeight:600, background:'none', border:'none', cursor:'pointer', whiteSpace:'nowrap' },
  userCard:   { display:'flex', alignItems:'center', gap:10, padding:'8px 12px', borderRadius:8, cursor:'pointer', marginBottom:3 },
  avatar:     { width:32, height:32, borderRadius:'50%', color:'#fff', fontSize:11, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 },
  roleBadge:  { padding:'2px 8px', borderRadius:10, fontSize:10, fontWeight:700, whiteSpace:'nowrap' },
  table:      { width:'100%', borderCollapse:'collapse' },
  th:         { padding:'8px 10px', fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em', borderBottom:'1px solid #E2E8F0', textAlign:'left', background:'#FAFAFA', position:'sticky', top:0 },
  tr:         { borderBottom:'1px solid #F1F5F9', cursor:'pointer' },
  td:         { padding:'8px 10px', fontSize:12, color:'#1E293B' },
  editBtn:    { background:'#F1F5F9', border:'1px solid #E2E8F0', borderRadius:4, padding:'2px 8px', fontSize:11, cursor:'pointer', color:'#475569' },
  detailPanel:{ width:280, borderLeft:'1px solid #E2E8F0', background:'#fff', flexShrink:0, overflowY:'auto' },
  detailHeader:{ display:'flex', alignItems:'center', gap:10, padding:'14px', borderBottom:'1px solid #E2E8F0', background:'#F8FAFC' },
};

Object.assign(window, { TeamManagement });
