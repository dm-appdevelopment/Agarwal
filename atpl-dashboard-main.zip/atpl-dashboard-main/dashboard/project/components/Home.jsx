
// ─── Home Dashboard Component ────────────────────────────────────────────────
function HomeDashboard({ currentUser }) {
  const { TASKS, COMPLIANCE, USERS, STATUS_LABELS } = window.AppData;
  const today = '2026-04-20';

  // Filter tasks visible to current user
  const visibleTasks = React.useMemo(() => {
    if (currentUser.role === 'Super Master' || currentUser.role === 'Admin') return TASKS;
    if (currentUser.role === 'Team Lead') {
      const myIds = [currentUser.id, ...(currentUser.teamMembers || [])];
      return TASKS.filter(t => myIds.includes(t.assignedTo));
    }
    return TASKS.filter(t => t.assignedTo === currentUser.id);
  }, [currentUser]);

  const total    = visibleTasks.length;
  const pending  = visibleTasks.filter(t => t.status !== 'T3').length;
  const overdue  = visibleTasks.filter(t => t.status !== 'T3' && t.due < today).length;
  const doneToday= visibleTasks.filter(t => t.status === 'T3' && t.t3 === today).length;
  const highPrio = visibleTasks.filter(t => t.priority === 'High' && t.status !== 'T3').length;

  // Dept breakdown
  const { DEPTS } = window.AppData;
  const deptStats = DEPTS.map(dept => {
    const dt = visibleTasks.filter(t => t.dept === dept);
    return {
      dept,
      total: dt.length,
      done:  dt.filter(t => t.status === 'T3').length,
      wip:   dt.filter(t => t.status === 'T2').length,
      pending: dt.filter(t => t.status === 'T1' || t.status === 'T0').length,
    };
  }).filter(d => d.total > 0);

  // Upcoming deadlines (next 14 days)
  const upcoming = COMPLIANCE
    .filter(c => c.date >= today)
    .sort((a,b) => a.date.localeCompare(b.date))
    .slice(0, 8);

  // Recent tasks
  const recentTasks = [...visibleTasks]
    .sort((a,b) => (b.t1 || b.t0 || '').localeCompare(a.t1 || a.t0 || ''))
    .slice(0, 6);

  const statusColor = { T0:'#94A3B8', T1:'#3B82F6', T2:'#F59E0B', T3:'#10B981' };
  const prioColor   = { High:'#EF4444', Medium:'#F59E0B', Low:'#10B981' };

  const daysUntil = (date) => {
    const diff = Math.ceil((new Date(date) - new Date(today)) / 86400000);
    if (diff < 0) return { label: `${Math.abs(diff)}d overdue`, color: '#EF4444' };
    if (diff === 0) return { label: 'Due today', color: '#F59E0B' };
    return { label: `${diff}d left`, color: diff <= 3 ? '#F97316' : '#64748B' };
  };

  return (
    <div style={homeStyles.page}>
      {/* KPI Row */}
      <div style={homeStyles.kpiRow}>
        {[
          { label:'Total Tasks',    value: total,     color:'#1D4ED8', bg:'#EFF6FF' },
          { label:'Pending',        value: pending,   color:'#F59E0B', bg:'#FFFBEB' },
          { label:'Overdue',        value: overdue,   color:'#EF4444', bg:'#FEF2F2' },
          { label:'High Priority',  value: highPrio,  color:'#DC2626', bg:'#FEF2F2' },
          { label:'Approved Today', value: doneToday, color:'#10B981', bg:'#F0FDF4' },
        ].map(k => (
          <div key={k.label} style={{...homeStyles.kpiCard, background: k.bg}}>
            <div style={{...homeStyles.kpiValue, color: k.color}}>{k.value}</div>
            <div style={homeStyles.kpiLabel}>{k.label}</div>
          </div>
        ))}
      </div>

      <div style={homeStyles.twoCol}>
        {/* Dept breakdown */}
        <div style={homeStyles.card}>
          <div style={homeStyles.cardHeader}>Department Workload</div>
          <table style={homeStyles.table}>
            <thead>
              <tr>
                {['Department','Total','Pending','In Progress','Approved'].map(h => (
                  <th key={h} style={homeStyles.th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {deptStats.map(d => (
                <tr key={d.dept} style={homeStyles.tr}>
                  <td style={homeStyles.td}>
                    <span style={{...homeStyles.deptBadge, background: deptBgColor(d.dept)}}>{d.dept}</span>
                  </td>
                  <td style={{...homeStyles.td, textAlign:'center', fontWeight:600}}>{d.total}</td>
                  <td style={{...homeStyles.td, textAlign:'center', color:'#F59E0B'}}>{d.pending}</td>
                  <td style={{...homeStyles.td, textAlign:'center', color:'#3B82F6'}}>{d.wip}</td>
                  <td style={{...homeStyles.td, textAlign:'center', color:'#10B981'}}>{d.done}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Upcoming deadlines */}
        <div style={homeStyles.card}>
          <div style={homeStyles.cardHeader}>Upcoming Deadlines</div>
          <div style={{overflowY:'auto', maxHeight:260}}>
            {upcoming.map(c => {
              const du = daysUntil(c.date);
              return (
                <div key={c.id} style={homeStyles.deadlineRow}>
                  <div style={{flex:1}}>
                    <div style={homeStyles.deadlineType}>{c.type}</div>
                    <div style={homeStyles.deadlineSub}>{c.period} · <span style={{...homeStyles.deptBadge, background: deptBgColor(c.dept), fontSize:10}}>{c.dept}</span></div>
                  </div>
                  <div style={{textAlign:'right'}}>
                    <div style={{fontSize:11, fontWeight:700, color: du.color}}>{du.label}</div>
                    <div style={{fontSize:10, color:'#94A3B8'}}>{c.date}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent Task Activity */}
      <div style={homeStyles.card}>
        <div style={homeStyles.cardHeader}>Recent Task Activity</div>
        <table style={homeStyles.table}>
          <thead>
            <tr>
              {['Client','Task Type','Department','Assigned To','Priority','Status','Due Date'].map(h => (
                <th key={h} style={homeStyles.th}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {recentTasks.map(t => {
              const du = daysUntil(t.due);
              const emp = USERS.find(u => u.id === t.assignedTo);
              return (
                <tr key={t.id} style={homeStyles.tr}>
                  <td style={homeStyles.td}>{t.clientName.length > 22 ? t.clientName.slice(0,22)+'…' : t.clientName}</td>
                  <td style={homeStyles.td}>{t.type}</td>
                  <td style={homeStyles.td}><span style={{...homeStyles.deptBadge, background: deptBgColor(t.dept)}}>{t.dept}</span></td>
                  <td style={homeStyles.td}>{emp ? emp.name : '—'}</td>
                  <td style={homeStyles.td}><span style={{...homeStyles.badge, background: prioColor[t.priority]+'22', color: prioColor[t.priority]}}>{t.priority}</span></td>
                  <td style={homeStyles.td}><span style={{...homeStyles.statusBadge, background: statusColor[t.status]+'22', color: statusColor[t.status], borderColor: statusColor[t.status]+'44'}}>{t.status} · {STATUS_LABELS[t.status]}</span></td>
                  <td style={{...homeStyles.td, color: du.color, fontWeight:600, fontSize:11}}>{du.label}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function deptBgColor(dept) {
  const map = { GST:'#DBEAFE', 'Income Tax':'#D1FAE5', Audit:'#FEF3C7', TDS:'#EDE9FE', 'Company Law':'#FCE7F3', NGO:'#DCFCE7', Accounts:'#F1F5F9' };
  return map[dept] || '#F1F5F9';
}

const homeStyles = {
  page:       { display:'flex', flexDirection:'column', gap:16, padding:'20px 24px' },
  kpiRow:     { display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:12 },
  kpiCard:    { borderRadius:8, padding:'14px 16px', border:'1px solid #E2E8F0' },
  kpiValue:   { fontSize:28, fontWeight:700, lineHeight:1 },
  kpiLabel:   { fontSize:11, color:'#64748B', marginTop:4, fontWeight:500, textTransform:'uppercase', letterSpacing:'0.04em' },
  twoCol:     { display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 },
  card:       { background:'#fff', borderRadius:8, border:'1px solid #E2E8F0', overflow:'hidden' },
  cardHeader: { padding:'10px 14px', fontSize:12, fontWeight:700, color:'#0A1628', borderBottom:'1px solid #E2E8F0', textTransform:'uppercase', letterSpacing:'0.05em', background:'#F8FAFC' },
  table:      { width:'100%', borderCollapse:'collapse' },
  th:         { padding:'7px 10px', fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em', borderBottom:'1px solid #E2E8F0', textAlign:'left', background:'#FAFAFA' },
  tr:         { borderBottom:'1px solid #F1F5F9', transition:'background 0.1s' },
  td:         { padding:'7px 10px', fontSize:12, color:'#1E293B' },
  badge:      { padding:'2px 7px', borderRadius:4, fontSize:11, fontWeight:600 },
  statusBadge:{ padding:'2px 7px', borderRadius:4, fontSize:10, fontWeight:700, border:'1px solid', whiteSpace:'nowrap' },
  deptBadge:  { padding:'2px 6px', borderRadius:4, fontSize:11, fontWeight:600, color:'#1E293B' },
  deadlineRow:{ display:'flex', alignItems:'center', padding:'8px 14px', borderBottom:'1px solid #F1F5F9' },
  deadlineType:{ fontSize:12, fontWeight:600, color:'#0F172A' },
  deadlineSub: { fontSize:11, color:'#64748B', marginTop:2, display:'flex', alignItems:'center', gap:6 },
};

Object.assign(window, { HomeDashboard, deptBgColor });
