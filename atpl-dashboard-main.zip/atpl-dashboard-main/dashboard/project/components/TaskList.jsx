
// ─── Task List & Detail Component ────────────────────────────────────────────
function TaskList({ currentUser }) {
  const { TASKS, USERS, STATUS_LABELS } = window.AppData;
  const [filters, setFilters] = React.useState({ dept:'', priority:'', status:'', search:'' });
  const [selected, setSelected] = React.useState(null);
  const [showNew, setShowNew] = React.useState(false);
  const today = '2026-04-20';

  const statusColor = { T0:'#94A3B8', T1:'#3B82F6', T2:'#F59E0B', T3:'#10B981' };
  const prioColor   = { High:'#EF4444', Medium:'#F59E0B', Low:'#10B981' };

  const visibleTasks = React.useMemo(() => {
    let tasks = TASKS;
    if (currentUser.role === 'Team Lead') {
      const myIds = [currentUser.id, ...(currentUser.teamMembers || [])];
      tasks = tasks.filter(t => myIds.includes(t.assignedTo));
    } else if (currentUser.role === 'Employee') {
      tasks = tasks.filter(t => t.assignedTo === currentUser.id);
    }
    if (filters.dept)     tasks = tasks.filter(t => t.dept === filters.dept);
    if (filters.priority) tasks = tasks.filter(t => t.priority === filters.priority);
    if (filters.status)   tasks = tasks.filter(t => t.status === filters.status);
    if (filters.search)   tasks = tasks.filter(t =>
      t.clientName.toLowerCase().includes(filters.search.toLowerCase()) ||
      t.type.toLowerCase().includes(filters.search.toLowerCase())
    );
    return tasks;
  }, [currentUser, filters]);

  const daysUntil = (date) => {
    const diff = Math.ceil((new Date(date) - new Date(today)) / 86400000);
    if (diff < 0) return { label:`${Math.abs(diff)}d overdue`, color:'#EF4444' };
    if (diff === 0) return { label:'Due today', color:'#F59E0B' };
    return { label:`In ${diff}d`, color: diff <= 3 ? '#F97316' : '#64748B' };
  };

  const canAdvance = (task) => {
    if (currentUser.role === 'Super Master' || currentUser.role === 'Admin') return true;
    if (currentUser.role === 'Team Lead' && task.assignedTo !== currentUser.id) return true;
    return task.assignedTo === currentUser.id;
  };

  const nextStatus = { T0:'T1', T1:'T2', T2:'T3' };

  return (
    <div style={tlStyles.page}>
      {/* Toolbar */}
      <div style={tlStyles.toolbar}>
        <div style={tlStyles.searchWrap}>
          <span style={tlStyles.searchIcon}>⌕</span>
          <input style={tlStyles.searchInput} placeholder="Search client or task…"
            value={filters.search} onChange={e => setFilters(f => ({...f, search: e.target.value}))} />
        </div>
        <select style={tlStyles.select} value={filters.dept} onChange={e => setFilters(f => ({...f, dept: e.target.value}))}>
          <option value="">All Departments</option>
          {window.AppData.DEPTS.map(d => <option key={d}>{d}</option>)}
        </select>
        <select style={tlStyles.select} value={filters.priority} onChange={e => setFilters(f => ({...f, priority: e.target.value}))}>
          <option value="">All Priorities</option>
          {['High','Medium','Low'].map(p => <option key={p}>{p}</option>)}
        </select>
        <select style={tlStyles.select} value={filters.status} onChange={e => setFilters(f => ({...f, status: e.target.value}))}>
          <option value="">All Statuses</option>
          {['T0','T1','T2','T3'].map(s => <option key={s} value={s}>{s} – {window.AppData.STATUS_LABELS[s]}</option>)}
        </select>
        <div style={{flex:1}} />
        <span style={tlStyles.countBadge}>{visibleTasks.length} tasks</span>
        {(currentUser.role === 'Admin' || currentUser.role === 'Super Master' || currentUser.role === 'Team Lead') && (
          <button style={tlStyles.newBtn} onClick={() => setShowNew(true)}>+ Assign Task</button>
        )}
      </div>

      {/* Table */}
      <div style={tlStyles.tableWrap}>
        <table style={tlStyles.table}>
          <thead>
            <tr>
              {['Client','Task Type','Dept','Assigned To','Priority','Status','T-Stamps','Due',''].map(h => (
                <th key={h} style={tlStyles.th}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visibleTasks.map(t => {
              const emp = USERS.find(u => u.id === t.assignedTo);
              const du = daysUntil(t.due);
              const isSelected = selected?.id === t.id;
              return (
                <tr key={t.id} style={{...tlStyles.tr, background: isSelected ? '#EFF6FF' : undefined}}
                    onClick={() => setSelected(isSelected ? null : t)}>
                  <td style={tlStyles.td}>
                    <div style={{fontWeight:600, fontSize:12}}>{t.clientName.length>22 ? t.clientName.slice(0,22)+'…' : t.clientName}</div>
                  </td>
                  <td style={tlStyles.td}>{t.type}</td>
                  <td style={tlStyles.td}><span style={{...tlStyles.deptBadge, background: window.deptBgColor(t.dept)}}>{t.dept}</span></td>
                  <td style={tlStyles.td}>
                    <div style={{display:'flex', alignItems:'center', gap:5}}>
                      <div style={tlStyles.avatar}>{emp?.avatar||'??'}</div>
                      <span style={{fontSize:11}}>{emp?.name||'—'}</span>
                    </div>
                  </td>
                  <td style={tlStyles.td}><span style={{...tlStyles.badge, background:prioColor[t.priority]+'22', color:prioColor[t.priority]}}>{t.priority}</span></td>
                  <td style={tlStyles.td}><span style={{...tlStyles.sBadge, background:statusColor[t.status]+'18', color:statusColor[t.status], border:`1px solid ${statusColor[t.status]}44`}}>{t.status}</span></td>
                  <td style={tlStyles.td}>
                    <div style={tlStyles.stamps}>
                      {['t0','t1','t2','t3'].map((s,i) => (
                        <div key={s} style={{...tlStyles.stamp, background: t[s] ? statusColor[`T${i}`] : '#E2E8F0', color: t[s] ? '#fff' : '#94A3B8'}} title={t[s] || 'Not yet'}>T{i}</div>
                      ))}
                    </div>
                  </td>
                  <td style={{...tlStyles.td, color:du.color, fontWeight:700, fontSize:11, whiteSpace:'nowrap'}}>{du.label}</td>
                  <td style={tlStyles.td} onClick={e => e.stopPropagation()}>
                    {t.status !== 'T3' && canAdvance(t) && (
                      <button style={tlStyles.advBtn} title={`Advance to ${nextStatus[t.status]}`}>
                        ▶ {nextStatus[t.status]}
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
            {visibleTasks.length === 0 && (
              <tr><td colSpan={9} style={{textAlign:'center', padding:32, color:'#94A3B8', fontSize:13}}>No tasks match the current filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Detail Panel */}
      {selected && <TaskDetail task={selected} currentUser={currentUser} onClose={() => setSelected(null)} />}

      {/* New Task Modal */}
      {showNew && <AssignTaskModal currentUser={currentUser} onClose={() => setShowNew(false)} />}
    </div>
  );
}

function TaskDetail({ task, currentUser, onClose }) {
  const { USERS, STATUS_LABELS } = window.AppData;
  const statusColor = { T0:'#94A3B8', T1:'#3B82F6', T2:'#F59E0B', T3:'#10B981' };
  const prioColor   = { High:'#EF4444', Medium:'#F59E0B', Low:'#10B981' };
  const emp  = USERS.find(u => u.id === task.assignedTo);
  const assigner = USERS.find(u => u.id === task.assignedBy);

  return (
    <div style={tlStyles.detailOverlay} onClick={onClose}>
      <div style={tlStyles.detailPanel} onClick={e => e.stopPropagation()}>
        <div style={tlStyles.detailHeader}>
          <div>
            <div style={{fontSize:14, fontWeight:700, color:'#0F172A'}}>{task.type}</div>
            <div style={{fontSize:11, color:'#64748B', marginTop:2}}>{task.clientName}</div>
          </div>
          <button onClick={onClose} style={tlStyles.closeBtn}>✕</button>
        </div>

        <div style={tlStyles.detailBody}>
          {/* Status badges */}
          <div style={{display:'flex', gap:8, marginBottom:16, flexWrap:'wrap'}}>
            <span style={{...tlStyles.sBadge, background:statusColor[task.status]+'18', color:statusColor[task.status], border:`1px solid ${statusColor[task.status]}44`, padding:'4px 10px', fontSize:12}}>{task.status} · {STATUS_LABELS[task.status]}</span>
            <span style={{...tlStyles.badge, background:prioColor[task.priority]+'22', color:prioColor[task.priority], padding:'4px 10px', fontSize:12}}>{task.priority} Priority</span>
            <span style={{...tlStyles.deptBadge, background:window.deptBgColor(task.dept), padding:'4px 10px', fontSize:12}}>{task.dept}</span>
          </div>

          {/* Four-stamp timeline */}
          <div style={tlStyles.stampSection}>
            <div style={{fontSize:11, fontWeight:700, color:'#64748B', marginBottom:8, textTransform:'uppercase', letterSpacing:'0.05em'}}>Task Lifecycle</div>
            <div style={{display:'flex', gap:0}}>
              {[
                {key:'T0', label:'Received', val:task.t0, desc:'Client request received'},
                {key:'T1', label:'Allocated', val:task.t1, desc:'Task assigned'},
                {key:'T2', label:'In Progress', val:task.t2, desc:'Work submitted for review'},
                {key:'T3', label:'Approved', val:task.t3, desc:'Final approval granted'},
              ].map((s, i) => (
                <div key={s.key} style={{flex:1, textAlign:'center', position:'relative'}}>
                  {i > 0 && <div style={{position:'absolute', left:0, top:14, width:'50%', height:2, background: task[s.key.toLowerCase()] ? statusColor[s.key] : '#E2E8F0'}} />}
                  {i < 3 && <div style={{position:'absolute', right:0, top:14, width:'50%', height:2, background: task[['t0','t1','t2','t3'][i+1]] ? statusColor[['T0','T1','T2','T3'][i+1]] : '#E2E8F0'}} />}
                  <div style={{...tlStyles.stampCircle, background: task[s.key.toLowerCase()] ? statusColor[s.key] : '#E2E8F0', color: task[s.key.toLowerCase()] ? '#fff' : '#94A3B8', margin:'0 auto'}}>{s.key}</div>
                  <div style={{fontSize:10, fontWeight:700, color: task[s.key.toLowerCase()] ? statusColor[s.key] : '#94A3B8', marginTop:4}}>{s.label}</div>
                  <div style={{fontSize:10, color:'#94A3B8', marginTop:1}}>{task[s.key.toLowerCase()] || '—'}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Info rows */}
          <div style={tlStyles.infoGrid}>
            {[
              ['Assigned To',   emp?.name || '—'],
              ['Assigned By',   assigner?.name || '—'],
              ['Due Date',      task.due],
              ['Department',    task.dept],
              ['Remarks',       task.remarks || 'None'],
            ].map(([label, val]) => (
              <div key={label} style={tlStyles.infoRow}>
                <span style={tlStyles.infoLabel}>{label}</span>
                <span style={tlStyles.infoVal}>{val}</span>
              </div>
            ))}
          </div>

          {/* Actions */}
          {task.status !== 'T3' && (
            <div style={{marginTop:16, display:'flex', gap:8}}>
              {task.status !== 'T3' && <button style={tlStyles.actionBtn}>▶ Advance Status</button>}
              <button style={{...tlStyles.actionBtn, background:'#FEF2F2', color:'#DC2626', border:'1px solid #FECACA'}}>⚑ Pending from Client</button>
              {(currentUser.role === 'Admin' || currentUser.role === 'Super Master') && (
                <button style={{...tlStyles.actionBtn, background:'#FFFBEB', color:'#D97706', border:'1px solid #FDE68A'}}>↩ Revert with Remarks</button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AssignTaskModal({ currentUser, onClose }) {
  const { CLIENTS, USERS, DEPTS } = window.AppData;
  return (
    <div style={tlStyles.detailOverlay} onClick={onClose}>
      <div style={{...tlStyles.detailPanel, width:480, maxHeight:'80vh', overflowY:'auto'}} onClick={e=>e.stopPropagation()}>
        <div style={tlStyles.detailHeader}>
          <div style={{fontSize:14, fontWeight:700}}>Assign New Task</div>
          <button onClick={onClose} style={tlStyles.closeBtn}>✕</button>
        </div>
        <div style={{padding:16, display:'flex', flexDirection:'column', gap:12}}>
          {[
            {label:'Client', type:'select', opts: CLIENTS.map(c => c.name)},
            {label:'Task Type', type:'text', placeholder:'e.g. GSTR-3B Filing'},
            {label:'Department', type:'select', opts: DEPTS},
            {label:'Assign To', type:'select', opts: USERS.filter(u => u.role === 'Employee' || u.role === 'Team Lead').map(u => u.name)},
            {label:'Priority', type:'select', opts:['High','Medium','Low']},
            {label:'Due Date', type:'date'},
            {label:'T₀ (Client Request Date)', type:'date'},
            {label:'Remarks', type:'textarea'},
          ].map(f => (
            <div key={f.label}>
              <label style={{fontSize:11, fontWeight:600, color:'#64748B', textTransform:'uppercase', letterSpacing:'0.04em', display:'block', marginBottom:4}}>{f.label}</label>
              {f.type === 'select' ? (
                <select style={tlStyles.modalInput}><option value="">Select…</option>{f.opts?.map(o=><option key={o}>{o}</option>)}</select>
              ) : f.type === 'textarea' ? (
                <textarea style={{...tlStyles.modalInput, height:60, resize:'vertical'}} placeholder="Optional remarks…" />
              ) : (
                <input type={f.type} style={tlStyles.modalInput} placeholder={f.placeholder} />
              )}
            </div>
          ))}
          <div style={{display:'flex', gap:8, marginTop:4}}>
            <button style={tlStyles.newBtn}>Assign Task</button>
            <button style={{...tlStyles.newBtn, background:'#F1F5F9', color:'#475569', border:'1px solid #E2E8F0'}} onClick={onClose}>Cancel</button>
          </div>
        </div>
      </div>
    </div>
  );
}

const tlStyles = {
  page:      { display:'flex', flexDirection:'column', height:'100%', background:'#F8FAFC' },
  toolbar:   { display:'flex', alignItems:'center', gap:8, padding:'10px 16px', background:'#fff', borderBottom:'1px solid #E2E8F0', flexShrink:0 },
  searchWrap:{ position:'relative', flex:'0 0 220px' },
  searchIcon:{ position:'absolute', left:8, top:'50%', transform:'translateY(-50%)', color:'#94A3B8', fontSize:16 },
  searchInput:{ width:'100%', border:'1px solid #E2E8F0', borderRadius:6, padding:'5px 8px 5px 26px', fontSize:12, outline:'none', boxSizing:'border-box' },
  select:    { border:'1px solid #E2E8F0', borderRadius:6, padding:'5px 8px', fontSize:12, color:'#475569', background:'#fff', outline:'none' },
  countBadge:{ fontSize:11, color:'#94A3B8', fontWeight:600 },
  newBtn:    { background:'#1D4ED8', color:'#fff', border:'none', borderRadius:6, padding:'6px 14px', fontSize:12, fontWeight:600, cursor:'pointer' },
  tableWrap: { flex:1, overflowY:'auto' },
  table:     { width:'100%', borderCollapse:'collapse' },
  th:        { padding:'8px 10px', fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em', borderBottom:'1px solid #E2E8F0', textAlign:'left', background:'#FAFAFA', position:'sticky', top:0, zIndex:1 },
  tr:        { borderBottom:'1px solid #F1F5F9', cursor:'pointer' },
  td:        { padding:'8px 10px', fontSize:12, color:'#1E293B' },
  badge:     { padding:'2px 7px', borderRadius:4, fontSize:11, fontWeight:600 },
  sBadge:    { padding:'2px 7px', borderRadius:4, fontSize:10, fontWeight:700, whiteSpace:'nowrap' },
  deptBadge: { padding:'2px 6px', borderRadius:4, fontSize:11, fontWeight:600, color:'#1E293B' },
  avatar:    { width:22, height:22, borderRadius:'50%', background:'#1D4ED8', color:'#fff', fontSize:9, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 },
  stamps:    { display:'flex', gap:3 },
  stamp:     { width:18, height:18, borderRadius:'50%', fontSize:9, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center' },
  advBtn:    { background:'#EFF6FF', color:'#1D4ED8', border:'1px solid #BFDBFE', borderRadius:4, padding:'3px 8px', fontSize:10, fontWeight:700, cursor:'pointer', whiteSpace:'nowrap' },
  detailOverlay: { position:'fixed', inset:0, background:'rgba(0,0,0,0.3)', zIndex:50, display:'flex', justifyContent:'flex-end' },
  detailPanel:   { background:'#fff', width:440, height:'100%', display:'flex', flexDirection:'column', boxShadow:'-4px 0 24px rgba(0,0,0,0.1)', overflowY:'auto' },
  detailHeader:  { display:'flex', justifyContent:'space-between', alignItems:'flex-start', padding:'16px', borderBottom:'1px solid #E2E8F0', flexShrink:0 },
  detailBody:    { padding:16, flex:1 },
  closeBtn:      { background:'none', border:'none', fontSize:16, cursor:'pointer', color:'#94A3B8', padding:2 },
  stampSection:  { background:'#F8FAFC', borderRadius:8, padding:12, marginBottom:16 },
  stampCircle:   { width:30, height:30, borderRadius:'50%', fontSize:10, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', position:'relative', zIndex:1 },
  infoGrid:      { display:'flex', flexDirection:'column', gap:0, border:'1px solid #E2E8F0', borderRadius:8, overflow:'hidden' },
  infoRow:       { display:'flex', padding:'8px 12px', borderBottom:'1px solid #F1F5F9' },
  infoLabel:     { width:150, fontSize:11, fontWeight:600, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.04em' },
  infoVal:       { fontSize:12, color:'#1E293B', fontWeight:500 },
  actionBtn:     { background:'#EFF6FF', color:'#1D4ED8', border:'1px solid #BFDBFE', borderRadius:6, padding:'6px 12px', fontSize:12, fontWeight:600, cursor:'pointer' },
  modalInput:    { width:'100%', border:'1px solid #E2E8F0', borderRadius:6, padding:'6px 10px', fontSize:12, outline:'none', boxSizing:'border-box', background:'#FAFAFA' },
};

Object.assign(window, { TaskList });
