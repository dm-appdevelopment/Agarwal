
// ─── Audit Trail ──────────────────────────────────────────────────────────────
function AuditTrail({ currentUser }) {
  const { AUDIT_LOG, USERS } = window.AppData;
  const [search, setSearch] = React.useState('');
  const [roleFilter, setRoleFilter] = React.useState('');
  const [moduleFilter, setModuleFilter] = React.useState('');

  const modules = [...new Set(AUDIT_LOG.map(a => a.module))];
  const roles   = [...new Set(AUDIT_LOG.map(a => a.role))];

  const filtered = AUDIT_LOG.filter(a => {
    if (roleFilter && a.role !== roleFilter) return false;
    if (moduleFilter && a.module !== moduleFilter) return false;
    if (search && !a.action.toLowerCase().includes(search.toLowerCase()) && !a.user.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const roleColor = { 'Super Master':'#1D4ED8', 'Admin':'#7C3AED', 'Team Lead':'#0891B2', 'Employee':'#059669' };
  const roleBg    = { 'Super Master':'#EFF6FF', 'Admin':'#F5F3FF', 'Team Lead':'#ECFEFF', 'Employee':'#F0FDF4' };
  const modColor  = { 'User Management':'#F59E0B', 'Task Management':'#3B82F6', 'Task Lifecycle':'#10B981', 'Client Management':'#8B5CF6', 'Compliance DB':'#EC4899' };

  return (
    <div style={auditStyles.page}>
      {/* Toolbar */}
      <div style={auditStyles.toolbar}>
        <div style={{position:'relative', flex:'0 0 260px'}}>
          <span style={{position:'absolute', left:8, top:'50%', transform:'translateY(-50%)', color:'#94A3B8', fontSize:16}}>⌕</span>
          <input style={auditStyles.searchInput} placeholder="Search action or user…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select style={auditStyles.select} value={roleFilter} onChange={e => setRoleFilter(e.target.value)}>
          <option value="">All Roles</option>
          {roles.map(r => <option key={r}>{r}</option>)}
        </select>
        <select style={auditStyles.select} value={moduleFilter} onChange={e => setModuleFilter(e.target.value)}>
          <option value="">All Modules</option>
          {modules.map(m => <option key={m}>{m}</option>)}
        </select>
        <div style={{flex:1}} />
        <div style={{fontSize:11, color:'#94A3B8', fontWeight:600}}>{filtered.length} entries</div>
        <div style={{background:'#FEF2F2', border:'1px solid #FECACA', borderRadius:6, padding:'5px 10px', fontSize:11, color:'#DC2626', fontWeight:600}}>
          🔒 Read-only · Immutable
        </div>
      </div>

      {/* Table */}
      <div style={{flex:1, overflowY:'auto'}}>
        <table style={auditStyles.table}>
          <thead>
            <tr>
              {['Timestamp','User','Role','Module','Action','IP Address'].map(h => (
                <th key={h} style={auditStyles.th}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((a, i) => (
              <tr key={a.id} style={{...auditStyles.tr, background: i % 2 === 0 ? '#fff' : '#FAFAFA'}}>
                <td style={{...auditStyles.td, fontFamily:'monospace', fontSize:11, whiteSpace:'nowrap', color:'#475569'}}>{a.ts}</td>
                <td style={auditStyles.td}>
                  <div style={{fontWeight:600, fontSize:12}}>{a.user}</div>
                </td>
                <td style={auditStyles.td}>
                  <span style={{...auditStyles.badge, background:roleBg[a.role]||'#F1F5F9', color:roleColor[a.role]||'#64748B'}}>{a.role}</span>
                </td>
                <td style={auditStyles.td}>
                  <span style={{...auditStyles.modBadge, background:(modColor[a.module]||'#64748B')+'18', color:modColor[a.module]||'#64748B', border:`1px solid ${(modColor[a.module]||'#64748B')}33`}}>{a.module}</span>
                </td>
                <td style={{...auditStyles.td, maxWidth:380, fontSize:12, color:'#1E293B'}}>{a.action}</td>
                <td style={{...auditStyles.td, fontFamily:'monospace', fontSize:11, color:'#94A3B8'}}>{a.ip}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const auditStyles = {
  page:       { display:'flex', flexDirection:'column', height:'100%', background:'#F8FAFC' },
  toolbar:    { display:'flex', alignItems:'center', gap:8, padding:'10px 16px', background:'#fff', borderBottom:'1px solid #E2E8F0', flexShrink:0 },
  searchInput:{ width:'100%', border:'1px solid #E2E8F0', borderRadius:6, padding:'5px 8px 5px 26px', fontSize:12, outline:'none', boxSizing:'border-box' },
  select:     { border:'1px solid #E2E8F0', borderRadius:6, padding:'5px 8px', fontSize:12, color:'#475569', background:'#fff', outline:'none' },
  table:      { width:'100%', borderCollapse:'collapse' },
  th:         { padding:'8px 10px', fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em', borderBottom:'1px solid #E2E8F0', textAlign:'left', background:'#FAFAFA', position:'sticky', top:0 },
  tr:         { borderBottom:'1px solid #F1F5F9' },
  td:         { padding:'8px 10px', fontSize:12, color:'#1E293B', verticalAlign:'middle' },
  badge:      { padding:'2px 7px', borderRadius:10, fontSize:10, fontWeight:700 },
  modBadge:   { padding:'2px 7px', borderRadius:4, fontSize:10, fontWeight:700 },
};

// ─── Settings / User Management ───────────────────────────────────────────────
function Settings({ currentUser }) {
  const { USERS, DEPTS } = window.AppData;
  const [activeTab, setActiveTab] = React.useState('users');
  const [showNewUser, setShowNewUser] = React.useState(false);

  const roleColor = { 'Super Master':'#1D4ED8', 'Admin':'#7C3AED', 'Team Lead':'#0891B2', 'Employee':'#059669' };
  const roleBg    = { 'Super Master':'#EFF6FF', 'Admin':'#F5F3FF', 'Team Lead':'#ECFEFF', 'Employee':'#F0FDF4' };

  const tabs = [
    { id:'users', label:'User Management' },
    { id:'departments', label:'Departments' },
    { id:'compliance-db', label:'Compliance DB' },
    { id:'system', label:'System Config' },
  ];

  return (
    <div style={settStyles.page}>
      <div style={settStyles.tabBar}>
        {tabs.map(t => (
          <button key={t.id} style={{...settStyles.tab, borderBottom: activeTab===t.id ? '2px solid #1D4ED8' : '2px solid transparent', color: activeTab===t.id ? '#1D4ED8' : '#64748B'}}
                  onClick={() => setActiveTab(t.id)}>{t.label}</button>
        ))}
      </div>

      <div style={{flex:1, overflowY:'auto', padding:20}}>
        {activeTab === 'users' && (
          <div>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12}}>
              <div style={{fontSize:13, fontWeight:700, color:'#0F172A'}}>User Accounts <span style={{fontSize:11, fontWeight:400, color:'#64748B'}}>({USERS.length} total)</span></div>
              {currentUser.role === 'Super Master' && (
                <button style={settStyles.newBtn} onClick={() => setShowNewUser(true)}>+ Create User</button>
              )}
            </div>
            <table style={settStyles.table}>
              <thead>
                <tr>{['Name','Avatar','Role','Department','User ID','Team Lead','Actions'].map(h=>(
                  <th key={h} style={settStyles.th}>{h}</th>
                ))}</tr>
              </thead>
              <tbody>
                {USERS.map(u => {
                  const lead = USERS.find(l => (l.teamMembers||[]).includes(u.id));
                  return (
                    <tr key={u.id} style={settStyles.tr}>
                      <td style={{...settStyles.td, fontWeight:600}}>{u.name}</td>
                      <td style={settStyles.td}><div style={{width:28, height:28, borderRadius:'50%', background:roleColor[u.role], color:'#fff', fontSize:9, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center'}}>{u.avatar}</div></td>
                      <td style={settStyles.td}><span style={{padding:'2px 8px', borderRadius:10, fontSize:10, fontWeight:700, background:roleBg[u.role], color:roleColor[u.role]}}>{u.role}</span></td>
                      <td style={settStyles.td}>{u.dept}</td>
                      <td style={{...settStyles.td, fontFamily:'monospace', fontSize:11, color:'#64748B'}}>{u.id}</td>
                      <td style={settStyles.td}>{lead ? lead.name : <span style={{color:'#94A3B8'}}>—</span>}</td>
                      <td style={settStyles.td} onClick={e=>e.stopPropagation()}>
                        <div style={{display:'flex', gap:4}}>
                          {currentUser.role === 'Super Master' && <>
                            <button style={settStyles.editBtn}>Edit</button>
                            <button style={{...settStyles.editBtn, color:'#DC2626', borderColor:'#FECACA'}}>Disable</button>
                          </>}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'departments' && (
          <div>
            <div style={{fontSize:13, fontWeight:700, color:'#0F172A', marginBottom:12}}>Department Configuration</div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12}}>
              {DEPTS.map(dept => {
                const deptUsers = USERS.filter(u => u.dept === dept);
                return (
                  <div key={dept} style={{background:'#fff', border:'1px solid #E2E8F0', borderRadius:8, padding:14}}>
                    <div style={{display:'flex', alignItems:'center', gap:8, marginBottom:10}}>
                      <div style={{width:10, height:10, borderRadius:2, background: window.deptBgColor(dept) === '#F1F5F9' ? '#94A3B8' : '#1D4ED8'}} />
                      <span style={{fontWeight:700, fontSize:13}}>{dept}</span>
                    </div>
                    <div style={{fontSize:11, color:'#64748B', marginBottom:6}}>{deptUsers.length} staff assigned</div>
                    {deptUsers.map(u => (
                      <div key={u.id} style={{display:'flex', alignItems:'center', gap:6, padding:'3px 0', borderTop:'1px solid #F8FAFC', fontSize:11}}>
                        <span style={{width:16, height:16, borderRadius:'50%', background:'#1D4ED8', color:'#fff', fontSize:8, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0}}>{u.avatar.slice(0,1)}</span>
                        <span>{u.name}</span>
                        <span style={{marginLeft:'auto', color:'#94A3B8', fontSize:10}}>{u.role === 'Admin' ? 'Head' : u.role === 'Team Lead' ? 'Lead' : ''}</span>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'compliance-db' && (
          <div>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12}}>
              <div style={{fontSize:13, fontWeight:700, color:'#0F172A'}}>Statutory Deadline Database</div>
              {currentUser.role === 'Super Master' && <button style={settStyles.newBtn}>+ Add Filing Type</button>}
            </div>
            <div style={{background:'#FEF2F2', border:'1px solid #FECACA', borderRadius:8, padding:'10px 14px', marginBottom:12, fontSize:12, color:'#DC2626', display:'flex', gap:8, alignItems:'center'}}>
              <span>⚠</span> All modifications to this database are recorded in the Audit Trail and attributed to your account.
            </div>
            {[
              {filing:'GSTR-3B', dept:'GST', freq:'Monthly', day:'20th', note:'Due on 20th of following month'},
              {filing:'GSTR-1', dept:'GST', freq:'Monthly', day:'11th', note:'Due on 11th of following month'},
              {filing:'GSTR-9', dept:'GST', freq:'Annual', day:'Dec 31', note:'Annual return by 31st December'},
              {filing:'TDS 26Q/24Q', dept:'TDS', freq:'Quarterly', day:'31st', note:'Last day of month after quarter end'},
              {filing:'Advance Tax', dept:'Income Tax', freq:'Quarterly', day:'15th', note:'Jun 15, Sep 15, Dec 15, Mar 15'},
              {filing:'ITR-6', dept:'Income Tax', freq:'Annual', day:'Oct 31', note:'Companies (non-audit)'},
              {filing:'MGT-7', dept:'Company Law', freq:'Annual', day:'60 days', note:'From AGM date'},
              {filing:'DIR-3 KYC', dept:'Company Law', freq:'Annual', day:'Sep 30', note:'Director KYC by 30 Sep'},
            ].map(row => (
              <div key={row.filing} style={{display:'flex', alignItems:'center', padding:'9px 12px', background:'#fff', border:'1px solid #E2E8F0', borderRadius:6, marginBottom:4, gap:12}}>
                <span style={{fontWeight:700, fontSize:12, width:120}}>{row.filing}</span>
                <span style={{...settStyles.deptChip, background:window.deptBgColor(row.dept)}}>{row.dept}</span>
                <span style={{fontSize:11, color:'#64748B', flex:1}}>{row.freq} · Due: {row.day}</span>
                <span style={{fontSize:11, color:'#94A3B8'}}>{row.note}</span>
                {currentUser.role === 'Super Master' && <button style={settStyles.editBtn}>Edit</button>}
              </div>
            ))}
          </div>
        )}

        {activeTab === 'system' && (
          <div style={{display:'flex', flexDirection:'column', gap:16}}>
            <div style={{fontSize:13, fontWeight:700, color:'#0F172A'}}>System Configuration</div>
            {[
              {label:'Organization Name', value:'Agarwal Taxcon Private Limited'},
              {label:'System Version', value:'v2.1'},
              {label:'Fiscal Year', value:'April – March'},
              {label:'Default Priority', value:'Medium'},
              {label:'Session Timeout', value:'30 minutes'},
              {label:'Audit Log Retention', value:'7 years (immutable)'},
              {label:'Task Reminder Lead Time', value:'3 days before due'},
            ].map(item => (
              <div key={item.label} style={{display:'flex', alignItems:'center', background:'#fff', border:'1px solid #E2E8F0', borderRadius:8, padding:'12px 16px', gap:12}}>
                <span style={{fontWeight:600, fontSize:12, color:'#475569', width:220}}>{item.label}</span>
                <span style={{fontSize:12, color:'#1E293B', flex:1}}>{item.value}</span>
                {currentUser.role === 'Super Master' && <button style={settStyles.editBtn}>Edit</button>}
              </div>
            ))}
          </div>
        )}
      </div>

      {showNewUser && (
        <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,0.3)', zIndex:50, display:'flex', alignItems:'center', justifyContent:'center'}} onClick={() => setShowNewUser(false)}>
          <div style={{background:'#fff', borderRadius:10, padding:20, width:420, boxShadow:'0 12px 32px rgba(0,0,0,0.12)'}} onClick={e=>e.stopPropagation()}>
            <div style={{fontWeight:700, fontSize:14, marginBottom:14, display:'flex', justifyContent:'space-between'}}>
              Create New User <button onClick={() => setShowNewUser(false)} style={{background:'none',border:'none',cursor:'pointer',color:'#94A3B8',fontSize:16}}>✕</button>
            </div>
            {[{l:'Full Name', t:'text'}, {l:'Role', t:'select', opts:['Admin','Team Lead','Employee']}, {l:'Department', t:'select', opts:DEPTS}, {l:'Login Email', t:'email'}].map(f => (
              <div key={f.l} style={{marginBottom:12}}>
                <label style={{fontSize:11, fontWeight:600, color:'#64748B', textTransform:'uppercase', letterSpacing:'0.04em', display:'block', marginBottom:4}}>{f.l}</label>
                {f.t === 'select' ? (
                  <select style={settStyles.modalInput}><option value="">Select…</option>{f.opts?.map(o => <option key={o}>{o}</option>)}</select>
                ) : (
                  <input type={f.t} style={settStyles.modalInput} />
                )}
              </div>
            ))}
            <button style={{...settStyles.newBtn, width:'100%', marginTop:4}}>Create User</button>
          </div>
        </div>
      )}
    </div>
  );
}

const settStyles = {
  page:      { display:'flex', flexDirection:'column', height:'100%', background:'#F8FAFC' },
  tabBar:    { display:'flex', background:'#fff', borderBottom:'1px solid #E2E8F0', padding:'0 16px', flexShrink:0 },
  tab:       { padding:'10px 16px', fontSize:12, fontWeight:600, background:'none', border:'none', cursor:'pointer', whiteSpace:'nowrap' },
  newBtn:    { background:'#1D4ED8', color:'#fff', border:'none', borderRadius:6, padding:'6px 14px', fontSize:12, fontWeight:600, cursor:'pointer' },
  table:     { width:'100%', borderCollapse:'collapse' },
  th:        { padding:'8px 10px', fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em', borderBottom:'1px solid #E2E8F0', textAlign:'left', background:'#FAFAFA', position:'sticky', top:0 },
  tr:        { borderBottom:'1px solid #F1F5F9' },
  td:        { padding:'8px 10px', fontSize:12, color:'#1E293B', verticalAlign:'middle' },
  editBtn:   { background:'#F1F5F9', border:'1px solid #E2E8F0', borderRadius:4, padding:'2px 8px', fontSize:11, cursor:'pointer', color:'#475569' },
  deptChip:  { padding:'2px 6px', borderRadius:4, fontSize:11, fontWeight:600, color:'#1E293B' },
  modalInput:{ width:'100%', border:'1px solid #E2E8F0', borderRadius:6, padding:'6px 10px', fontSize:12, outline:'none', boxSizing:'border-box', background:'#FAFAFA' },
};

Object.assign(window, { AuditTrail, Settings });
