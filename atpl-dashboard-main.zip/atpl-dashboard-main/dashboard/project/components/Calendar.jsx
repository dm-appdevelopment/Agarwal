
// ─── Compliance Calendar ──────────────────────────────────────────────────────
function ComplianceCalendar({ currentUser }) {
  const { COMPLIANCE } = window.AppData;
  const [viewDate, setViewDate] = React.useState(new Date('2026-04-01'));

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const monthName = viewDate.toLocaleString('default', { month: 'long', year: 'numeric' });

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const pad = (n) => String(n).padStart(2, '0');
  const isoDate = (d) => `${year}-${pad(month+1)}-${pad(d)}`;
  const today = '2026-04-20';

  const eventsByDate = React.useMemo(() => {
    const map = {};
    COMPLIANCE.forEach(c => {
      if (!map[c.date]) map[c.date] = [];
      map[c.date].push(c);
    });
    return map;
  }, []);

  const deptColor = { GST:'#3B82F6', 'Income Tax':'#10B981', Audit:'#F59E0B', TDS:'#8B5CF6', 'Company Law':'#EC4899', NGO:'#14B8A6', Accounts:'#64748B' };

  const upcoming = COMPLIANCE.filter(c => c.date >= today).sort((a,b) => a.date.localeCompare(b.date)).slice(0,10);

  const prevMonth = () => setViewDate(new Date(year, month - 1, 1));
  const nextMonth = () => setViewDate(new Date(year, month + 1, 1));

  const [selected, setSelected] = React.useState(null);

  return (
    <div style={calStyles.page}>
      <div style={calStyles.left}>
        {/* Upcoming list */}
        <div style={calStyles.upcomingHeader}>Upcoming Deadlines</div>
        <div style={{overflowY:'auto', flex:1}}>
          {upcoming.map(c => {
            const diff = Math.ceil((new Date(c.date) - new Date(today)) / 86400000);
            const urgent = diff <= 3;
            return (
              <div key={c.id} style={{...calStyles.upcomingItem, borderLeft:`3px solid ${deptColor[c.dept]||'#94A3B8'}`, background: selected?.id === c.id ? '#EFF6FF' : undefined}}
                   onClick={() => setSelected(c)}>
                <div style={{fontWeight:700, fontSize:12, color:'#0F172A'}}>{c.type}</div>
                <div style={{fontSize:10, color:'#64748B', marginTop:1}}>{c.period} · {c.dept}</div>
                <div style={{fontSize:10, fontWeight:700, color: urgent ? '#EF4444' : '#64748B', marginTop:2}}>
                  {diff === 0 ? 'Due today' : diff < 0 ? `${Math.abs(diff)}d ago` : `${diff}d left`} · {c.date}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div style={calStyles.calArea}>
        {/* Nav */}
        <div style={calStyles.calNav}>
          <button style={calStyles.navBtn} onClick={prevMonth}>‹</button>
          <span style={{fontWeight:700, fontSize:14, color:'#0F172A'}}>{monthName}</span>
          <button style={calStyles.navBtn} onClick={nextMonth}>›</button>
        </div>

        {/* Day headers */}
        <div style={calStyles.dayHeaders}>
          {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
            <div key={d} style={calStyles.dayHeader}>{d}</div>
          ))}
        </div>

        {/* Grid */}
        <div style={calStyles.grid}>
          {/* Empty cells */}
          {Array.from({length: firstDay}).map((_,i) => <div key={`e${i}`} style={calStyles.emptyCell} />)}
          {/* Day cells */}
          {Array.from({length: daysInMonth}).map((_,i) => {
            const d = i + 1;
            const iso = isoDate(d);
            const events = eventsByDate[iso] || [];
            const isToday = iso === today;
            return (
              <div key={d} style={{...calStyles.dayCell, background: isToday ? '#EFF6FF' : '#fff', border: isToday ? '2px solid #1D4ED8' : '1px solid #E2E8F0'}}>
                <div style={{...calStyles.dayNum, color: isToday ? '#1D4ED8' : '#475569', fontWeight: isToday ? 700 : 400}}>{d}</div>
                <div style={{display:'flex', flexDirection:'column', gap:2}}>
                  {events.slice(0,3).map(ev => (
                    <div key={ev.id} style={{...calStyles.eventChip, background: (deptColor[ev.dept]||'#94A3B8')+'22', color: deptColor[ev.dept]||'#64748B', borderLeft:`2px solid ${deptColor[ev.dept]||'#94A3B8'}`}}
                         onClick={() => setSelected(ev)} title={ev.desc}>
                      {ev.type.length > 12 ? ev.type.slice(0,12)+'…' : ev.type}
                    </div>
                  ))}
                  {events.length > 3 && <div style={{fontSize:9, color:'#94A3B8', paddingLeft:2}}>+{events.length-3} more</div>}
                </div>
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div style={calStyles.legend}>
          {Object.entries(deptColor).map(([dept, color]) => (
            <div key={dept} style={{display:'flex', alignItems:'center', gap:4}}>
              <div style={{width:10, height:10, borderRadius:2, background:color}} />
              <span style={{fontSize:10, color:'#64748B'}}>{dept}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Event detail popup */}
      {selected && (
        <div style={calStyles.popup}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8}}>
            <div style={{fontWeight:700, fontSize:13}}>{selected.type}</div>
            <button onClick={() => setSelected(null)} style={{background:'none', border:'none', cursor:'pointer', color:'#94A3B8', fontSize:14}}>✕</button>
          </div>
          {[['Period', selected.period], ['Department', selected.dept], ['Date', selected.date], ['Description', selected.desc], ['Clients Affected', selected.clients.length]].map(([l,v]) => (
            <div key={l} style={{display:'flex', gap:8, padding:'4px 0', borderBottom:'1px solid #F1F5F9', fontSize:12}}>
              <span style={{fontWeight:600, color:'#64748B', width:100}}>{l}</span>
              <span style={{color:'#1E293B'}}>{v}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const calStyles = {
  page:       { display:'flex', height:'100%', overflow:'hidden', background:'#F8FAFC', position:'relative' },
  left:       { width:220, borderRight:'1px solid #E2E8F0', background:'#fff', display:'flex', flexDirection:'column', flexShrink:0 },
  upcomingHeader:{ padding:'10px 12px', fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em', borderBottom:'1px solid #E2E8F0', background:'#FAFAFA' },
  upcomingItem:{ padding:'8px 10px 8px 12px', borderBottom:'1px solid #F1F5F9', cursor:'pointer', marginLeft:8, marginTop:4, borderRadius:4 },
  calArea:    { flex:1, display:'flex', flexDirection:'column', overflow:'auto', padding:16 },
  calNav:     { display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 },
  navBtn:     { background:'#F1F5F9', border:'1px solid #E2E8F0', borderRadius:6, padding:'4px 12px', fontSize:16, cursor:'pointer', color:'#475569' },
  dayHeaders: { display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:4, marginBottom:4 },
  dayHeader:  { textAlign:'center', fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em', padding:'4px 0' },
  grid:       { display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:4, flex:1 },
  emptyCell:  { background:'#FAFAFA', borderRadius:6, minHeight:80, border:'1px solid #F1F5F9' },
  dayCell:    { borderRadius:6, minHeight:80, padding:'4px 5px', cursor:'default' },
  dayNum:     { fontSize:11, marginBottom:3, padding:'1px 3px' },
  eventChip:  { fontSize:9, fontWeight:600, padding:'1px 4px', borderRadius:3, cursor:'pointer', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' },
  legend:     { display:'flex', flexWrap:'wrap', gap:10, marginTop:12, padding:'8px 0', borderTop:'1px solid #E2E8F0' },
  popup:      { position:'absolute', right:20, bottom:20, width:280, background:'#fff', border:'1px solid #E2E8F0', borderRadius:10, boxShadow:'0 8px 24px rgba(0,0,0,0.1)', padding:14, zIndex:10 },
};

Object.assign(window, { ComplianceCalendar });
