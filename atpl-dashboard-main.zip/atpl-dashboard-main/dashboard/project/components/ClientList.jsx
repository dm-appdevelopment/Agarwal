
// ─── Client Master List (CML) ─────────────────────────────────────────────────
function ClientList({ currentUser }) {
  const { CLIENTS, TASKS } = window.AppData;
  const [search, setSearch] = React.useState('');
  const [deptFilter, setDeptFilter] = React.useState('');
  const [selected, setSelected] = React.useState(null);

  const filtered = React.useMemo(() => {
    let list = CLIENTS;
    if (currentUser.role === 'Employee') list = list.filter(c => {
      const myTasks = TASKS.filter(t => t.assignedTo === currentUser.id);
      return myTasks.some(t => t.clientId === c.id);
    });
    if (search) list = list.filter(c =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.code.toLowerCase().includes(search.toLowerCase()) ||
      c.pan.toLowerCase().includes(search.toLowerCase())
    );
    if (deptFilter) list = list.filter(c => c.depts.includes(deptFilter));
    return list;
  }, [search, deptFilter, currentUser]);

  return (
    <div style={cmlStyles.page}>
      {/* Toolbar */}
      <div style={cmlStyles.toolbar}>
        <div style={{position:'relative', flex:'0 0 260px'}}>
          <span style={{position:'absolute', left:8, top:'50%', transform:'translateY(-50%)', color:'#94A3B8', fontSize:16}}>⌕</span>
          <input style={cmlStyles.searchInput} placeholder="Search by name, code or PAN…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select style={cmlStyles.select} value={deptFilter} onChange={e => setDeptFilter(e.target.value)}>
          <option value="">All Departments</option>
          {window.AppData.DEPTS.map(d => <option key={d}>{d}</option>)}
        </select>
        <div style={{flex:1}} />
        <span style={{fontSize:11, color:'#94A3B8', fontWeight:600}}>{filtered.length} clients</span>
        {(currentUser.role !== 'Employee') && (
          <button style={cmlStyles.newBtn}>+ Onboard Client</button>
        )}
      </div>

      <div style={{display:'flex', flex:1, overflow:'hidden'}}>
        {/* Table */}
        <div style={{flex:1, overflowY:'auto'}}>
          <table style={cmlStyles.table}>
            <thead>
              <tr>
                {['Code','Client Name','PAN','GSTIN','TAN','CIN/LLPIN','Departments','Active Tasks','Status',''].map(h => (
                  <th key={h} style={cmlStyles.th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => {
                const activeTasks = TASKS.filter(t => t.clientId === c.id && t.status !== 'T3').length;
                const isSelected = selected?.id === c.id;
                return (
                  <tr key={c.id} style={{...cmlStyles.tr, background: isSelected ? '#EFF6FF' : undefined}}
                      onClick={() => setSelected(isSelected ? null : c)}>
                    <td style={{...cmlStyles.td, fontFamily:'monospace', fontSize:11, color:'#1D4ED8', fontWeight:600}}>{c.code}</td>
                    <td style={cmlStyles.td}>
                      <div style={{fontWeight:600, fontSize:12}}>{c.name}</div>
                      {c.group && <div style={{fontSize:10, color:'#94A3B8'}}>{c.group}</div>}
                    </td>
                    <td style={{...cmlStyles.td, fontFamily:'monospace', fontSize:11}}>{c.pan || <span style={{color:'#94A3B8'}}>—</span>}</td>
                    <td style={{...cmlStyles.td, fontFamily:'monospace', fontSize:10}}>{c.gstin || <span style={{color:'#94A3B8'}}>—</span>}</td>
                    <td style={{...cmlStyles.td, fontFamily:'monospace', fontSize:11}}>{c.tan || <span style={{color:'#94A3B8'}}>—</span>}</td>
                    <td style={{...cmlStyles.td, fontFamily:'monospace', fontSize:10}}>{c.cin || <span style={{color:'#94A3B8'}}>—</span>}</td>
                    <td style={cmlStyles.td}>
                      <div style={{display:'flex', flexWrap:'wrap', gap:3}}>
                        {c.depts.map(d => <span key={d} style={{...cmlStyles.deptChip, background:window.deptBgColor(d)}}>{d}</span>)}
                      </div>
                    </td>
                    <td style={{...cmlStyles.td, textAlign:'center'}}>
                      <span style={{fontWeight:700, fontSize:13, color: activeTasks > 0 ? '#1D4ED8' : '#94A3B8'}}>{activeTasks || '—'}</span>
                    </td>
                    <td style={cmlStyles.td}>
                      <span style={{padding:'2px 7px', borderRadius:10, fontSize:11, fontWeight:600, background: c.status==='Active'?'#D1FAE5':'#F1F5F9', color: c.status==='Active'?'#065F46':'#94A3B8'}}>{c.status}</span>
                    </td>
                    <td style={cmlStyles.td} onClick={e=>e.stopPropagation()}>
                      {currentUser.role !== 'Employee' && <button style={cmlStyles.editBtn}>Edit</button>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Client Detail Sidebar */}
        {selected && (
          <div style={cmlStyles.sidebar}>
            <div style={cmlStyles.sidebarHeader}>
              <div>
                <div style={{fontSize:13, fontWeight:700, color:'#0F172A'}}>{selected.name}</div>
                <div style={{fontSize:10, fontFamily:'monospace', color:'#1D4ED8', marginTop:2}}>{selected.code}</div>
              </div>
              <button onClick={() => setSelected(null)} style={{background:'none', border:'none', fontSize:16, cursor:'pointer', color:'#94A3B8'}}>✕</button>
            </div>
            <div style={{padding:14, display:'flex', flexDirection:'column', gap:12}}>
              {/* Key identifiers */}
              <div>
                <div style={cmlStyles.sectionTitle}>Identifiers</div>
                {[['PAN', selected.pan], ['GSTIN', selected.gstin], ['TAN', selected.tan], ['CIN/LLPIN', selected.cin]].map(([l,v]) => (
                  <div key={l} style={cmlStyles.fieldRow}>
                    <span style={cmlStyles.fieldLabel}>{l}</span>
                    <span style={{fontFamily:'monospace', fontSize:11, color: v ? '#1E293B' : '#94A3B8'}}>{v || '—'}</span>
                  </div>
                ))}
              </div>
              {/* Group */}
              {selected.group && (
                <div>
                  <div style={cmlStyles.sectionTitle}>Group</div>
                  <div style={{fontSize:12, color:'#1E293B'}}>{selected.group}</div>
                </div>
              )}
              {/* Departments */}
              <div>
                <div style={cmlStyles.sectionTitle}>Active Departments</div>
                <div style={{display:'flex', flexWrap:'wrap', gap:4, marginTop:4}}>
                  {selected.depts.map(d => <span key={d} style={{...cmlStyles.deptChip, background:window.deptBgColor(d), padding:'3px 8px', fontSize:12}}>{d}</span>)}
                </div>
              </div>
              {/* Active Tasks for this client */}
              <div>
                <div style={cmlStyles.sectionTitle}>Active Tasks</div>
                {TASKS.filter(t => t.clientId === selected.id).slice(0,5).map(t => {
                  const stColor = { T0:'#94A3B8', T1:'#3B82F6', T2:'#F59E0B', T3:'#10B981' };
                  return (
                    <div key={t.id} style={cmlStyles.taskRow}>
                      <div style={{flex:1}}>
                        <div style={{fontSize:11, fontWeight:600}}>{t.type}</div>
                        <div style={{fontSize:10, color:'#94A3B8'}}>{t.dept}</div>
                      </div>
                      <span style={{padding:'2px 6px', borderRadius:4, fontSize:10, fontWeight:700, background:stColor[t.status]+'18', color:stColor[t.status], border:`1px solid ${stColor[t.status]}44`}}>{t.status}</span>
                    </div>
                  );
                })}
              </div>
              {currentUser.role !== 'Employee' && (
                <button style={{...cmlStyles.newBtn, width:'100%', textAlign:'center'}}>+ Assign Task to Client</button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const cmlStyles = {
  page:      { display:'flex', flexDirection:'column', height:'100%', background:'#F8FAFC' },
  toolbar:   { display:'flex', alignItems:'center', gap:8, padding:'10px 16px', background:'#fff', borderBottom:'1px solid #E2E8F0', flexShrink:0 },
  searchInput:{ width:'100%', border:'1px solid #E2E8F0', borderRadius:6, padding:'5px 8px 5px 26px', fontSize:12, outline:'none', boxSizing:'border-box' },
  select:    { border:'1px solid #E2E8F0', borderRadius:6, padding:'5px 8px', fontSize:12, color:'#475569', background:'#fff', outline:'none' },
  newBtn:    { background:'#1D4ED8', color:'#fff', border:'none', borderRadius:6, padding:'6px 14px', fontSize:12, fontWeight:600, cursor:'pointer' },
  table:     { width:'100%', borderCollapse:'collapse' },
  th:        { padding:'8px 10px', fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em', borderBottom:'1px solid #E2E8F0', textAlign:'left', background:'#FAFAFA', position:'sticky', top:0 },
  tr:        { borderBottom:'1px solid #F1F5F9', cursor:'pointer' },
  td:        { padding:'8px 10px', fontSize:12, color:'#1E293B', verticalAlign:'middle' },
  deptChip:  { padding:'1px 5px', borderRadius:4, fontSize:10, fontWeight:600, color:'#1E293B' },
  editBtn:   { background:'#F1F5F9', border:'1px solid #E2E8F0', borderRadius:4, padding:'2px 8px', fontSize:11, cursor:'pointer', color:'#475569' },
  sidebar:   { width:300, borderLeft:'1px solid #E2E8F0', background:'#fff', overflowY:'auto', flexShrink:0 },
  sidebarHeader:{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', padding:'14px', borderBottom:'1px solid #E2E8F0', background:'#F8FAFC' },
  sectionTitle:{ fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:6 },
  fieldRow:  { display:'flex', justifyContent:'space-between', padding:'4px 0', borderBottom:'1px solid #F1F5F9' },
  fieldLabel:{ fontSize:11, fontWeight:600, color:'#64748B' },
  taskRow:   { display:'flex', alignItems:'center', padding:'5px 0', borderBottom:'1px solid #F8FAFC' },
};

Object.assign(window, { ClientList });
