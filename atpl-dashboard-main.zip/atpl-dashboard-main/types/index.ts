// ── Role types ──────────────────────────────────────────────
export type Role = 'Super Master' | 'Admin' | 'Team Lead' | 'Employee';

export interface DepartmentRecord {
  id: string;
  name: string;
  color_bg: string;
  color_text: string;
  status: 'Active' | 'Inactive';
  created_at: string;
}
export type TaskStatus = 'T0' | 'T1' | 'T2' | 'T3';
export type Priority = 'High' | 'Medium' | 'Low';
export type Department = 'GST' | 'Income Tax' | 'Audit' | 'TDS' | 'Company Law' | 'NGO' | 'Accounts';

// ── Database row types ───────────────────────────────────────
export interface Employee {
  id: string;
  full_name: string;
  username: string;
  role: Role;
  is_team_lead: boolean;
  team_lead_scope: string[];
  reporting_to: string | null;
  departments: string[];
  personal_email: string | null;
  phone: string | null;
  date_of_joining: string | null;
  task_capacity: number;
  status: 'Active' | 'Inactive' | 'Offboarded';
  offboarding_date: string | null;
  offboarding_remarks: string | null;
  avatar: string;
  created_at: string;
}

export interface LoginRegistry {
  employee_id: string;
  username: string;
  password_hash: string;
  password_last_changed: string | null;
  force_password_reset: boolean;
  role: Role;
  is_team_lead: boolean;
  department_access: string[];
  client_visibility: 'All Clients' | 'Team Scope Only' | 'Assigned Clients Only';
  dashboard_my_tasks: boolean;
  dashboard_my_team: boolean;
  dashboard_dept_overview: boolean;
  dashboard_firm_wide: boolean;
  can_onboard_clients: boolean;
  can_edit_compliance_master: boolean;
  can_generate_reports: boolean;
  can_export_data: boolean;
  account_status: 'Active' | 'Suspended' | 'Locked';
  lock_reason: string | null;
  failed_login_attempts: number;
  last_login_date: string | null;
  access_granted_by: string | null;
  access_grant_date: string;
  notes: string | null;
}

export interface Client {
  id: string;
  code: string;
  name: string;
  pan: string | null;
  tan: string | null;
  cin: string | null;
  client_group: string | null;
  constitution: string;
  status: 'Active' | 'Inactive' | 'On Hold' | 'New (Pre-PAN)';
  pan_status: 'Confirmed' | 'Awaited';
  transition_trigger: string;
  ao_code: string | null;
  jurisdiction: string | null;
  created_by: string | null;
  created_at: string;
  // joined
  departments?: string[];
  gstins?: Gstin[];
}

export interface Gstin {
  id: string;
  client_id: string;
  gstin: string;
  state: string | null;
  registration_type: string;
  return_frequency: string;
  gst_status: string;
  created_at: string;
}

export interface ComplianceType {
  id: string;
  filing_category: string;
  filing_type: string;
  frequency: string;
  due_date_rule: string;
  applicability_rules: string | null;
  status: 'Active' | 'Deactivated';
  created_at: string;
}

export interface Task {
  id: string;
  client_id: string;
  compliance_type_id: string | null;
  dept: string;
  type: string;
  period: string | null;
  assigned_to: string | null;
  assigned_by: string | null;
  parent_task_id: string | null;
  priority: Priority;
  status: TaskStatus;
  t0: string | null;
  t1: string | null;
  t2: string | null;
  t3: string | null;
  due: string | null;
  pending_from_client: boolean;
  remarks: string;
  revert_count: number;
  recurring: boolean;
  recurring_prompt_status: string;
  created_at: string;
  gstin_id: string | null;
  tl_reviewed: boolean;
  sub_assigned_by: string | null;
  // joined
  client_name?: string;
  client_code?: string;
  assigned_to_name?: string;
  assigned_by_name?: string;
  assigned_by_role?: string;
  sub_assigned_by_name?: string;
  gstin_number?: string;
  gstin_state?: string;
  gstin_return_frequency?: string;
}

export interface SubtaskChecklist {
  id: string;
  task_id: string;
  description: string;
  status: 'Pending' | 'In Progress' | 'Done';
  assigned_to: string | null;
  created_at: string;
}

export interface Notice {
  id: string;
  client_id: string;
  dept: string | null;
  notice_type: string | null;
  notice_date: string | null;
  due_date: string | null;
  status: string;
  assigned_to: string | null;
  drive_link: string | null;
  remarks: string | null;
  created_at: string;
}

export interface ComplianceScheduleItem {
  id: string;
  client_id: string;
  compliance_type_id: string | null;
  gstin_id: string | null;
  period: string;
  due_date: string | null;
  assigned_employee: string | null;
  status: string;
  task_id: string | null;
  recurring_prompt_status: string;
  created_at: string;
  // joined
  client_name?: string;
  filing_type?: string;
  dept?: string;
  desc?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor_employee_id: string | null;
  actor_name: string;
  actor_role: string;
  action_type: string;
  target_entity_type: string | null;
  target_entity_id: string | null;
  action_description: string;
  previous_value: string | null;
  new_value: string | null;
  ip_address: string | null;
  session_id: string | null;
}

export interface TeamComposition {
  id: string;
  team_lead_id: string;
  member_id: string;
  effective_from: string;
  effective_to: string | null;
  status: 'Active' | 'Historical';
  designated_by: string | null;
  designation_date: string;
}

// ── Session / JWT ────────────────────────────────────────────
export interface SessionUser {
  id: string;
  username: string;
  full_name: string;
  role: Role;
  departments: string[];
  avatar: string;
  client_visibility: string;
  can_onboard_clients: boolean;
  can_edit_compliance_master: boolean;
  can_generate_reports: boolean;
  can_export_data: boolean;
  dashboard_my_tasks: boolean;
  dashboard_my_team: boolean;
  dashboard_dept_overview: boolean;
  dashboard_firm_wide: boolean;
  force_password_reset: boolean;
}

export interface ClientRequest {
  id: string;
  request_status: 'Pending' | 'Rejected';
  requested_by: string;
  requested_at: string;
  rejection_remarks: string | null;
  code: string;
  name: string;
  pan: string | null;
  tan: string | null;
  cin: string | null;
  client_group: string | null;
  constitution: string;
  client_status: string;
  pan_status: string;
  departments: string[];
  requester_name?: string;
}

export interface ComplianceTypeRequest {
  id: string;
  request_status: 'Pending' | 'Rejected';
  requested_by: string;
  requested_at: string;
  rejection_remarks: string | null;
  filing_category: string;
  filing_type: string;
  frequency: string;
  due_date_rule: string;
  applicability_rules: string | null;
  requester_name?: string;
}

// ── API response helpers ─────────────────────────────────────
export interface ApiResponse<T> {
  data?: T;
  error?: string;
}
