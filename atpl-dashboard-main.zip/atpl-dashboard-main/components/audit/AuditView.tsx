'use client';
import { useEffect, useState, useCallback } from 'react';
import { Search, Lock } from 'lucide-react';
import { ROLE_COLOR, ROLE_BG, formatDateTime } from '@/lib/utils';
import type { SessionUser, AuditLogEntry } from '@/types';

const ACTION_COLOR: Record<string, string> = {
  'Login':                  '#10B981',
  'Task Created':           '#3B82F6',
  'Task Advanced':          '#0891B2',
  'Task Reverted':          '#F59E0B',
  'Task Transferred':       '#8B5CF6',
  'Profile Created':        '#F59E0B',
  'Profile Modified':       '#F59E0B',
  'Profile Deleted':        '#EF4444',
  'Client Onboarded':       '#8B5CF6',
  'Client Modified':        '#8B5CF6',
  'Compliance Master Edited':'#EC4899',
  'Team Lead Designated':   '#0891B2',
  'Password Reset':         '#F97316',
  'Account Locked':         '#EF4444',
  'Account Unlocked':       '#10B981',
};

const ROLES  = ['Super Master','Admin','Team Lead','Employee'];
const ACTIONS = Object.keys(ACTION_COLOR);

export default function AuditView({ user }: { user: SessionUser }) {
  const [logs, setLogs]         = useState<AuditLogEntry[]>([]);
  const [search, setSearch]     = useState('');
  const [roleFilter, setRole]   = useState('');
  const [actionFilter, setAction] = useState('');
  const [loading, setLoading]   = useState(true);

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    const p = new URLSearchParams();
    if (search)       p.set('search', search);
    if (roleFilter)   p.set('role', roleFilter);
    if (actionFilter) p.set('module', actionFilter);
    const res = await fetch(`/api/audit?${p}`);
    const data = await res.json();
    setLogs(data.logs ?? []);
    setLoading(false);
  }, [search, roleFilter, actionFilter]);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);

  return (
    <div className="flex flex-col h-full bg-slate-50">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-4 py-2.5 bg-white border-b border-slate-200 flex-shrink-0">
        <div className="relative w-64">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="w-full border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs outline-none focus:border-blue-400 bg-slate-50"
            placeholder="Search action or user…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        <select className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 bg-white outline-none"
          value={roleFilter} onChange={e => setRole(e.target.value)}>
          <option value="">All Roles</option>
          {ROLES.map(r => <option key={r}>{r}</option>)}
        </select>

        <select className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 bg-white outline-none"
          value={actionFilter} onChange={e => setAction(e.target.value)}>
          <option value="">All Actions</option>
          {ACTIONS.map(a => <option key={a}>{a}</option>)}
        </select>

        <div className="flex-1" />
        <span className="text-xs text-slate-400 font-semibold">{logs.length} entries</span>
        <div className="flex items-center gap-1.5 bg-red-50 border border-red-200 rounded-lg px-3 py-1.5 text-xs text-red-600 font-semibold">
          <Lock size={11} />
          Read-only · Immutable
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center h-32 text-slate-400 text-sm animate-pulse">Loading audit log…</div>
        ) : (
          <table className="w-full border-collapse">
            <thead>
              <tr>
                {['Timestamp','User','Role','Action','Description','IP Address'].map(h => (
                  <th key={h} className="th">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {logs.map((a, i) => {
                const aColor = ACTION_COLOR[a.action_type] ?? '#64748B';
                return (
                  <tr key={a.id} className="border-b border-slate-100" style={{ background: i % 2 === 0 ? '#fff' : '#FAFAFA' }}>
                    <td className="td font-mono text-[10px] text-slate-500 whitespace-nowrap">{formatDateTime(a.timestamp)}</td>
                    <td className="td font-semibold text-xs">{a.actor_name}</td>
                    <td className="td">
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-bold"
                        style={{ background: ROLE_BG[a.actor_role] ?? '#F1F5F9', color: ROLE_COLOR[a.actor_role] ?? '#64748B' }}>
                        {a.actor_role}
                      </span>
                    </td>
                    <td className="td">
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold border"
                        style={{ background: aColor+'18', color: aColor, borderColor: aColor+'44' }}>
                        {a.action_type}
                      </span>
                    </td>
                    <td className="td text-xs text-slate-700 max-w-[360px]">{a.action_description}</td>
                    <td className="td font-mono text-[10px] text-slate-400">{a.ip_address ?? '—'}</td>
                  </tr>
                );
              })}
              {logs.length === 0 && (
                <tr><td colSpan={6} className="td text-center text-slate-400 py-12">No audit log entries found.</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
