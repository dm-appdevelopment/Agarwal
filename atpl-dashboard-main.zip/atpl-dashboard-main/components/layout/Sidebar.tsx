'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutDashboard, CheckSquare, Users, Calendar,
  GitBranch, ShieldAlert, Settings, LogOut, PackageCheck
} from 'lucide-react';
import { cn, ROLE_COLOR } from '@/lib/utils';
import type { SessionUser } from '@/types';

const NAV = [
  { id: 'home',     href: '/',         label: 'Dashboard',       icon: LayoutDashboard,  roles: ['Super Master','Admin','Team Lead','Employee'] },
  { id: 'tasks',    href: '/tasks',    label: 'Task Manager',    icon: CheckSquare,       roles: ['Super Master','Admin','Team Lead','Employee'] },
  { id: 'clients',  href: '/clients',  label: 'Client Master',   icon: Users,             roles: ['Super Master','Admin','Team Lead','Employee'] },
  { id: 'calendar', href: '/calendar', label: 'Compliance Cal.', icon: Calendar,          roles: ['Super Master','Admin','Team Lead','Employee'] },
  { id: 'completed',href: '/completed', label: 'Completed Tasks',  icon: PackageCheck,        roles: ['Super Master','Admin','Team Lead','Employee'] },
  { id: 'team',     href: '/team',     label: 'Team Management', icon: GitBranch,          roles: ['Super Master','Admin','Team Lead'] },
  { id: 'audit',    href: '/audit',    label: 'Audit Trail',     icon: ShieldAlert,        roles: ['Super Master','Admin'] },
  { id: 'settings', href: '/settings', label: 'Settings',        icon: Settings,           roles: ['Super Master','Admin'] },
];

const ROLE_BG_DARK: Record<string, string> = {
  'Super Master': '#1e3a8a',
  Admin:          '#4c1d95',
  'Team Lead':    '#164e63',
  Employee:       '#14532d',
};

export default function Sidebar({ user }: { user: SessionUser }) {
  const pathname = usePathname();
  const router   = useRouter();

  const visibleNav = NAV.filter(n => n.roles.includes(user.role));

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
    router.refresh();
  }

  return (
    <aside className="w-[220px] flex flex-col bg-[#0D2137] flex-shrink-0" style={{ height: '100vh' }}>
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-3.5 py-3.5 flex-shrink-0">
        <div className="w-8 h-8 rounded-lg bg-blue-700 flex items-center justify-center text-white text-xs font-black flex-shrink-0">
          AT
        </div>
        <div>
          <div className="text-[11px] font-bold text-white leading-tight">Agarwal Taxcon</div>
          <div className="text-[9px] text-slate-500 font-medium">Practice Management</div>
        </div>
      </div>

      {/* User Badge */}
      <div className="mx-2 mb-1.5 px-2.5 py-2 rounded-lg" style={{ background: '#0D1F38' }}>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0"
            style={{ background: ROLE_COLOR[user.role] }}>
            {user.avatar}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[11px] font-semibold text-slate-200 truncate">{user.full_name}</div>
            <div className="text-[9px] font-bold mt-0.5" style={{ color: ROLE_COLOR[user.role] }}>
              {user.role}
            </div>
          </div>
        </div>
      </div>

      <div className="h-px bg-[#1E2D47] mx-2 my-1.5 flex-shrink-0" />

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-1">
        {visibleNav.map(item => {
          const active = item.href === '/' ? pathname === '/' : pathname.startsWith(item.href);
          const Icon   = item.icon;
          return (
            <Link key={item.id} href={item.href}
              className={cn(
                'flex items-center gap-2.5 px-3.5 py-2 text-xs font-medium transition-all rounded-r-lg mr-1 mb-px border-l-[3px]',
                active
                  ? 'bg-blue-700/20 border-blue-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-white/5'
              )}>
              <Icon size={14} className="flex-shrink-0" />
              <span className={cn('font-medium', active && 'font-semibold')}>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="h-px bg-[#1E2D47] mx-2 my-1 flex-shrink-0" />

      {/* Logout */}
      <button onClick={logout}
        className="flex items-center gap-2.5 px-3.5 py-2.5 text-xs text-slate-500 hover:text-red-400 hover:bg-red-900/10 transition-colors mx-1 mb-1 rounded-lg">
        <LogOut size={13} />
        <span>Sign out</span>
      </button>
    </aside>
  );
}
