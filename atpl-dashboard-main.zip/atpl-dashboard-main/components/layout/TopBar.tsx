'use client';
import { usePathname } from 'next/navigation';
import { Bell, ChevronRight } from 'lucide-react';
import { useState, useEffect } from 'react';
import { ROLE_COLOR, ROLE_BG, formatDate } from '@/lib/utils';
import type { SessionUser, Task } from '@/types';

const PAGE_TITLES: Record<string, string> = {
  '/':          'Dashboard',
  '/tasks':     'Task Manager',
  '/clients':   'Client Master List',
  '/calendar':  'Compliance Calendar',
  '/team':      'Team Management',
  '/audit':     'Audit Trail',
  '/settings':  'Settings',
};

export default function TopBar({ user }: { user: SessionUser }) {
  const pathname = usePathname();
  const [notifOpen, setNotifOpen] = useState(false);
  const [overdue, setOverdue]     = useState<Task[]>([]);
  const [dueToday, setDueToday]   = useState<Task[]>([]);

  const title = Object.entries(PAGE_TITLES).find(([k]) =>
    k === '/' ? pathname === '/' : pathname.startsWith(k)
  )?.[1] ?? 'Dashboard';

  useEffect(() => {
    fetch('/api/dashboard/alerts')
      .then(r => r.json())
      .then(d => {
        setOverdue(d.overdue ?? []);
        setDueToday(d.dueToday ?? []);
      })
      .catch(() => {});
  }, [pathname]);

  const badgeCount = overdue.length + dueToday.length;
  const dept = user.departments?.[0] ?? 'Management';

  return (
    <header className="h-11 flex items-center justify-between px-5 bg-white border-b border-slate-200 flex-shrink-0">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1.5">
        <span className="text-sm font-bold text-slate-800">{title}</span>
        <ChevronRight size={12} className="text-slate-300" />
        <span className="text-xs text-slate-400">{dept}</span>
      </div>

      <div className="flex items-center gap-3">
        <span className="text-xs text-slate-400">{formatDate(new Date().toISOString())}</span>

        {/* Notifications */}
        <div className="relative">
          <button onClick={() => setNotifOpen(o => !o)}
            className="relative p-1.5 text-slate-400 hover:text-slate-700 transition-colors">
            <Bell size={16} />
            {badgeCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-red-500 text-white text-[8px] font-bold flex items-center justify-center">
                {badgeCount > 9 ? '9+' : badgeCount}
              </span>
            )}
          </button>

          {notifOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
              <div className="absolute right-0 top-full mt-1 w-72 bg-white border border-slate-200 rounded-xl shadow-xl z-50 overflow-hidden">
                <div className="px-3 py-2 border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Notifications
                </div>
                {overdue.length > 0 && (
                  <div className="px-3 py-2 border-b border-slate-100 bg-red-50">
                    <span className="text-xs font-semibold text-red-600">
                      ⚠ {overdue.length} overdue task{overdue.length > 1 ? 's' : ''} need attention
                    </span>
                  </div>
                )}
                {dueToday.map(t => (
                  <div key={t.id} className="px-3 py-2 border-b border-slate-100 text-xs">
                    <span className="font-semibold text-amber-600">Due today: </span>
                    <span className="text-slate-600">{t.type} — {(t.client_name ?? '').slice(0, 25)}</span>
                  </div>
                ))}
                {badgeCount === 0 && (
                  <div className="px-3 py-3 text-xs text-slate-400">No pending alerts</div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Role pill */}
        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold"
          style={{ background: ROLE_BG[user.role], color: ROLE_COLOR[user.role] }}>
          {user.role}
        </span>
      </div>
    </header>
  );
}
