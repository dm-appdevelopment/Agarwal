'use client';
import { useEffect, useState } from 'react';
import { Plus, X, AlertTriangle, Pencil, Trash2, Inbox } from 'lucide-react';
import { ROLE_COLOR, ROLE_BG, DEPT_BG, COLOR_PALETTE } from '@/lib/utils';
import { useDepartments, invalidateDeptCache } from '@/lib/hooks';
import EditUserModal from '@/components/shared/EditUserModal';
import RequestComplianceModal from '@/components/requests/RequestComplianceModal';
import type { SessionUser, Employee, ComplianceType, DepartmentRecord, ClientRequest, ComplianceTypeRequest } from '@/types';

type Tab = 'users' | 'departments' | 'compliance-db' | 'system' | 'requests';

export default function SettingsView({ user }: { user: SessionUser }) {
  const [tab, setTab]               = useState<Tab>('users');
  const [pendingCount, setPending]  = useState(0);

  useEffect(() => {
    if (user.role === 'Super Master') {
      fetch('/api/requests').then(r => r.json()).then(d => {
        setPending((d.client_requests?.length ?? 0) + (d.compliance_requests?.length ?? 0));
      });
    }
  }, [user.role]);

  const TABS: { id: Tab; label: string; badge?: number }[] = [
    { id: 'users',         label: 'User Management' },
    { id: 'departments',   label: 'Departments' },
    { id: 'compliance-db', label: 'Compliance DB' },
    ...(user.role === 'Super Master' ? [{ id: 'requests' as Tab, label: 'Requests', badge: pendingCount }] : []),
    { id: 'system',        label: 'System Config' },
  ];

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <div className="flex bg-white border-b border-slate-200 px-4 flex-shrink-0">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className="px-4 py-2.5 text-xs font-semibold transition-colors flex items-center gap-1.5"
            style={{
              color:        tab === t.id ? '#1D4ED8' : '#64748B',
              borderBottom: tab === t.id ? '2px solid #1D4ED8' : '2px solid transparent',
            }}>
            {t.label}
            {t.badge ? (
              <span className="w-4 h-4 rounded-full bg-red-500 text-white text-[8px] font-bold flex items-center justify-center">
                {t.badge > 9 ? '9+' : t.badge}
              </span>
            ) : null}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-5">
        {tab === 'users'         && <UsersTab user={user} />}
        {tab === 'departments'   && <DepartmentsTab user={user} />}
        {tab === 'compliance-db' && <ComplianceDbTab user={user} />}
        {tab === 'requests'      && <RequestsTab user={user} onBadgeChange={setPending} />}
        {tab === 'system'        && <SystemTab user={user} />}
      </div>
    </div>
  );
}

/* ── Users Tab ────────────────────────────────────────────── */
function UsersTab({ user }: { user: SessionUser }) {
  const [users, setUsers]     = useState<Employee[]>([]);
  const [showNew, setShowNew] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUsers = () => {
    fetch('/api/users').then(r => r.json()).then(d => { setUsers(d.users ?? []); setLoading(false); });
  };
  useEffect(fetchUsers, []);

  async function deactivate(id: string) {
    await fetch(`/api/users/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'deactivate', reason: 'Deactivated by Super Master' }),
    });
    fetchUsers();
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="font-bold text-sm text-slate-900">
          User Accounts <span className="text-slate-400 font-normal text-xs">({users.length} total)</span>
        </div>
        {(user.role === 'Super Master' || user.role === 'Admin') && (
          <button onClick={() => setShowNew(true)} className="btn-primary flex items-center gap-1.5">
            <Plus size={13} /> Create User
          </button>
        )}
      </div>

      {loading ? <div className="text-slate-400 text-sm animate-pulse">Loading…</div> : (
        <table className="w-full border-collapse">
          <thead>
            <tr>{['Name','Role','Department','Username','Status','Actions'].map(h => <th key={h} className="th">{h}</th>)}</tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="td">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[9px] font-bold"
                      style={{ background: ROLE_COLOR[u.role] }}>{u.avatar}</div>
                    <span className="font-semibold text-xs">{u.full_name}</span>
                  </div>
                </td>
                <td className="td">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold"
                    style={{ background: ROLE_BG[u.role], color: ROLE_COLOR[u.role] }}>{u.role}</span>
                </td>
                <td className="td text-xs">{u.departments?.join(', ') || '—'}</td>
                <td className="td font-mono text-[10px] text-slate-500">{u.username}</td>
                <td className="td">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold"
                    style={{ background: u.status === 'Active' ? '#D1FAE5' : '#F1F5F9', color: u.status === 'Active' ? '#065F46' : '#94A3B8' }}>
                    {u.status}
                  </span>
                </td>
                <td className="td">
                  {(user.role === 'Super Master' || user.role === 'Admin') && (
                    <div className="flex gap-1.5">
                      <button onClick={() => setEditing(u)} className="btn-secondary py-0.5 px-2 text-[10px]">Edit</button>
                      {u.id !== user.id && (
                        <button onClick={() => deactivate(u.id)} className="btn-danger py-0.5 px-2 text-[10px]">
                          {u.status === 'Active' ? 'Disable' : 'Enable'}
                        </button>
                      )}
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {showNew  && <CreateUserModal user={user} allUsers={users} onClose={() => setShowNew(false)} onRefresh={fetchUsers} />}
      {editing  && <EditUserModal   user={user} target={editing} allUsers={users} onClose={() => setEditing(null)} onRefresh={fetchUsers} />}
    </div>
  );
}

/* ── Create User Modal ────────────────────────────────────── */
function CreateUserModal({ user, allUsers, onClose, onRefresh }: {
  user: SessionUser; allUsers: Employee[]; onClose: () => void; onRefresh: () => void;
}) {
  const { departments } = useDepartments();
  const [form, setForm] = useState({
    full_name: '', username: '', role: 'Employee', departments: [] as string[], password: 'Change@123',
  });
  const [teamMembers, setTeamMembers] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState('');

  function set(k: string, v: string) { setForm(f => ({...f, [k]: v})); }
  function toggleDept(d: string) {
    setForm(f => ({ ...f, departments: f.departments.includes(d) ? f.departments.filter(x => x !== d) : [...f.departments, d] }));
  }
  function toggleMember(id: string) {
    setTeamMembers(m => m.includes(id) ? m.filter(x => x !== id) : [...m, id]);
  }

  const employees = allUsers.filter(u => u.role === 'Employee');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.full_name || !form.username) { setError('Name and username are required'); return; }
    setSaving(true);
    const res = await fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, team_members: form.role === 'Team Lead' ? teamMembers : [] }),
    });
    const data = await res.json();
    if (!res.ok) { setError(data.error); setSaving(false); return; }
    onRefresh(); onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[480px] shadow-2xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 sticky top-0 bg-white">
          <div className="font-bold text-sm">Create New User</div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
        </div>
        <form onSubmit={submit} className="p-5 flex flex-col gap-4">
          {[
            { l: 'Full Name *',       k: 'full_name', t: 'text',     ph: 'Priya Sharma' },
            { l: 'Username *',        k: 'username',  t: 'text',     ph: 'priya.gst' },
            { l: 'Initial Password',  k: 'password',  t: 'password', ph: '' },
          ].map(f => (
            <div key={f.k}>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">{f.l}</label>
              <input type={f.t} className="input-base" placeholder={f.ph}
                value={(form as any)[f.k]} onChange={e => set(f.k, e.target.value)} />
            </div>
          ))}

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Role</label>
            <select className="input-base" value={form.role} onChange={e => set('role', e.target.value)}>
              {(user.role === 'Super Master' ? ['Admin','Team Lead','Employee'] : ['Team Lead','Employee']).map(r =>
                <option key={r}>{r}</option>
              )}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">Departments</label>
            <div className="flex flex-wrap gap-1.5">
              {departments.map(d => (
                <button type="button" key={d} onClick={() => toggleDept(d)}
                  className="px-2 py-0.5 rounded text-[10px] font-semibold border transition-all"
                  style={{
                    background:  form.departments.includes(d) ? '#1D4ED8' : '#F8FAFC',
                    color:       form.departments.includes(d) ? '#fff' : '#64748B',
                    borderColor: form.departments.includes(d) ? '#1D4ED8' : '#E2E8F0',
                  }}>
                  {d}
                </button>
              ))}
            </div>
          </div>

          {form.role === 'Team Lead' && (
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                Assign Team Members
              </label>
              <div className="border border-slate-200 rounded-lg max-h-40 overflow-y-auto divide-y divide-slate-100">
                {employees.length === 0 && <div className="text-xs text-slate-400 px-3 py-2">No employees available</div>}
                {employees.map(emp => (
                  <label key={emp.id} className="flex items-center gap-2.5 px-3 py-2 cursor-pointer hover:bg-slate-50">
                    <input type="checkbox" checked={teamMembers.includes(emp.id)}
                      onChange={() => toggleMember(emp.id)} className="accent-blue-600" />
                    <div className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[8px] font-bold flex-shrink-0"
                      style={{ background: ROLE_COLOR[emp.role] }}>{emp.avatar}</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-slate-800 truncate">{emp.full_name}</div>
                      <div className="text-[10px] text-slate-400">{emp.departments?.join(', ')}</div>
                    </div>
                  </label>
                ))}
              </div>
              {teamMembers.length > 0 && <div className="text-[10px] text-blue-600 mt-1">{teamMembers.length} member(s) selected</div>}
            </div>
          )}

          {error && <div className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</div>}

          <div className="flex gap-2 pt-1">
            <button type="submit" disabled={saving} className="btn-primary flex-1">{saving ? 'Creating…' : 'Create User'}</button>
            <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ── Departments Tab ──────────────────────────────────────── */
function DepartmentsTab({ user }: { user: SessionUser }) {
  const isSuperMaster = user.role === 'Super Master';
  const [deptRecords, setDeptRecords] = useState<DepartmentRecord[]>([]);
  const [empData, setEmpData]         = useState<Employee[]>([]);
  const [showForm, setShowForm]       = useState(false);
  const [editing, setEditing]         = useState<DepartmentRecord | null>(null);
  const [form, setForm]               = useState({ name: '', color_bg: '#F1F5F9', color_text: '#64748B' });
  const [saving, setSaving]           = useState(false);
  const [error, setError]             = useState('');

  const fetchDepts = () => {
    fetch('/api/departments').then(r => r.json()).then(d => {
      setDeptRecords(d.departments ?? []);
      invalidateDeptCache();
    });
  };

  useEffect(() => {
    fetchDepts();
    fetch('/api/users').then(r => r.json()).then(d => setEmpData(d.users ?? []));
  }, []);

  function openNew() {
    setEditing(null);
    const idx = deptRecords.length % COLOR_PALETTE.length;
    setForm({ name: '', color_bg: COLOR_PALETTE[idx].bg, color_text: COLOR_PALETTE[idx].text });
    setShowForm(true);
    setError('');
  }

  function openEdit(dept: DepartmentRecord) {
    setEditing(dept);
    setForm({ name: dept.name, color_bg: dept.color_bg, color_text: dept.color_text });
    setShowForm(true);
    setError('');
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) { setError('Department name is required'); return; }
    setSaving(true);
    const res = await fetch('/api/departments', {
      method:  editing ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(editing ? { id: editing.id, ...form } : form),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) { setError(data.error ?? 'Save failed'); return; }
    setShowForm(false);
    setEditing(null);
    invalidateDeptCache();
    fetchDepts();
  }

  async function toggleStatus(dept: DepartmentRecord) {
    await fetch('/api/departments', {
      method:  'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ id: dept.id, status: dept.status === 'Active' ? 'Inactive' : 'Active' }),
    });
    invalidateDeptCache();
    fetchDepts();
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="font-bold text-sm text-slate-900">Department Configuration</div>
        {isSuperMaster && (
          <button onClick={openNew} className="btn-primary flex items-center gap-1.5">
            <Plus size={13} /> Add Department
          </button>
        )}
      </div>

      {/* Add / Edit form */}
      {showForm && isSuperMaster && (
        <form onSubmit={save} className="card p-4 mb-5 flex flex-col gap-3 border-blue-200 bg-blue-50/40">
          <div className="font-semibold text-xs text-slate-700">{editing ? 'Edit Department' : 'Add New Department'}</div>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Name *</label>
              <input type="text" className="input-base" placeholder="e.g. PF / ESI"
                value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Badge Colour</label>
              <div className="flex items-center gap-2">
                <input type="color" className="w-9 h-8 rounded border border-slate-200 cursor-pointer p-0.5"
                  value={form.color_bg} onChange={e => setForm(f => ({ ...f, color_bg: e.target.value }))} />
                <span className="text-[10px] text-slate-500">Background</span>
              </div>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Text Colour</label>
              <div className="flex items-center gap-2">
                <input type="color" className="w-9 h-8 rounded border border-slate-200 cursor-pointer p-0.5"
                  value={form.color_text} onChange={e => setForm(f => ({ ...f, color_text: e.target.value }))} />
                <span className="text-[10px] text-slate-500">Text</span>
              </div>
            </div>
          </div>
          {/* Palette quick-picks */}
          <div>
            <div className="text-[10px] text-slate-400 mb-1.5">Quick palettes</div>
            <div className="flex gap-2 flex-wrap">
              {COLOR_PALETTE.map((p, i) => (
                <button key={i} type="button"
                  onClick={() => setForm(f => ({ ...f, color_bg: p.bg, color_text: p.text }))}
                  className="w-6 h-6 rounded border-2 transition-all"
                  style={{ background: p.bg, borderColor: form.color_bg === p.bg ? p.text : 'transparent' }}>
                  <span className="sr-only">Palette {i}</span>
                </button>
              ))}
            </div>
          </div>
          {/* Preview */}
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-400">Preview:</span>
            <span className="px-2 py-0.5 rounded text-[10px] font-semibold"
              style={{ background: form.color_bg, color: form.color_text }}>
              {form.name || 'Department'}
            </span>
          </div>
          {error && <div className="text-xs text-red-500">{error}</div>}
          <div className="flex gap-2">
            <button type="submit" disabled={saving} className="btn-primary">{saving ? 'Saving…' : editing ? 'Save Changes' : 'Create Department'}</button>
            <button type="button" onClick={() => { setShowForm(false); setEditing(null); }} className="btn-secondary">Cancel</button>
          </div>
        </form>
      )}

      {/* Department cards grid */}
      <div className="grid grid-cols-3 gap-4">
        {deptRecords.map(dept => {
          const deptUsers = empData.filter(u => u.departments?.includes(dept.name));
          return (
            <div key={dept.id} className="card p-4" style={{ opacity: dept.status === 'Inactive' ? 0.55 : 1 }}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-sm" style={{ background: dept.color_text }} />
                  <span className="font-bold text-sm text-slate-800">{dept.name}</span>
                  {dept.status === 'Inactive' && (
                    <span className="text-[9px] bg-slate-100 text-slate-400 px-1.5 rounded-full font-semibold">Inactive</span>
                  )}
                </div>
                {isSuperMaster && (
                  <div className="flex gap-1">
                    <button onClick={() => openEdit(dept)} className="text-slate-400 hover:text-blue-600 p-0.5">
                      <Pencil size={12} />
                    </button>
                    <button onClick={() => toggleStatus(dept)}
                      className="text-[9px] px-1.5 py-0.5 rounded border border-slate-200 text-slate-400 hover:border-slate-400">
                      {dept.status === 'Active' ? 'Disable' : 'Enable'}
                    </button>
                  </div>
                )}
              </div>
              <div className="text-xs text-slate-400 mb-3">{deptUsers.length} staff assigned</div>
              {deptUsers.map(u => (
                <div key={u.id} className="flex items-center gap-1.5 py-1.5 border-t border-slate-100 text-xs">
                  <div className="w-4 h-4 rounded-full flex items-center justify-center text-white text-[7px] font-bold"
                    style={{ background: ROLE_COLOR[u.role] }}>{u.avatar[0]}</div>
                  <span className="flex-1 truncate">{u.full_name}</span>
                  <span className="text-[9px] text-slate-400">
                    {u.role === 'Admin' ? 'Head' : u.role === 'Team Lead' ? 'Lead' : ''}
                  </span>
                </div>
              ))}
              {deptUsers.length === 0 && <div className="text-xs text-slate-300">No staff assigned</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── Frequency input component ────────────────────────────── */
const FREQ_PRESETS = ['Weekly','Monthly','Quarterly','Half Yearly','Yearly','Custom'] as const;

function FrequencyInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const isCustom    = !FREQ_PRESETS.slice(0,-1).includes(value as any);
  const customMatch = value.match(/^Every (\d+) (Days?|Months?|Years?)$/i);

  const [preset,     setPreset]     = useState<string>(isCustom ? 'Custom' : value);
  const [customN,    setCustomN]    = useState(customMatch?.[1] ?? '3');
  const [customUnit, setCustomUnit] = useState(customMatch?.[2] ?? 'Months');

  function build(n: string, unit: string) { return `Every ${n} ${unit}`; }

  function handlePreset(p: string) {
    setPreset(p);
    onChange(p === 'Custom' ? build(customN, customUnit) : p);
  }
  function handleCustom(n: string, unit: string) {
    setCustomN(n); setCustomUnit(unit);
    onChange(build(n, unit));
  }

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <select className="input-base flex-1" value={preset} onChange={e => handlePreset(e.target.value)}>
        {FREQ_PRESETS.map(p => <option key={p}>{p}</option>)}
      </select>
      {preset === 'Custom' && (
        <>
          <span className="text-xs text-slate-500 flex-shrink-0">Every</span>
          <input type="number" min="1" className="input-base w-16"
            value={customN} onChange={e => handleCustom(e.target.value, customUnit)} />
          <select className="input-base" value={customUnit}
            onChange={e => handleCustom(customN, e.target.value)}>
            {['Days','Months','Years'].map(u => <option key={u}>{u}</option>)}
          </select>
        </>
      )}
    </div>
  );
}

/* ── Due date rule builder ────────────────────────────────── */
const MONTHS_LIST = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const REF_OPTIONS = ['of same month','of following month','of the assessment year','of the following financial year','days after period end'] as const;

function ordinal(n: number): string {
  if (n % 100 >= 11 && n % 100 <= 13) return `${n}th`;
  if (n % 10 === 1) return `${n}st`;
  if (n % 10 === 2) return `${n}nd`;
  if (n % 10 === 3) return `${n}rd`;
  return `${n}th`;
}

function buildRule(day: string, ref: string, month: string): string {
  const d = Math.min(parseInt(day) || 1, 31);
  if (ref === 'days after period end')              return `${d} days after period end`;
  if (ref === 'of the assessment year')             return `${ordinal(d)} ${month} of the assessment year`;
  if (ref === 'of the following financial year')    return `${ordinal(d)} ${month} of the following financial year`;
  return `${ordinal(d)} ${ref}`;
}

function parseRule(rule: string): { day: string; ref: string; month: string } {
  const followMatch = rule.match(/^(\d+)(?:st|nd|rd|th)? of following month$/i);
  if (followMatch) return { day: followMatch[1], ref: 'of following month', month: 'July' };

  const sameMatch = rule.match(/^(\d+)(?:st|nd|rd|th)? of same month$/i);
  if (sameMatch) return { day: sameMatch[1], ref: 'of same month', month: 'July' };

  const finYearMatch = rule.match(/^(\d+)(?:st|nd|rd|th)? (\w+) of the following financial year$/i);
  if (finYearMatch) return { day: finYearMatch[1], ref: 'of the following financial year', month: finYearMatch[2] };

  const yearMatch = rule.match(/^(\d+)(?:st|nd|rd|th)? (\w+) of the (?:assessment )?year$/i);
  if (yearMatch) return { day: yearMatch[1], ref: 'of the assessment year', month: yearMatch[2] };

  const daysAfter = rule.match(/^(\d+) days? after period end$/i);
  if (daysAfter) return { day: daysAfter[1], ref: 'days after period end', month: 'July' };

  return { day: '20', ref: 'of following month', month: 'July' };
}

function DueDateRuleInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const parsed = parseRule(value);
  const [day,   setDay]   = useState(parsed.day);
  const [ref,   setRef]   = useState(parsed.ref);
  const [month, setMonth] = useState(parsed.month);

  function update(d: string, r: string, m: string) { onChange(buildRule(d, r, m)); }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex gap-2 flex-wrap items-end">
        <div>
          <label className="block text-[9px] text-slate-400 mb-0.5">Day / Days</label>
          <input type="number" min="1" max="31" className="input-base w-16"
            value={day}
            onChange={e => {
              const v = String(Math.min(Math.max(parseInt(e.target.value) || 1, 1), 31));
              setDay(v); update(v, ref, month);
            }} />
        </div>
        <div className="flex-1 min-w-32">
          <label className="block text-[9px] text-slate-400 mb-0.5">Reference</label>
          <select className="input-base" value={ref}
            onChange={e => { setRef(e.target.value); update(day, e.target.value, month); }}>
            {REF_OPTIONS.map(r => <option key={r}>{r}</option>)}
          </select>
        </div>
        {(ref === 'of the assessment year' || ref === 'of the following financial year') && (
          <div>
            <label className="block text-[9px] text-slate-400 mb-0.5">Month</label>
            <select className="input-base" value={month}
              onChange={e => { setMonth(e.target.value); update(day, ref, e.target.value); }}>
              {MONTHS_LIST.map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
        )}
      </div>
      <div className="text-[10px] text-blue-600 bg-blue-50 px-2 py-1 rounded self-start">
        → {buildRule(day, ref, month)}
      </div>
    </div>
  );
}

/* ── Compliance DB Tab ────────────────────────────────────── */
function ComplianceDbTab({ user }: { user: SessionUser }) {
  const { departments, deptBg } = useDepartments();
  const [types, setTypes]               = useState<ComplianceType[]>([]);
  const [showSuggest, setShowSuggest]   = useState(false);
  const [resubmitComp, setResubmitComp] = useState<ComplianceTypeRequest | null>(null);
  const [myCompReqs, setMyCompReqs]     = useState<ComplianceTypeRequest[]>([]);

  const canSuggest = !user.can_edit_compliance_master;

  const fetchMyCompReqs = () => {
    if (!canSuggest) return;
    fetch('/api/requests').then(r => r.json()).then(d => setMyCompReqs(d.compliance_requests ?? []));
  };
  useEffect(fetchMyCompReqs, []);
  const [showNew, setShowNew]         = useState(false);
  const [editingComp, setEditingComp] = useState<ComplianceType | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [saving, setSaving]           = useState(false);
  const [formError, setFormError]     = useState('');

  const blankForm = { filing_category: '', filing_type: '', frequency: 'Monthly', due_date_rule: '20th of following month', applicability_rules: '' };
  const [form, setForm] = useState(blankForm);

  const fetchTypes = () => { fetch('/api/compliance-types').then(r => r.json()).then(d => setTypes(d.types ?? [])); };
  useEffect(fetchTypes, []);

  function openNew() {
    setEditingComp(null);
    setForm(blankForm);
    setFormError('');
    setShowNew(true);
  }

  function openEdit(ct: ComplianceType) {
    setEditingComp(ct);
    setForm({
      filing_category:     ct.filing_category,
      filing_type:         ct.filing_type,
      frequency:           ct.frequency,
      due_date_rule:       ct.due_date_rule,
      applicability_rules: ct.applicability_rules ?? '',
    });
    setFormError('');
    setShowNew(true);
  }

  async function deleteType(id: string) {
    await fetch('/api/compliance-types', {
      method:  'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ id }),
    });
    setConfirmDeleteId(null);
    fetchTypes();
  }

  async function saveType(e: React.FormEvent) {
    e.preventDefault();
    if (!form.filing_category) { setFormError('Filing category is required'); return; }
    if (!form.filing_type.trim()) { setFormError('Filing type is required'); return; }
    setSaving(true);
    setFormError('');

    const res = editingComp
      ? await fetch('/api/compliance-types', {
          method:  'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ id: editingComp.id, ...form }),
        })
      : await fetch('/api/compliance-types', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ ...form, status: 'Active' }),
        });

    const data = await res.json();
    setSaving(false);
    if (!res.ok) { setFormError(data.error ?? 'Save failed'); return; }
    setShowNew(false);
    setEditingComp(null);
    setFormError('');
    fetchTypes();
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="font-bold text-sm text-slate-900">Statutory Deadline Database</div>
        <div className="flex gap-2">
          {canSuggest && (
            <button onClick={() => { setResubmitComp(null); setShowSuggest(true); }}
              className="btn-secondary flex items-center gap-1.5">
              <Plus size={13} /> Suggest Filing Type
            </button>
          )}
          {user.can_edit_compliance_master && (
            <button onClick={openNew} className="btn-primary flex items-center gap-1.5">
              <Plus size={13} /> Add Filing Type
            </button>
          )}
        </div>
      </div>

      {/* My Suggestions — non-Super Masters */}
      {canSuggest && myCompReqs.length > 0 && (
        <div className="mb-4">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">My Suggestions</div>
          <div className="flex flex-col gap-1.5">
            {myCompReqs.map(r => (
              <div key={r.id} className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl px-4 py-2.5">
                <span className="font-bold text-xs text-slate-800 flex-1">{r.filing_type}</span>
                <span className="text-[10px] text-slate-500">{r.filing_category} · {r.frequency}</span>
                {r.request_status === 'Rejected' && r.rejection_remarks && (
                  <span className="text-[10px] text-red-600 bg-red-50 border border-red-200 rounded px-2 py-0.5 max-w-[200px] truncate">
                    {r.rejection_remarks}
                  </span>
                )}
                <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold flex-shrink-0 ${
                  r.request_status === 'Pending' ? 'bg-amber-50 text-amber-700' : 'bg-red-50 text-red-600'
                }`}>{r.request_status}</span>
                {r.request_status === 'Rejected' && (
                  <button onClick={() => { setResubmitComp(r); setShowSuggest(true); }}
                    className="btn-secondary py-0.5 px-2 text-[10px] flex-shrink-0">Resubmit</button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Suggest Filing Type Modal */}
      {showSuggest && (
        <RequestComplianceModal
          prefill={resubmitComp}
          onClose={() => { setShowSuggest(false); setResubmitComp(null); }}
          onRefresh={fetchMyCompReqs}
        />
      )}

      <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-xl px-4 py-2.5 mb-4 text-xs text-red-600">
        <AlertTriangle size={13} />
        All modifications are recorded in the Audit Trail and attributed to your account.
      </div>

      {/* Add / Edit Form */}
      {showNew && user.can_edit_compliance_master && (
        <form onSubmit={saveType} className="card p-4 mb-4 flex flex-col gap-3 border-blue-200 bg-blue-50/40">
          <div className="font-semibold text-xs text-slate-700">
            {editingComp ? `Edit: ${editingComp.filing_type}` : 'Add New Filing Type'}
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Filing Category — dropdown from departments */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Filing Category</label>
              <select className="input-base" value={form.filing_category}
                onChange={e => setForm(f => ({ ...f, filing_category: e.target.value }))}>
                <option value="">Select…</option>
                {departments.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>

            {/* Filing Type — free text */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Filing Type</label>
              <input type="text" className="input-base" placeholder="e.g. GSTR-3B"
                value={form.filing_type} onChange={e => setForm(f => ({ ...f, filing_type: e.target.value }))} />
            </div>
          </div>

          {/* Frequency — structured picker */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Frequency</label>
            <FrequencyInput value={form.frequency} onChange={v => setForm(f => ({ ...f, frequency: v }))} />
          </div>

          {/* Due Date Rule — structured builder */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Due Date Rule</label>
            <DueDateRuleInput value={form.due_date_rule} onChange={v => setForm(f => ({ ...f, due_date_rule: v }))} />
          </div>

          {/* Applicability notes */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Applicability Notes <span className="normal-case font-normal text-slate-300">(optional)</span>
            </label>
            <input type="text" className="input-base" placeholder="e.g. Only for GST-registered clients"
              value={form.applicability_rules} onChange={e => setForm(f => ({ ...f, applicability_rules: e.target.value }))} />
          </div>

          {formError && (
            <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{formError}</div>
          )}
          <div className="flex gap-2">
            <button type="submit" disabled={saving} className="btn-primary">
              {saving ? 'Saving…' : editingComp ? 'Save Changes' : 'Save'}
            </button>
            <button type="button" onClick={() => { setShowNew(false); setEditingComp(null); setFormError(''); }} className="btn-secondary">Cancel</button>
          </div>
        </form>
      )}

      <div className="flex flex-col gap-1.5">
        {types.map(ct => (
          <div key={ct.id} className="flex flex-col bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="flex items-center px-4 py-3 gap-3">
              <span className="font-bold text-xs w-36 flex-shrink-0">{ct.filing_type}</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold text-slate-700"
                style={{ background: deptBg[ct.filing_category] ?? DEPT_BG[ct.filing_category] ?? '#F1F5F9' }}>
                {ct.filing_category}
              </span>
              <span className="text-xs text-slate-500 flex-1">{ct.frequency} · Due: {ct.due_date_rule}</span>
              {ct.applicability_rules && (
                <span className="text-[10px] text-slate-400 hidden xl:block truncate max-w-[200px]">{ct.applicability_rules}</span>
              )}
              <span className="px-1.5 py-0.5 rounded-full text-[9px] font-bold flex-shrink-0"
                style={{ background: ct.status==='Active'?'#D1FAE5':'#F1F5F9', color: ct.status==='Active'?'#065F46':'#94A3B8' }}>
                {ct.status}
              </span>
              {user.can_edit_compliance_master && (
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => { openEdit(ct); setConfirmDeleteId(null); }}
                    className="text-slate-400 hover:text-blue-600 p-0.5 transition-colors">
                    <Pencil size={13} />
                  </button>
                  <button onClick={() => setConfirmDeleteId(confirmDeleteId === ct.id ? null : ct.id)}
                    className="text-slate-400 hover:text-red-500 p-0.5 transition-colors">
                    <Trash2 size={13} />
                  </button>
                </div>
              )}
            </div>
            {/* Inline delete confirmation */}
            {confirmDeleteId === ct.id && (
              <div className="flex items-center gap-3 px-4 py-2.5 bg-red-50 border-t border-red-200">
                <AlertTriangle size={13} className="text-red-500 flex-shrink-0" />
                <span className="text-xs text-red-600 flex-1">
                  Permanently delete <strong>{ct.filing_type}</strong>? This cannot be undone.
                </span>
                <button onClick={() => deleteType(ct.id)}
                  className="px-3 py-1 text-[11px] font-bold rounded bg-red-600 text-white hover:bg-red-700 transition-colors">
                  Delete
                </button>
                <button onClick={() => setConfirmDeleteId(null)}
                  className="px-3 py-1 text-[11px] font-semibold rounded border border-slate-300 text-slate-600 hover:bg-slate-100 transition-colors">
                  Cancel
                </button>
              </div>
            )}
          </div>
        ))}
        {types.length === 0 && <div className="text-sm text-slate-400 text-center py-8">No compliance types configured yet.</div>}
      </div>
    </div>
  );
}

/* ── Requests Tab (Super Master only) ────────────────────── */
function RequestsTab({ user, onBadgeChange }: { user: SessionUser; onBadgeChange: (n: number) => void }) {
  const { deptBg } = useDepartments();
  const [clientReqs,  setClientReqs]  = useState<ClientRequest[]>([]);
  const [compReqs,    setCompReqs]    = useState<ComplianceTypeRequest[]>([]);
  const [rejectId,    setRejectId]    = useState<string | null>(null);
  const [rejectType,  setRejectType]  = useState<'client' | 'compliance'>('client');
  const [remarks,     setRemarks]     = useState('');
  const [loading,     setLoading]     = useState(true);

  const fetchRequests = () => {
    fetch('/api/requests').then(r => r.json()).then(d => {
      setClientReqs(d.client_requests ?? []);
      setCompReqs(d.compliance_requests ?? []);
      onBadgeChange((d.client_requests?.length ?? 0) + (d.compliance_requests?.length ?? 0));
      setLoading(false);
    });
  };
  useEffect(fetchRequests, []);

  async function doAction(id: string, type: 'client' | 'compliance', action: 'approve' | 'reject') {
    if (action === 'reject' && !remarks.trim()) return;
    await fetch(`/api/requests/${id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, type, rejection_remarks: remarks }),
    });
    setRejectId(null);
    setRemarks('');
    fetchRequests();
  }

  if (loading) return <div className="text-slate-400 text-sm animate-pulse">Loading requests…</div>;

  const total = clientReqs.length + compReqs.length;

  return (
    <div>
      <div className="font-bold text-sm text-slate-900 mb-4">
        Pending Requests
        {total > 0 && <span className="ml-2 text-xs font-normal text-slate-400">({total} pending)</span>}
      </div>

      {total === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-slate-400">
          <Inbox size={32} className="mb-2 opacity-40" />
          <div className="text-sm">No pending requests</div>
        </div>
      )}

      {/* Client Requests */}
      {clientReqs.length > 0 && (
        <div className="mb-6">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">
            Client Addition Requests ({clientReqs.length})
          </div>
          <div className="flex flex-col gap-2">
            {clientReqs.map(r => (
              <div key={r.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="flex items-start gap-3 px-4 py-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-sm text-slate-800">{r.name}</span>
                      <span className="font-mono text-[10px] text-blue-600">{r.code}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-x-4 text-[10px] text-slate-500">
                      <span>PAN: {r.pan || '—'}</span>
                      <span>TAN: {r.tan || '—'}</span>
                      <span>CIN: {r.cin || '—'}</span>
                      <span>Constitution: {r.constitution}</span>
                      <span>Status: {r.client_status}</span>
                      <span>PAN Status: {r.pan_status}</span>
                    </div>
                    {r.departments?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {r.departments.map(d => (
                          <span key={d} className="px-1.5 py-0.5 rounded text-[9px] font-semibold text-slate-700"
                            style={{ background: deptBg[d] ?? DEPT_BG[d] ?? '#F1F5F9' }}>{d}</span>
                        ))}
                      </div>
                    )}
                    <div className="text-[10px] text-slate-400 mt-1.5">
                      Requested by <strong>{r.requester_name ?? r.requested_by}</strong> · {new Date(r.requested_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <button onClick={() => doAction(r.id, 'client', 'approve')}
                      className="btn-primary py-1 px-3 text-xs">✓ Approve</button>
                    <button onClick={() => { setRejectId(r.id); setRejectType('client'); setRemarks(''); }}
                      className="btn-danger py-1 px-3 text-xs">✗ Reject</button>
                  </div>
                </div>
                {rejectId === r.id && (
                  <div className="px-4 pb-3 flex gap-2">
                    <input type="text" className="input-base flex-1 text-xs"
                      placeholder="Rejection reason (required)…"
                      value={remarks} onChange={e => setRemarks(e.target.value)} />
                    <button onClick={() => doAction(r.id, 'client', 'reject')}
                      disabled={!remarks.trim()}
                      className="btn-danger px-3 text-xs">Confirm Reject</button>
                    <button onClick={() => setRejectId(null)} className="btn-secondary text-xs">Cancel</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Compliance Type Requests */}
      {compReqs.length > 0 && (
        <div>
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">
            Compliance Type Suggestions ({compReqs.length})
          </div>
          <div className="flex flex-col gap-2">
            {compReqs.map(r => (
              <div key={r.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="flex items-start gap-3 px-4 py-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-sm text-slate-800">{r.filing_type}</span>
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-semibold text-slate-700"
                        style={{ background: deptBg[r.filing_category] ?? DEPT_BG[r.filing_category] ?? '#F1F5F9' }}>
                        {r.filing_category}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500">
                      {r.frequency} · Due: {r.due_date_rule}
                    </div>
                    {r.applicability_rules && (
                      <div className="text-[10px] text-slate-400 mt-0.5 italic">{r.applicability_rules}</div>
                    )}
                    <div className="text-[10px] text-slate-400 mt-1.5">
                      Requested by <strong>{r.requester_name ?? r.requested_by}</strong> · {new Date(r.requested_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <button onClick={() => doAction(r.id, 'compliance', 'approve')}
                      className="btn-primary py-1 px-3 text-xs">✓ Approve</button>
                    <button onClick={() => { setRejectId(r.id); setRejectType('compliance'); setRemarks(''); }}
                      className="btn-danger py-1 px-3 text-xs">✗ Reject</button>
                  </div>
                </div>
                {rejectId === r.id && (
                  <div className="px-4 pb-3 flex gap-2">
                    <input type="text" className="input-base flex-1 text-xs"
                      placeholder="Rejection reason (required)…"
                      value={remarks} onChange={e => setRemarks(e.target.value)} />
                    <button onClick={() => doAction(r.id, 'compliance', 'reject')}
                      disabled={!remarks.trim()}
                      className="btn-danger px-3 text-xs">Confirm Reject</button>
                    <button onClick={() => setRejectId(null)} className="btn-secondary text-xs">Cancel</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ── System Config Tab ────────────────────────────────────── */
function SystemTab({ user }: { user: SessionUser }) {
  const CONFIG = [
    { label: 'Organisation Name',       value: 'Agarwal Taxcon Private Limited' },
    { label: 'System Version',          value: 'v2.1' },
    { label: 'Fiscal Year',             value: 'April – March' },
    { label: 'Default Priority',        value: 'Medium' },
    { label: 'Session Timeout',         value: '8 hours' },
    { label: 'Audit Log Retention',     value: '7 years (immutable)' },
    { label: 'Task Reminder Lead Time', value: '3 days before due date' },
    { label: 'Max Login Attempts',      value: '5 (then auto-lock)' },
    { label: 'Password Policy',         value: 'Force reset on first login' },
  ];

  return (
    <div>
      <div className="font-bold text-sm text-slate-900 mb-4">System Configuration</div>
      <div className="flex flex-col gap-2">
        {CONFIG.map(item => (
          <div key={item.label} className="flex items-center bg-white border border-slate-200 rounded-xl px-4 py-3 gap-3">
            <span className="font-semibold text-xs text-slate-500 w-52 flex-shrink-0">{item.label}</span>
            <span className="text-xs text-slate-800 flex-1">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
