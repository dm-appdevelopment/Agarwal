'use client';
import { useEffect, useState, useCallback } from 'react';
import { Search, Plus, UserCheck } from 'lucide-react';
import { STATUS_COLOR, STATUS_LABEL, PRIO_COLOR, daysUntil, DEPT_BG } from '@/lib/utils';
import { useDepartments } from '@/lib/hooks';
import { useTasksRealtime } from '@/lib/useTasksRealtime';
import TaskDetail from './TaskDetail';
import AssignTaskModal from './AssignTaskModal';
import type { SessionUser, Task } from '@/types';

export default function TaskManager({ user }: { user: SessionUser }) {
  const [tasks, setTasks]       = useState<Task[]>([]);
  const [selected, setSelected] = useState<Task | null>(null);
  const [showNew, setShowNew]   = useState(false);
  const [showSelf, setShowSelf] = useState(false);
  const [filters, setFilters]   = useState({ dept:'', priority:'', status:'', search:'' });
  const [loading, setLoading]   = useState(true);
  const { departments, deptBg } = useDepartments();

  const fetchTasks = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    const p = new URLSearchParams();
    if (filters.dept)     p.set('dept', filters.dept);
    if (filters.priority) p.set('priority', filters.priority);
    if (filters.status)   p.set('status', filters.status);
    if (filters.search)   p.set('search', filters.search);
    const res = await fetch(`/api/tasks?${p}`);
    const data = await res.json();
    setTasks(data.tasks ?? []);
    if (!silent) setLoading(false);
  }, [filters]);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  // Sync open TaskDetail panel when the list refreshes
  useEffect(() => {
    setSelected(prev => {
      if (!prev) return prev;
      const updated = tasks.find(t => t.id === prev.id);
      return updated ?? prev;
    });
  }, [tasks]);

  // Background refresh whenever another user inserts or updates a task
  useTasksRealtime(() => fetchTasks(true));

  async function advanceTask(task: Task) {
    await fetch(`/api/tasks/${task.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'advance' }),
    });
    fetchTasks();
  }

  const canAssign = ['Super Master','Admin','Team Lead'].includes(user.role);

  return (
    <div className="flex flex-col h-full bg-slate-50">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-4 py-2.5 bg-white border-b border-slate-200 flex-shrink-0">
        <div className="relative flex-shrink-0 w-52">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="w-full border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs outline-none focus:border-blue-400 bg-slate-50"
            placeholder="Search task or client…"
            value={filters.search}
            onChange={e => setFilters(f => ({ ...f, search: e.target.value }))} />
        </div>

        <select
          className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 bg-white outline-none focus:border-blue-400"
          value={filters.dept}
          onChange={e => setFilters(f => ({ ...f, dept: e.target.value === 'All Departments' ? '' : e.target.value }))}>
          <option value="">All Departments</option>
          {departments.map(d => <option key={d} value={d}>{d}</option>)}
        </select>

        {[
          { key:'priority', opts: ['All Priorities','High','Medium','Low'] },
          { key:'status',   opts: ['All Statuses','T0','T1','T2','T3'] },
        ].map(({ key, opts }) => (
          <select key={key}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 bg-white outline-none focus:border-blue-400"
            value={(filters as any)[key]}
            onChange={e => setFilters(f => ({ ...f, [key]: e.target.value.startsWith('All') ? '' : e.target.value }))}>
            {opts.map(o => <option key={o} value={o.startsWith('All') ? '' : o}>{o}</option>)}
          </select>
        ))}

        <div className="flex-1" />
        <span className="text-xs text-slate-400 font-semibold">{tasks.length} tasks</span>

        {/* Self-assign available to all roles */}
        <button onClick={() => setShowSelf(true)} className="btn-secondary flex items-center gap-1.5">
          <UserCheck size={13} /> Self-Assign
        </button>

        {canAssign && (
          <button onClick={() => setShowNew(true)} className="btn-primary flex items-center gap-1.5">
            <Plus size={13} /> Assign Task
          </button>
        )}
      </div>

      {/* Table */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center h-32 text-slate-400 text-sm animate-pulse">Loading…</div>
        ) : (
          <table className="w-full border-collapse">
            <thead>
              <tr>
                {['Client','Task Type','Dept','Assigned To','Priority','Status','Stamps','Due',''].map(h => (
                  <th key={h} className="th">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tasks.map(t => {
                const du = daysUntil(t.due);
                const isSelected = selected?.id === t.id;
                const bg = deptBg[t.dept] ?? DEPT_BG[t.dept] ?? '#F1F5F9';
                return (
                  <tr key={t.id}
                    onClick={() => setSelected(isSelected ? null : t)}
                    className="border-b border-slate-100 cursor-pointer hover:bg-slate-50 transition-colors"
                    style={{ background: isSelected ? '#EFF6FF' : undefined }}>
                    <td className="td">
                      <div className="font-semibold text-xs truncate max-w-[150px]">
                        {(t.client_name ?? '').slice(0,22)}{(t.client_name ?? '').length > 22 ? '…' : ''}
                      </div>
                    </td>
                    <td className="td">
                      <div className="text-xs">{t.type}</div>
                      <div className="flex flex-wrap gap-1 mt-0.5">
                        {t.assigned_by_role === 'Team Lead' && (
                          <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded bg-violet-50 text-violet-700 border border-violet-200 inline-block">
                            ↔ Cross-Lead
                          </span>
                        )}
                        {t.gstin_number && (
                          <span className="text-[9px] font-mono font-semibold px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 inline-block">
                            {t.gstin_number.slice(0, 15)}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="td">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold text-slate-700"
                        style={{ background: bg }}>{t.dept}</span>
                    </td>
                    <td className="td">
                      <div className="flex items-center gap-1.5">
                        <div className="w-5 h-5 rounded-full bg-blue-700 text-white text-[8px] font-bold flex items-center justify-center flex-shrink-0">
                          {(t.assigned_to_name ?? '??').slice(0,2).toUpperCase()}
                        </div>
                        <span className="text-xs truncate max-w-[90px]">{t.assigned_to_name ?? '—'}</span>
                      </div>
                    </td>
                    <td className="td">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold"
                        style={{ background: PRIO_COLOR[t.priority]+'22', color: PRIO_COLOR[t.priority] }}>{t.priority}</span>
                    </td>
                    <td className="td">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold border"
                        style={{ background: STATUS_COLOR[t.status]+'18', color: STATUS_COLOR[t.status], borderColor: STATUS_COLOR[t.status]+'44' }}>
                        {t.status}
                      </span>
                    </td>
                    <td className="td">
                      <div className="flex gap-1">
                        {(['t0','t1','t2','t3'] as const).map((s,i) => (
                          <div key={s} title={t[s] ?? 'Not yet'}
                            className="w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold"
                            style={{ background: t[s] ? STATUS_COLOR[`T${i}` as keyof typeof STATUS_COLOR] : '#E2E8F0', color: t[s] ? '#fff' : '#94A3B8' }}>
                            T{i}
                          </div>
                        ))}
                      </div>
                    </td>
                    <td className="td font-bold text-[11px]" style={{ color: du.color }}>{du.label}</td>
                    <td className="td" onClick={e => e.stopPropagation()}>
                      {(() => {
                        const isReviewer = ['Super Master','Admin','Team Lead'].includes(user.role);
                        const canAdvance =
                          t.status === 'T3' ? false :
                          t.status === 'T2' ? isReviewer :
                          t.status === 'T1' ? t.assigned_to === user.id :
                          isReviewer;
                        return canAdvance ? (
                          <button onClick={() => advanceTask(t)}
                            className="px-2 py-0.5 text-[10px] font-bold rounded border text-blue-700 border-blue-200 bg-blue-50 hover:bg-blue-100 whitespace-nowrap">
                            ▶ {({T0:'T1',T1:'T2',T2:'T3',T3:'T3'} as Record<string,string>)[t.status]}
                          </button>
                        ) : null;
                      })()}
                    </td>
                  </tr>
                );
              })}
              {tasks.length === 0 && (
                <tr><td colSpan={9} className="td text-center text-slate-400 py-12">No tasks match the current filters.</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      {selected && (
        <TaskDetail task={selected} user={user} onClose={() => setSelected(null)} onRefresh={fetchTasks} />
      )}

      {showNew && (
        <AssignTaskModal user={user} onClose={() => setShowNew(false)} onRefresh={fetchTasks} />
      )}

      {showSelf && (
        <AssignTaskModal user={user} selfAssign onClose={() => setShowSelf(false)} onRefresh={fetchTasks} />
      )}
    </div>
  );
}
