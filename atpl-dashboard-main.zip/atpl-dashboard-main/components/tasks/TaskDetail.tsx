'use client';
import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { STATUS_COLOR, STATUS_LABEL, PRIO_COLOR, DEPT_BG, formatDate } from '@/lib/utils';
import { useDepartments } from '@/lib/hooks';
import type { SessionUser, Task, Employee } from '@/types';

export default function TaskDetail({
  task, user, onClose, onRefresh
}: {
  task: Task; user: SessionUser; onClose: () => void; onRefresh: () => void;
}) {
  const isReviewer = ['Super Master','Admin','Team Lead'].includes(user.role);
  const { deptBg } = useDepartments();

  const [revertRemarks, setRevertRemarks] = useState('');
  const [showRevert, setShowRevert]       = useState(false);
  const [showReassign, setShowReassign]   = useState(false);
  const [reassignTo, setReassignTo]       = useState('');
  const [allUsers, setAllUsers]           = useState<Employee[]>([]);
  const [loading, setLoading]             = useState(false);

  useEffect(() => {
    if (isReviewer) {
      fetch('/api/users').then(r => r.json()).then(d => {
        const assignable = (d.users ?? []).filter((u: Employee) =>
          ['Employee', 'Team Lead'].includes(u.role) && u.status === 'Active' && u.id !== user.id
        );
        setAllUsers(assignable);
      });
    }
  }, []);

  async function doAction(action: string, extra?: object) {
    setLoading(true);
    const res = await fetch(`/api/tasks/${task.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...extra }),
    });
    setLoading(false);
    if (res.ok) { onRefresh(); onClose(); }
  }

  async function doReassign() {
    if (!reassignTo) return;
    await doAction('transfer', { assigned_to: reassignTo });
  }

  const isSuperMaster   = user.role === 'Super Master';
  const isAdmin         = user.role === 'Admin';
  const isAssigner      = task.assigned_by === user.id;
  const isCrossLead     = task.assigned_by_role === 'Team Lead';
  const isAssignedTL    = user.role === 'Team Lead' && task.assigned_to === user.id && !isCrossLead;

  // Two-stage approval logic
  const isSubAssigned      = !!task.sub_assigned_by && task.sub_assigned_by !== task.assigned_by;
  const isSubAssigner      = task.sub_assigned_by === user.id;
  const needsTLReview      = isSubAssigned && !task.tl_reviewed;
  // Only the actual sub-assigner sees TL Review button — Super Master can approve T3 directly
  const canDoTLReview      = task.status === 'T2' && needsTLReview && isSubAssigner;

  // T2→T3: only original assigner or Super Master, and only after TL review if sub-assigned
  const canApproveT3       = task.status === 'T2'
    && (isAssigner || isSuperMaster)
    && (!needsTLReview || isSuperMaster);

  const canAdvance =
    task.status === 'T3' ? false :
    task.status === 'T2' ? canApproveT3 :
    task.status === 'T1' ? task.assigned_to === user.id :
    isReviewer;

  const canManage   = isAssigner || isSuperMaster || isAdmin || isAssignedTL;
  // Reassign blocked at T2 (submitted for review) and T3 — revert first
  const canReassign = canManage && !['T2','T3'].includes(task.status) && !(isCrossLead && user.role === 'Team Lead');
  const canRevert   = canManage && task.status !== 'T0' && task.status !== 'T3';
  // Assignee can silently undo their own T2 submission (no remarks needed)
  const canUndoT2   = task.status === 'T2' && task.assigned_to === user.id;

  const stamps = [
    { key: 'T0', label: 'Received',    val: task.t0 },
    { key: 'T1', label: 'Allocated',   val: task.t1 },
    { key: 'T2', label: 'In Progress', val: task.t2 },
    { key: 'T3', label: 'Approved',    val: task.t3 },
  ];

  const nextLabel: Record<string, string> = { T0:'T1', T1:'T2', T2:'Approve (T3)' };

  return (
    <div className="fixed inset-0 z-50 flex justify-end" style={{ background: 'rgba(0,0,0,0.25)' }} onClick={onClose}>
      <div className="w-[440px] h-full bg-white flex flex-col shadow-2xl overflow-y-auto" onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="flex items-start justify-between px-4 py-3.5 border-b border-slate-200 flex-shrink-0">
          <div>
            <div className="font-bold text-slate-900 text-sm">{task.type}</div>
            <div className="text-xs text-slate-400 mt-0.5">{task.client_name}</div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={16} /></button>
        </div>

        <div className="p-4 flex flex-col gap-4 flex-1">

          {/* Badges */}
          <div className="flex flex-wrap gap-2">
            <span className="px-2.5 py-1 rounded text-xs font-bold border"
              style={{ background: STATUS_COLOR[task.status]+'18', color: STATUS_COLOR[task.status], borderColor: STATUS_COLOR[task.status]+'44' }}>
              {task.status} · {STATUS_LABEL[task.status]}
            </span>
            <span className="px-2.5 py-1 rounded text-xs font-semibold"
              style={{ background: PRIO_COLOR[task.priority]+'22', color: PRIO_COLOR[task.priority] }}>
              {task.priority} Priority
            </span>
            <span className="px-2.5 py-1 rounded text-xs font-semibold text-slate-700"
              style={{ background: deptBg[task.dept] ?? DEPT_BG[task.dept] ?? '#F1F5F9' }}>
              {task.dept}
            </span>
            {task.pending_from_client && (
              <span className="px-2.5 py-1 rounded text-xs font-semibold bg-orange-50 text-orange-600 border border-orange-200">
                ⏳ Pending from Client
              </span>
            )}
            {isCrossLead && (
              <span className="px-2.5 py-1 rounded text-xs font-semibold bg-violet-50 text-violet-700 border border-violet-200">
                ↔ Cross-Lead · {task.assigned_by_name ?? 'Team Lead'}
              </span>
            )}
            {isSubAssigned && (
              <span className={`px-2.5 py-1 rounded text-xs font-semibold border ${
                task.tl_reviewed
                  ? 'bg-green-50 text-green-700 border-green-200'
                  : 'bg-amber-50 text-amber-700 border-amber-200'
              }`}>
                {task.tl_reviewed ? '✓ TL Reviewed' : '⏳ Awaiting TL Review'}
              </span>
            )}
          </div>

          {/* Four-stamp timeline */}
          <div className="bg-slate-50 rounded-xl p-3">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Task Lifecycle</div>
            <div className="flex relative">
              <div className="absolute top-[14px] left-0 right-0 h-0.5 bg-slate-200" />
              {stamps.map(s => {
                const filled = !!s.val;
                const color  = STATUS_COLOR[s.key as keyof typeof STATUS_COLOR];
                return (
                  <div key={s.key} className="flex-1 flex flex-col items-center relative z-10">
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold"
                      style={{ background: filled ? color : '#E2E8F0', color: filled ? '#fff' : '#94A3B8' }}>
                      {s.key}
                    </div>
                    <div className="text-[10px] font-bold mt-1" style={{ color: filled ? color : '#94A3B8' }}>{s.label}</div>
                    <div className="text-[9px] text-slate-400 mt-0.5">{s.val ? formatDate(s.val) : '—'}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Info grid */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            {([
              ['Assigned To',     task.assigned_to_name ?? '—'],
              ['Assigned By',     task.assigned_by_name ?? '—'],
              ...(task.sub_assigned_by ? [['Sub-Assigned By', task.sub_assigned_by_name ?? task.sub_assigned_by]] : []),
              ['Due Date',     formatDate(task.due)],
              ['Department',   task.dept],
              ...(task.gstin_number ? [['GSTIN', `${task.gstin_number}${task.gstin_state ? ' · ' + task.gstin_state : ''}`]] : []),
              ...(task.gstin_return_frequency ? [['Return Freq.', task.gstin_return_frequency]] : []),
              ['Client Code',  task.client_code ?? '—'],
              ['Remarks',      task.remarks || 'None'],
              ['Revert Count', task.revert_count?.toString() ?? '0'],
            ] as [string, string][]).map(([label, val]) => (
              <div key={label} className="flex px-3 py-2 border-b border-slate-100 last:border-0">
                <span className="w-32 text-[10px] font-bold text-slate-400 uppercase tracking-wide flex-shrink-0">{label}</span>
                <span className="text-xs text-slate-700 font-medium">{val}</span>
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2">

            {/* TL Review button — shown to sub-assigner when task is at T2 and not yet reviewed */}
            {canDoTLReview && (
              <button onClick={() => doAction('tl_review')} disabled={loading}
                className="btn-primary bg-amber-500 hover:bg-amber-600 border-amber-500">
                ✓ Mark as TL Reviewed
              </button>
            )}

            {/* Sub-assigner has reviewed — tell them final approval is pending */}
            {task.status === 'T2' && isSubAssigner && task.tl_reviewed && (
              <div className="text-xs text-green-700 bg-green-50 border border-green-200 rounded-xl px-3 py-2.5">
                ✓ Your review is complete. <strong>{task.assigned_by_name ?? 'The original assigner'}</strong> will give final approval (T3).
              </div>
            )}

            {/* Awaiting TL review — shown to original assigner so they know why T3 is locked */}
            {task.status === 'T2' && isAssigner && needsTLReview && !isSuperMaster && (
              <button disabled className="btn-secondary opacity-60 cursor-not-allowed">
                ⏳ Awaiting TL Review by {task.sub_assigned_by_name ?? 'Team Lead'}
              </button>
            )}

            {/* Advance */}
            {canAdvance && (
              <button onClick={() => doAction('advance')} disabled={loading} className="btn-primary">
                ▶ {nextLabel[task.status] ? `Advance to ${nextLabel[task.status]}` : 'Advance'}
              </button>
            )}

            {/* Undo T2 — assignee can silently retract their own submission */}
            {canUndoT2 && (
              <button onClick={() => doAction('undo_t2')} disabled={loading}
                className="btn-secondary text-xs">
                ↩ Undo Submission
              </button>
            )}

            {/* Flag pending — assignee or assigner or Super Master */}
            {task.status !== 'T3' && (task.assigned_to === user.id || canManage) && (
              <button onClick={() => doAction('toggle_pending')} disabled={loading} className="btn-secondary">
                {task.pending_from_client ? '✓ Clear Pending Flag' : '⏳ Flag Pending from Client'}
              </button>
            )}

            {/* Reassign */}
            {canReassign && !showReassign && (
              <button onClick={() => { setShowReassign(true); setShowRevert(false); }}
                disabled={loading} className="btn-secondary">
                🔄 Reassign Task
              </button>
            )}
            {showReassign && (
              <div className="flex flex-col gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Reassign to</div>
                <select className="input-base" value={reassignTo} onChange={e => setReassignTo(e.target.value)}>
                  <option value="">Select employee…</option>
                  {allUsers.map(u => (
                    <option key={u.id} value={u.id}>
                      {u.full_name} ({u.role} · {u.departments?.join(', ')})
                    </option>
                  ))}
                </select>
                <div className="flex gap-2">
                  <button onClick={doReassign} disabled={!reassignTo || loading}
                    className="btn-primary flex-1">Confirm Reassign</button>
                  <button onClick={() => { setShowReassign(false); setReassignTo(''); }}
                    className="btn-secondary">Cancel</button>
                </div>
              </div>
            )}

            {/* Revert */}
            {canRevert && !showRevert && (
              <button onClick={() => { setShowRevert(true); setShowReassign(false); }}
                className="btn-danger">
                ↩ Revert with Remarks
              </button>
            )}
            {showRevert && (
              <div className="flex flex-col gap-2 mt-1">
                <textarea className="input-base h-16 resize-none"
                  placeholder="Mandatory: enter reason for reverting…"
                  value={revertRemarks} onChange={e => setRevertRemarks(e.target.value)} />
                <div className="flex gap-2">
                  <button onClick={() => { if (revertRemarks.trim()) doAction('revert', { remarks: revertRemarks }); }}
                    disabled={!revertRemarks.trim() || loading} className="btn-danger flex-1">
                    ↩ Confirm Revert
                  </button>
                  <button onClick={() => setShowRevert(false)} className="btn-secondary">Cancel</button>
                </div>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}
