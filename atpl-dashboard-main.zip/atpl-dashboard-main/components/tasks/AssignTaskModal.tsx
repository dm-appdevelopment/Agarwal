'use client';
import { useEffect, useState, useRef } from 'react';
import { X, ChevronDown } from 'lucide-react';
import { useDepartments } from '@/lib/hooks';
import type { SessionUser, Client, Employee, ComplianceType } from '@/types';

/* ── Searchable combobox ─────────────────────────────────── */
function SearchSelect({
  label, value, onChange, options, placeholder = 'Search or select…', disabled,
}: {
  label: string;
  value: string;
  onChange: (val: string) => void;
  options: { value: string; label: string }[];
  placeholder?: string;
  disabled?: boolean;
}) {
  const [query, setQuery] = useState('');
  const [open, setOpen]   = useState(false);
  const ref               = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const selected = options.find(o => o.value === value);
  const filtered = options.filter(o => o.label.toLowerCase().includes(query.toLowerCase()));

  function pick(o: { value: string; label: string }) {
    onChange(o.value); setQuery(''); setOpen(false);
  }
  function clear() { onChange(''); setQuery(''); }

  return (
    <div>
      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">{label}</label>
      <div ref={ref} className="relative">
        <div
          className={`input-base flex items-center gap-2 pr-8 ${disabled ? 'bg-slate-100 cursor-default' : 'cursor-pointer'}`}
          onClick={() => !disabled && setOpen(o => !o)}
        >
          {open && !disabled ? (
            <input autoFocus className="flex-1 outline-none bg-transparent text-xs"
              placeholder={placeholder} value={query}
              onChange={e => setQuery(e.target.value)} onClick={e => e.stopPropagation()} />
          ) : (
            <span className={`flex-1 text-xs truncate ${selected ? 'text-slate-800' : 'text-slate-400'}`}>
              {selected ? selected.label : placeholder}
            </span>
          )}
          {selected && !open && !disabled ? (
            <button type="button" onClick={e => { e.stopPropagation(); clear(); }}
              className="absolute right-7 text-slate-300 hover:text-slate-500">
              <X size={11} />
            </button>
          ) : null}
          <ChevronDown size={13} className="absolute right-2.5 text-slate-400 pointer-events-none" />
        </div>
        {open && !disabled && (
          <div className="absolute z-50 mt-1 w-full bg-white border border-slate-200 rounded-xl shadow-lg max-h-48 overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="px-3 py-3 text-xs text-slate-400">No matches found</div>
            ) : filtered.map(o => (
              <div key={o.value} onClick={() => pick(o)}
                className={`px-3 py-2 text-xs cursor-pointer hover:bg-blue-50 hover:text-blue-700 transition-colors
                  ${o.value === value ? 'bg-blue-50 text-blue-700 font-semibold' : 'text-slate-700'}`}>
                {o.label}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Main Modal ──────────────────────────────────────────── */
export default function AssignTaskModal({
  user, selfAssign = false, onClose, onRefresh,
}: {
  user: SessionUser; selfAssign?: boolean; onClose: () => void; onRefresh: () => void;
}) {
  const { departments } = useDepartments();
  const [clients, setClients]     = useState<Client[]>([]);
  const [users, setUsers]         = useState<Employee[]>([]);
  const [compTypes, setCompTypes] = useState<ComplianceType[]>([]);
  const [clientGstins, setClientGstins] = useState<{ id: string; gstin: string; state: string | null; return_frequency: string; gst_status: string }[]>([]);
  const [form, setForm] = useState({
    client_id: '', dept: '', type: '', compliance_type_id: '',
    assigned_to: selfAssign ? user.id : '',
    supervisor_id: '', gstin_id: '',
    priority: 'Medium', due: '', t0: '', remarks: '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState('');

  useEffect(() => {
    Promise.all([
      fetch('/api/clients').then(r => r.json()),
      fetch('/api/users').then(r => r.json()),
      fetch('/api/compliance-types').then(r => r.json()),
    ]).then(([c, u, ct]) => {
      setClients(c.clients ?? []);
      setCompTypes(ct.types ?? []);
      const all = u.users ?? [];
      setUsers(all.filter((usr: Employee) =>
        ['Employee','Team Lead'].includes(usr.role) && usr.status === 'Active' && usr.id !== user.id
      ));
    });
  }, []);

  // Filter assignable employees by selected department
  const assignableUsers = form.dept
    ? users.filter(u => u.departments?.includes(form.dept))
    : users;

  // Supervisors for self-assign: Team Lead+
  const supervisors = (users as Employee[]).concat(
    // include Admins and Super Masters from fresh fetch
    [] as Employee[]
  );

  // Separate supervisor fetch (Team Lead+)
  const [supervisorList, setSupervisorList] = useState<Employee[]>([]);
  useEffect(() => {
    if (selfAssign) {
      fetch('/api/users').then(r => r.json()).then(d => {
        setSupervisorList(
          (d.users ?? []).filter((u: Employee) =>
            ['Super Master','Admin','Team Lead'].includes(u.role) && u.status === 'Active'
          )
        );
      });
    }
  }, [selfAssign]);

  const filteredTypes = compTypes.filter(ct => !form.dept || ct.filing_category === form.dept);

  function fetchClientGstins(clientId: string) {
    if (!clientId) { setClientGstins([]); return; }
    fetch(`/api/clients/${clientId}`)
      .then(r => r.json())
      .then(d => setClientGstins(
        ((d.client?.gstins ?? []) as any[]).filter((g: any) => g.gst_status === 'Active')
      ));
  }

  function set(key: string, val: string) {
    if (key === 'client_id') {
      setForm(f => ({ ...f, client_id: val, gstin_id: '' }));
      fetchClientGstins(val);
      return;
    }
    if (key === 'dept') {
      setForm(f => ({ ...f, dept: val, compliance_type_id: '', type: '', assigned_to: selfAssign ? user.id : '', gstin_id: '' }));
      return;
    }
    if (key === 'compliance_type_id') {
      const ct = compTypes.find(c => c.id === val);
      setForm(f => ({ ...f, compliance_type_id: val, type: ct?.filing_type ?? f.type }));
      return;
    }
    setForm(f => ({ ...f, [key]: val }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.client_id || !form.type) { setError('Client and task type are required'); return; }
    if (selfAssign && !form.supervisor_id) { setError('Please select a supervisor'); return; }
    setSaving(true);
    const payload: any = {
      ...form,
      t0:                 form.t0  || null,
      due:                form.due || null,
      compliance_type_id: form.compliance_type_id || null,
      gstin_id:           form.gstin_id           || null,
      assigned_to:        form.assigned_to || null,
    };
    if (selfAssign) {
      payload.self_assign   = true;
      payload.assigned_to   = user.id;
      payload.supervisor_id = form.supervisor_id;
    }
    const res = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) { setError(data.error); setSaving(false); return; }
    onRefresh(); onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[480px] max-h-[90vh] overflow-y-auto shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
          <div>
            <div className="font-bold text-sm text-slate-900">
              {selfAssign ? 'Self-Assign Task' : 'Assign New Task'}
            </div>
            {selfAssign && (
              <div className="text-[10px] text-slate-400 mt-0.5">
                Task starts immediately · supervisor approves at T3
              </div>
            )}
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={16} /></button>
        </div>

        <form onSubmit={submit} className="p-5 flex flex-col gap-3.5">

          <SearchSelect
            label="Client *"
            value={form.client_id}
            onChange={v => set('client_id', v)}
            options={clients.map(c => ({ value: c.id, label: c.name }))}
            placeholder="Search client…"
          />

          <SearchSelect
            label="Department"
            value={form.dept}
            onChange={v => set('dept', v)}
            options={departments.map(d => ({ value: d, label: d }))}
            placeholder="Select department…"
          />

          <SearchSelect
            label="Filing Type (auto-fills from Compliance DB)"
            value={form.compliance_type_id}
            onChange={v => set('compliance_type_id', v)}
            options={filteredTypes.map(ct => ({ value: ct.id, label: `${ct.filing_type} (${ct.frequency})` }))}
            placeholder="Search filing type…"
          />

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Task Type / Custom Name *
            </label>
            <input type="text" className="input-base" placeholder="e.g. GSTR-3B Filing"
              value={form.type} onChange={e => set('type', e.target.value)} />
          </div>

          {/* GSTIN selector — only for GST dept with a client selected */}
          {form.dept === 'GST' && form.client_id && (
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                GSTIN <span className="font-normal normal-case text-slate-400">(optional)</span>
              </label>
              {clientGstins.length === 0 ? (
                <div className="text-xs text-slate-400 border border-dashed border-slate-200 rounded-lg px-3 py-2">
                  No active GSTINs found for this client — add them via Client Master
                </div>
              ) : (
                <select className="input-base font-mono text-xs"
                  value={form.gstin_id}
                  onChange={e => set('gstin_id', e.target.value)}>
                  <option value="">— Not specified —</option>
                  {clientGstins.map(g => (
                    <option key={g.id} value={g.id}>
                      {g.gstin}{g.state ? ` · ${g.state}` : ''} · {g.return_frequency}
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          {/* Self-assign: supervisor field; regular: assign-to field */}
          {selfAssign ? (
            <SearchSelect
              label="Supervisor (required — approves at T3) *"
              value={form.supervisor_id}
              onChange={v => set('supervisor_id', v)}
              options={supervisorList.map(u => ({ value: u.id, label: `${u.full_name} (${u.role})` }))}
              placeholder="Select supervisor…"
            />
          ) : (
            <SearchSelect
              label={form.dept ? `Assign To (${form.dept} team)` : 'Assign To'}
              value={form.assigned_to}
              onChange={v => set('assigned_to', v)}
              options={assignableUsers.map(u => ({ value: u.id, label: `${u.full_name} (${u.role} · ${u.departments?.join(', ')})` }))}
              placeholder={form.dept ? `Search ${form.dept} employees…` : 'Search employee…'}
            />
          )}

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Priority</label>
            <select className="input-base" value={form.priority} onChange={e => set('priority', e.target.value)}>
              {['High','Medium','Low'].map(p => <option key={p}>{p}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Due Date</label>
            <input type="date" className="input-base" value={form.due} onChange={e => set('due', e.target.value)} />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              T₀ — Client Request Date <span className="text-slate-300 font-normal normal-case">(optional)</span>
            </label>
            <input type="date" className="input-base" value={form.t0} onChange={e => set('t0', e.target.value)} />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Remarks</label>
            <textarea className="input-base h-16 resize-none" placeholder="Optional remarks…"
              value={form.remarks} onChange={e => set('remarks', e.target.value)} />
          </div>

          {error && <div className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</div>}

          <div className="flex gap-2 pt-1">
            <button type="submit" disabled={saving} className="btn-primary flex-1">
              {saving ? 'Saving…' : selfAssign ? 'Self-Assign Task' : 'Assign Task'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
