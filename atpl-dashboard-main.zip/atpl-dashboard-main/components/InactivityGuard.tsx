'use client';
import { useInactivityLogout } from '@/lib/useInactivityLogout';

function fmtTime(seconds: number): string {
  const m = Math.floor(seconds / 60).toString().padStart(2, '0');
  const s = (seconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

export default function InactivityGuard({ children }: { children: React.ReactNode }) {
  const { showWarning, remainingSeconds, resetTimer, doLogout } = useInactivityLogout();

  return (
    <>
      {children}

      {showWarning && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-[#0D2137] border border-slate-700 rounded-2xl p-8 w-[360px] shadow-2xl text-center">

            <div className="w-14 h-14 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto mb-4">
              <svg className="w-7 h-7 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                  d="M12 6v6l4 2M12 2a10 10 0 100 20A10 10 0 0012 2z" />
              </svg>
            </div>

            <h2 className="text-white font-semibold text-base mb-1">Session Expiring</h2>
            <p className="text-slate-400 text-sm mb-5">
              No activity detected. You&apos;ll be signed out in
            </p>

            <div className="text-4xl font-mono font-bold text-amber-400 mb-6 tabular-nums">
              {fmtTime(remainingSeconds)}
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => doLogout()}
                className="flex-1 px-4 py-2.5 rounded-lg border border-slate-600 text-slate-300 text-sm hover:bg-slate-700/50 transition-colors"
              >
                Sign out now
              </button>
              <button
                onClick={resetTimer}
                className="flex-1 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium transition-colors"
              >
                Stay signed in
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
}
