'use client';
import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { DEPT_COLOR, daysUntil, formatDate } from '@/lib/utils';
import { useDepartments } from '@/lib/hooks';
import type { SessionUser, ComplianceScheduleItem } from '@/types';

export default function CalendarView({ user }: { user: SessionUser }) {
  const [items, setItems]       = useState<ComplianceScheduleItem[]>([]);
  const [viewDate, setViewDate] = useState(new Date());
  const [selected, setSelected] = useState<ComplianceScheduleItem | null>(null);
  const [loading, setLoading]   = useState(true);
  const { deptColor, departments } = useDepartments();

  const year     = viewDate.getFullYear();
  const month    = viewDate.getMonth();
  const monthKey = `${year}-${String(month + 1).padStart(2,'0')}`;

  useEffect(() => {
    setLoading(true);
    fetch(`/api/compliance?month=${monthKey}`)
      .then(r => r.json())
      .then(d => { setItems(d.items ?? []); setLoading(false); })
      .catch(() => setLoading(false));
  }, [monthKey]);

  const pad = (n: number) => String(n).padStart(2,'0');
  const isoDate = (d: number) => `${year}-${pad(month+1)}-${pad(d)}`;
  const today   = new Date().toISOString().split('T')[0];

  const firstDay    = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthName   = viewDate.toLocaleString('default', { month: 'long', year: 'numeric' });

  const getDeptColor = (dept: string) => deptColor[dept] ?? DEPT_COLOR[dept] ?? '#64748B';

  const eventsByDate: Record<string, ComplianceScheduleItem[]> = {};
  items.forEach(c => {
    const key = c.due_date ?? '';
    if (!eventsByDate[key]) eventsByDate[key] = [];
    eventsByDate[key].push(c);
  });

  const upcoming = [...items]
    .filter(c => (c.due_date ?? '') >= today)
    .sort((a,b) => (a.due_date ?? '').localeCompare(b.due_date ?? ''))
    .slice(0,12);

  return (
    <div className="flex h-full overflow-hidden bg-slate-50">
      {/* Left panel — upcoming list */}
      <div className="w-52 border-r border-slate-200 bg-white flex flex-col flex-shrink-0">
        <div className="px-3 py-2.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-200 bg-slate-50">
          Upcoming Deadlines
        </div>
        <div className="overflow-y-auto flex-1">
          {loading ? (
            <div className="p-4 text-xs text-slate-400 animate-pulse">Loading…</div>
          ) : upcoming.length === 0 ? (
            <div className="p-4 text-xs text-slate-400">No upcoming deadlines</div>
          ) : upcoming.map(c => {
            const du    = daysUntil(c.due_date);
            const deptC = getDeptColor(c.dept ?? '');
            const isGeneric = (c as any).item_source === 'compliance_type';
            return (
              <div key={c.id}
                onClick={() => setSelected(c)}
                className="px-3 py-2.5 border-b border-slate-100 cursor-pointer hover:bg-slate-50 transition-colors"
                style={{ borderLeft: `3px solid ${deptC}`, background: selected?.id === c.id ? '#EFF6FF' : undefined }}>
                <div className="font-semibold text-xs text-slate-800 truncate">{c.filing_type ?? c.period}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {isGeneric ? <span className="italic">{c.client_name}</span> : c.client_name} · {c.dept}
                </div>
                <div className="text-[10px] font-bold mt-1" style={{ color: du.color }}>{du.label} · {formatDate(c.due_date)}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Calendar area */}
      <div className="flex-1 flex flex-col overflow-auto p-4">
        {/* Nav */}
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => setViewDate(new Date(year, month - 1, 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600">
            <ChevronLeft size={16} />
          </button>
          <span className="font-bold text-base text-slate-800">{monthName}</span>
          <button onClick={() => setViewDate(new Date(year, month + 1, 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600">
            <ChevronRight size={16} />
          </button>
        </div>

        {/* Day headers */}
        <div className="grid grid-cols-7 gap-1 mb-1">
          {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
            <div key={d} className="text-center text-[10px] font-bold text-slate-400 uppercase tracking-wider py-1">{d}</div>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-7 gap-1 flex-1">
          {Array.from({ length: firstDay }).map((_,i) => (
            <div key={`e${i}`} className="rounded-lg min-h-[80px] bg-slate-50 border border-slate-100" />
          ))}
          {Array.from({ length: daysInMonth }).map((_,i) => {
            const d      = i + 1;
            const iso    = isoDate(d);
            const events = eventsByDate[iso] ?? [];
            const isToday = iso === today;
            return (
              <div key={d}
                className="rounded-lg min-h-[80px] p-1.5 cursor-default"
                style={{
                  background: isToday ? '#EFF6FF' : '#fff',
                  border:     isToday ? '2px solid #1D4ED8' : '1px solid #E2E8F0',
                }}>
                <div className="text-[11px] mb-1 px-0.5 font-semibold"
                  style={{ color: isToday ? '#1D4ED8' : '#64748B', fontWeight: isToday ? 700 : 400 }}>
                  {d}
                </div>
                <div className="flex flex-col gap-0.5">
                  {events.slice(0,3).map(ev => {
                    const deptC     = getDeptColor(ev.dept ?? '');
                    const isGeneric = (ev as any).item_source === 'compliance_type';
                    return (
                      <div key={ev.id}
                        onClick={() => setSelected(ev)}
                        title={ev.filing_type ?? ev.period}
                        className="text-[9px] font-semibold px-1 py-0.5 rounded cursor-pointer truncate"
                        style={{
                          background:  deptC+'22',
                          color:       deptC,
                          borderLeft:  `2px solid ${deptC}`,
                          opacity:     isGeneric ? 0.75 : 1,
                        }}>
                        {(ev.filing_type ?? ev.period ?? '').slice(0,14)}
                      </div>
                    );
                  })}
                  {events.length > 3 && (
                    <div className="text-[9px] text-slate-400 px-0.5">+{events.length - 3} more</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-4 mt-3 pt-3 border-t border-slate-200">
          {departments.map(dept => {
            const color = getDeptColor(dept);
            return (
              <div key={dept} className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-sm" style={{ background: color }} />
                <span className="text-[10px] text-slate-500">{dept}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Event popup */}
      {selected && (
        <div className="absolute right-5 bottom-5 w-72 bg-white border border-slate-200 rounded-xl shadow-xl z-20 p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="font-bold text-sm text-slate-900">{selected.filing_type ?? selected.period}</div>
            <button onClick={() => setSelected(null)} className="text-slate-400 hover:text-slate-600"><X size={14} /></button>
          </div>
          {(selected as any).item_source === 'compliance_type' && (
            <div className="text-[10px] text-amber-600 bg-amber-50 border border-amber-200 rounded px-2 py-1 mb-2">
              General deadline — not yet scheduled for a specific client
            </div>
          )}
          {[
            ['Client',     selected.client_name ?? '—'],
            ['Period',     selected.period],
            ['Department', selected.dept ?? '—'],
            ['Due Date',   formatDate(selected.due_date)],
            ['Status',     selected.status],
          ].map(([l,v]) => (
            <div key={l} className="flex gap-2 py-1.5 border-b border-slate-100 last:border-0 text-xs">
              <span className="font-semibold text-slate-500 w-24 flex-shrink-0">{l}</span>
              <span className="text-slate-700">{v}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
