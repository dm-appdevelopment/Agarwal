'use client';
import { useEffect, useState, useCallback } from 'react';
import { Search, Download, PackageCheck } from 'lucide-react';
import { DEPT_BG, PRIO_COLOR, formatDate } from '@/lib/utils';
import type { SessionUser, Task } from '@/types';

/* ── helpers ─────────────────────────────────────────────── */
function subtractDays(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().split('T')[0];
}

function today(): string {
  return new Date().toISOString().split('T')[0];
}

function daysBetween(a: string | null, b: string | null): string {
  if (!a || !b) return '—';
  const diff = Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400000);
  return diff >= 0 ? `${diff}d` : '—';
}

const WINDOWS = [
  { label: 'Last 7 days',   days: 7 },
  { label: 'Last 30 days',  days: 30 },
  { label: 'Last 60 days',  days: 60 },
  { label: 'Last 90 days',  days: 90 },
  { label: 'Custom range',  days: 0 },
];

/* ── CSV export ──────────────────────────────────────────── */
function exportCSV(tasks: Task[], from: string, to: string) {
  const headers = [
    'Task ID', 'Client', 'Task Type', 'Department',
    'Assigned To (Maker)', 'Assigned By (Checker)',
    'T0 Received', 'T1 Allocated', 'T2 Submitted', 'T3 Approved',
    'T0→T1 (days)', 'T1→T2 (days)', 'T2→T3 (days)', 'Total (days)',
    'Revert Count', 'Due Date', 'Priority',
  ];

  const rows = tasks.map(t => [
    t.id,
    t.client_name ?? '',
    t.type,
    t.dept,
    t.assigned_to_name ?? '',
    t.assigned_by_name ?? '',
    t.t0 ?? '',
    t.t1 ?? '',
    t.t2 ?? '',
    t.t3 ?? '',
    daysBetween(t.t0, t.t1),
    daysBetween(t.t1, t.t2),
    daysBetween(t.t2, t.t3),
    daysBetween(t.t0, t.t3),
    t.revert_count?.toString() ?? '0',
    t.due ?? '',
    t.priority,
  ]);

  const csv = [headers, ...rows]
    .map(row => row.map(v => `"${String(v).replace(/"/g, '""')}"`).join(','))
    .join('\n');

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `completed-tasks-${from}-to-${to}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ── Main view ───────────────────────────────────────────── */
export default function CompletedView({ user }: { user: SessionUser }) {
  const [tasks, setTasks]       = useState<Task[]>([]);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState('');
  const [windowIdx, setWindowIdx] = useState(1); // default: last 30 days
  const [customFrom, setCustomFrom] = useState('');
  const [customTo,   setCustomTo]   = useState('');

  const isCustom = WINDOWS[windowIdx].days === 0;

  const dateFrom = isCustom ? customFrom : subtractDays(WINDOWS[windowIdx].days);
  const dateTo   = isCustom ? customTo   : today();

  const fetchTasks = useCallback(async () => {
    if (isCustom && (!customFrom || !customTo)) { setTasks([]); return; }
    setLoading(true);
    const p = new URLSearchParams({ status: 'T3', date_from: dateFrom, date_to: dateTo });
    if (search) p.set('search', search);
    const res  = await fetch(`/api/tasks?${p}`);
    const data = await res.json();
    setTasks(data.tasks ?? []);
    setLoading(false);
  }, [dateFrom, dateTo, search, isCustom, customFrom, customTo]);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  // Timesheet scope: Employee/Team Lead only see tasks they personally touched
  // Admin/Super Master see full dept/firm scope for reporting
  const visible = ['Super Master','Admin'].includes(user.role)
    ? tasks
    : tasks.filter(t => t.assigned_to === user.id || (t as any).assigned_by === user.id);

  const filtered = visible.filter(t =>
    !search ||
    t.type.toLowerCase().includes(search.toLowerCase()) ||
    (t.client_name ?? '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-slate-50">

      {/* Toolbar */}
      <div className="flex items-center gap-2 px-4 py-2.5 bg-white border-b border-slate-200 flex-shrink-0 flex-wrap">
        {/* Search */}
        <div className="relative w-52">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="w-full border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs outline-none focus:border-blue-400 bg-slate-50"
            placeholder="Search task or client…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        {/* Window picker */}
        <select className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 bg-white outline-none"
          value={windowIdx} onChange={e => setWindowIdx(Number(e.target.value))}>
          {WINDOWS.map((w, i) => <option key={i} value={i}>{w.label}</option>)}
        </select>

        {/* Custom date range */}
        {isCustom && (
          <>
            <input type="date" className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none"
              max={customTo || today()}
              min={subtractDays(90)}
              value={customFrom} onChange={e => setCustomFrom(e.target.value)} />
            <span className="text-xs text-slate-400">to</span>
            <input type="date" className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none"
              max={today()}
              min={customFrom || subtractDays(90)}
              value={customTo} onChange={e => setCustomTo(e.target.value)} />
          </>
        )}

        <div className="flex-1" />

        <span className="text-xs text-slate-400 font-semibold">{filtered.length} tasks</span>

        {/* Export CSV */}
        <button
          onClick={() => exportCSV(filtered, dateFrom, dateTo)}
          disabled={filtered.length === 0}
          className="btn-primary flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed">
          <Download size={13} />
          Export CSV
        </button>
      </div>

      {/* Info banner */}
      <div className="px-4 py-2 bg-emerald-50 border-b border-emerald-100 text-xs text-emerald-700 flex items-center gap-2 flex-shrink-0">
        <PackageCheck size={13} />
        Showing completed (T3 Approved) tasks · Max lookback 90 days ·
        CSV includes maker & checker details for timesheet reference
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto">
        {loading ? (
          <div className="flex items-center justify-center h-32 text-slate-400 text-sm animate-pulse">Loading…</div>
        ) : (
          <table className="w-full border-collapse">
            <thead>
              <tr>
                {['Task ID','Client','Task Type','Dept','Maker (Assigned To)','Checker (Assigned By)',
                  'T0','T1','T2','T3','T0→T1','T1→T2','T2→T3','Total','Reverts','Due','Priority'].map(h => (
                  <th key={h} className="th whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((t, i) => (
                <tr key={t.id} className="border-b border-slate-100"
                  style={{ background: i % 2 === 0 ? '#fff' : '#FAFAFA' }}>
                  <td className="td font-mono text-[10px] text-slate-500 whitespace-nowrap">{t.id}</td>
                  <td className="td text-xs font-semibold max-w-[130px] truncate">{t.client_name}</td>
                  <td className="td text-xs max-w-[140px] truncate">{t.type}</td>
                  <td className="td">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold text-slate-700"
                      style={{ background: DEPT_BG[t.dept] }}>{t.dept}</span>
                  </td>
                  <td className="td text-xs">{t.assigned_to_name ?? '—'}</td>
                  <td className="td text-xs">{t.assigned_by_name ?? '—'}</td>
                  <td className="td font-mono text-[10px] text-slate-500 whitespace-nowrap">{formatDate(t.t0)}</td>
                  <td className="td font-mono text-[10px] text-slate-500 whitespace-nowrap">{formatDate(t.t1)}</td>
                  <td className="td font-mono text-[10px] text-slate-500 whitespace-nowrap">{formatDate(t.t2)}</td>
                  <td className="td font-mono text-[10px] text-emerald-600 font-semibold whitespace-nowrap">{formatDate(t.t3)}</td>
                  <td className="td text-center text-[11px] text-slate-500">{daysBetween(t.t0, t.t1)}</td>
                  <td className="td text-center text-[11px] text-slate-500">{daysBetween(t.t1, t.t2)}</td>
                  <td className="td text-center text-[11px] text-slate-500">{daysBetween(t.t2, t.t3)}</td>
                  <td className="td text-center text-[11px] font-bold text-slate-700">{daysBetween(t.t0, t.t3)}</td>
                  <td className="td text-center text-[11px]">
                    <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                      (t.revert_count ?? 0) > 0 ? 'bg-red-50 text-red-500' : 'bg-slate-100 text-slate-400'}`}>
                      {t.revert_count ?? 0}
                    </span>
                  </td>
                  <td className="td font-mono text-[10px] text-slate-500 whitespace-nowrap">{formatDate(t.due)}</td>
                  <td className="td">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold"
                      style={{ background: PRIO_COLOR[t.priority]+'22', color: PRIO_COLOR[t.priority] }}>
                      {t.priority}
                    </span>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && !loading && (
                <tr><td colSpan={17} className="td text-center text-slate-400 py-12">
                  No completed tasks found for the selected period.
                </td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
