'use client';
import { useState } from 'react';
import { X } from 'lucide-react';
import { useDepartments } from '@/lib/hooks';
import type { ComplianceTypeRequest } from '@/types';

// ── Frequency picker (duplicated from SettingsView to keep modal self-contained) ──
const FREQ_PRESETS = ['Weekly','Monthly','Quarterly','Half Yearly','Yearly','Custom'] as const;

function FrequencyInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const isCustom    = !FREQ_PRESETS.slice(0,-1).includes(value as any);
  const customMatch = value.match(/^Every (\d+) (Days?|Months?|Years?)$/i);
  const [preset,     setPreset]     = useState<string>(isCustom ? 'Custom' : value);
  const [customN,    setCustomN]    = useState(customMatch?.[1] ?? '3');
  const [customUnit, setCustomUnit] = useState(customMatch?.[2] ?? 'Months');

  function build(n: string, unit: string) { return `Every ${n} ${unit}`; }
  function handlePreset(p: string) { setPreset(p); onChange(p === 'Custom' ? build(customN, customUnit) : p); }
  function handleCustom(n: string, unit: string) { setCustomN(n); setCustomUnit(unit); onChange(build(n, unit)); }

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <select className="input-base flex-1" value={preset} onChange={e => handlePreset(e.target.value)}>
        {FREQ_PRESETS.map(p => <option key={p}>{p}</option>)}
      </select>
      {preset === 'Custom' && (
        <>
          <span className="text-xs text-slate-500 flex-shrink-0">Every</span>
          <input type="number" min="1" className="input-base w-16"
            value={customN} onChange={e => handleCustom(e.target.value, customUnit)} />
          <select className="input-base" value={customUnit}
            onChange={e => handleCustom(customN, e.target.value)}>
            {['Days','Months','Years'].map(u => <option key={u}>{u}</option>)}
          </select>
        </>
      )}
    </div>
  );
}

const MONTHS_LIST = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const REF_OPTIONS = ['of same month','of following month','of the assessment year','of the following financial year','days after period end'] as const;

function ordinal(n: number): string {
  if (n % 100 >= 11 && n % 100 <= 13) return `${n}th`;
  if (n % 10 === 1) return `${n}st`;
  if (n % 10 === 2) return `${n}nd`;
  if (n % 10 === 3) return `${n}rd`;
  return `${n}th`;
}

function buildRule(day: string, ref: string, month: string): string {
  const d = Math.min(parseInt(day) || 1, 31);
  if (ref === 'days after period end')              return `${d} days after period end`;
  if (ref === 'of the assessment year')             return `${ordinal(d)} ${month} of the assessment year`;
  if (ref === 'of the following financial year')    return `${ordinal(d)} ${month} of the following financial year`;
  return `${ordinal(d)} ${ref}`;
}

function parseRule(rule: string): { day: string; ref: string; month: string } {
  const followMatch  = rule.match(/^(\d+)(?:st|nd|rd|th)? of following month$/i);
  if (followMatch)   return { day: followMatch[1],  ref: 'of following month',              month: 'July' };
  const sameMatch    = rule.match(/^(\d+)(?:st|nd|rd|th)? of same month$/i);
  if (sameMatch)     return { day: sameMatch[1],    ref: 'of same month',                   month: 'July' };
  const finYearMatch = rule.match(/^(\d+)(?:st|nd|rd|th)? (\w+) of the following financial year$/i);
  if (finYearMatch)  return { day: finYearMatch[1], ref: 'of the following financial year',  month: finYearMatch[2] };
  const yearMatch    = rule.match(/^(\d+)(?:st|nd|rd|th)? (\w+) of the (?:assessment )?year$/i);
  if (yearMatch)     return { day: yearMatch[1],    ref: 'of the assessment year',           month: yearMatch[2] };
  const daysAfter    = rule.match(/^(\d+) days? after period end$/i);
  if (daysAfter)     return { day: daysAfter[1],    ref: 'days after period end',            month: 'July' };
  return { day: '20', ref: 'of following month', month: 'July' };
}

function DueDateRuleInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const parsed = parseRule(value);
  const [day,   setDay]   = useState(parsed.day);
  const [ref,   setRef]   = useState(parsed.ref);
  const [month, setMonth] = useState(parsed.month);

  function update(d: string, r: string, m: string) { onChange(buildRule(d, r, m)); }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex gap-2 flex-wrap items-end">
        <div>
          <label className="block text-[9px] text-slate-400 mb-0.5">Day / Days</label>
          <input type="number" min="1" max="31" className="input-base w-16" value={day}
            onChange={e => { const v = String(Math.min(Math.max(parseInt(e.target.value)||1,1),31)); setDay(v); update(v,ref,month); }} />
        </div>
        <div className="flex-1 min-w-32">
          <label className="block text-[9px] text-slate-400 mb-0.5">Reference</label>
          <select className="input-base" value={ref}
            onChange={e => { setRef(e.target.value); update(day, e.target.value, month); }}>
            {REF_OPTIONS.map(r => <option key={r}>{r}</option>)}
          </select>
        </div>
        {(ref === 'of the assessment year' || ref === 'of the following financial year') && (
          <div>
            <label className="block text-[9px] text-slate-400 mb-0.5">Month</label>
            <select className="input-base" value={month}
              onChange={e => { setMonth(e.target.value); update(day, ref, e.target.value); }}>
              {MONTHS_LIST.map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
        )}
      </div>
      <div className="text-[10px] text-blue-600 bg-blue-50 px-2 py-1 rounded self-start">
        → {buildRule(day, ref, month)}
      </div>
    </div>
  );
}

// ── Main Modal ────────────────────────────────────────────────
interface Props {
  prefill?: ComplianceTypeRequest | null;
  onClose: () => void;
  onRefresh: () => void;
}

export default function RequestComplianceModal({ prefill, onClose, onRefresh }: Props) {
  const { departments } = useDepartments();
  const [form, setForm] = useState({
    filing_category:     prefill?.filing_category     ?? '',
    filing_type:         prefill?.filing_type         ?? '',
    frequency:           prefill?.frequency           ?? 'Monthly',
    due_date_rule:       prefill?.due_date_rule       ?? '20th of following month',
    applicability_rules: prefill?.applicability_rules ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState('');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.filing_category) { setError('Filing category is required'); return; }
    if (!form.filing_type.trim()) { setError('Filing type is required'); return; }
    setSaving(true);
    const res = await fetch('/api/requests/compliance-types', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) { setError(data.error ?? 'Submission failed'); return; }
    onRefresh();
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[560px] max-h-[90vh] overflow-y-auto shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div>
            <div className="font-bold text-sm text-slate-900">
              {prefill ? 'Resubmit Compliance Suggestion' : 'Suggest Filing Type'}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Submitted for Super Master approval</div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
        </div>

        <form onSubmit={submit} className="p-5 flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Filing Category *</label>
              <select className="input-base" value={form.filing_category}
                onChange={e => setForm(f => ({ ...f, filing_category: e.target.value }))}>
                <option value="">Select…</option>
                {departments.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Filing Type *</label>
              <input type="text" className="input-base" placeholder="e.g. GSTR-3B"
                value={form.filing_type} onChange={e => setForm(f => ({ ...f, filing_type: e.target.value }))} />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Frequency</label>
            <FrequencyInput value={form.frequency} onChange={v => setForm(f => ({ ...f, frequency: v }))} />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Due Date Rule</label>
            <DueDateRuleInput value={form.due_date_rule} onChange={v => setForm(f => ({ ...f, due_date_rule: v }))} />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Applicability Notes <span className="font-normal normal-case text-slate-400">(optional)</span>
            </label>
            <input type="text" className="input-base" placeholder="e.g. Only for GST-registered clients"
              value={form.applicability_rules} onChange={e => setForm(f => ({ ...f, applicability_rules: e.target.value }))} />
          </div>

          {error && <div className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</div>}

          <div className="flex gap-2 pt-1">
            <button type="submit" disabled={saving} className="btn-primary flex-1">
              {saving ? 'Submitting…' : prefill ? 'Resubmit Suggestion' : 'Submit Suggestion'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
