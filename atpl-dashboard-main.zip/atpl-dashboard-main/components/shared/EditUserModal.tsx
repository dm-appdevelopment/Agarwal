'use client';
import { useState } from 'react';
import { X } from 'lucide-react';
import { ROLE_COLOR } from '@/lib/utils';
import { useDepartments } from '@/lib/hooks';
import type { SessionUser, Employee } from '@/types';

export default function EditUserModal({ user, target, allUsers, onClose, onRefresh }: {
  user: SessionUser; target: Employee; allUsers: Employee[]; onClose: () => void; onRefresh: () => void;
}) {
  const { departments } = useDepartments();
  const [form, setForm] = useState({
    full_name:   target.full_name,
    role:        target.role,
    departments: target.departments ?? [],
    status:      target.status,
  });
  const [newPassword, setNewPassword] = useState('');
  const [teamMembers, setTeamMembers] = useState<string[]>(target.team_lead_scope ?? []);
  const [saving, setSaving]           = useState(false);
  const [error, setError]             = useState('');
  const [success, setSuccess]         = useState('');

  function toggleDept(d: string) {
    setForm(f => ({ ...f, departments: f.departments.includes(d) ? f.departments.filter(x => x !== d) : [...f.departments, d] }));
  }
  function toggleMember(id: string) {
    setTeamMembers(m => m.includes(id) ? m.filter(x => x !== id) : [...m, id]);
  }

  const employees = allUsers.filter(u => u.role === 'Employee');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true); setError(''); setSuccess('');
    const body: any = { action: 'update_profile', ...form };
    if (newPassword) body.new_password = newPassword;
    if (form.role === 'Team Lead') body.team_members = teamMembers;

    const res = await fetch(`/api/users/${target.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) { setError(data.error ?? 'Update failed'); return; }
    setSuccess('Profile updated successfully');
    onRefresh();
    setTimeout(onClose, 1000);
  }

  const canEditRole = user.role === 'Super Master';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[480px] shadow-2xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 sticky top-0 bg-white">
          <div>
            <div className="font-bold text-sm">Edit User</div>
            <div className="text-[10px] text-slate-400 mt-0.5">{target.username} · {target.id}</div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
        </div>

        <form onSubmit={submit} className="p-5 flex flex-col gap-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Full Name</label>
            <input type="text" className="input-base" value={form.full_name}
              onChange={e => setForm(f => ({...f, full_name: e.target.value}))} />
          </div>

          {canEditRole && (
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Role</label>
              <select className="input-base" value={form.role}
                onChange={e => setForm(f => ({...f, role: e.target.value as import('@/types').Role}))}>
                {['Admin','Team Lead','Employee'].map(r => <option key={r}>{r}</option>)}
              </select>
            </div>
          )}

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">Departments</label>
            <div className="flex flex-wrap gap-1.5">
              {departments.map(d => (
                <button type="button" key={d} onClick={() => toggleDept(d)}
                  className="px-2 py-0.5 rounded text-[10px] font-semibold border transition-all"
                  style={{
                    background:  form.departments.includes(d) ? '#1D4ED8' : '#F8FAFC',
                    color:       form.departments.includes(d) ? '#fff' : '#64748B',
                    borderColor: form.departments.includes(d) ? '#1D4ED8' : '#E2E8F0',
                  }}>
                  {d}
                </button>
              ))}
            </div>
          </div>

          {form.role === 'Team Lead' && (
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                Assign Team Members
              </label>
              <div className="border border-slate-200 rounded-lg max-h-40 overflow-y-auto divide-y divide-slate-100">
                {employees.length === 0 && <div className="text-xs text-slate-400 px-3 py-2">No employees available</div>}
                {employees.map(emp => (
                  <label key={emp.id} className="flex items-center gap-2.5 px-3 py-2 cursor-pointer hover:bg-slate-50">
                    <input type="checkbox" checked={teamMembers.includes(emp.id)}
                      onChange={() => toggleMember(emp.id)} className="accent-blue-600" />
                    <div className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[8px] font-bold flex-shrink-0"
                      style={{ background: ROLE_COLOR[emp.role] }}>{emp.avatar}</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-slate-800 truncate">{emp.full_name}</div>
                      <div className="text-[10px] text-slate-400">{emp.departments?.join(', ')}</div>
                    </div>
                  </label>
                ))}
              </div>
              {teamMembers.length > 0 && <div className="text-[10px] text-blue-600 mt-1">{teamMembers.length} member(s) selected</div>}
            </div>
          )}

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Status</label>
            <select className="input-base" value={form.status}
              onChange={e => setForm(f => ({...f, status: e.target.value as 'Active' | 'Inactive' | 'Offboarded'}))}>
              {['Active','Inactive'].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              New Password <span className="text-slate-300 font-normal normal-case">(leave blank to keep current)</span>
            </label>
            <input type="password" className="input-base" placeholder="Enter new password to reset"
              value={newPassword} onChange={e => setNewPassword(e.target.value)} />
          </div>

          {error   && <div className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</div>}
          {success && <div className="text-xs text-green-600 bg-green-50 border border-green-200 rounded-lg px-3 py-2">{success}</div>}

          <div className="flex gap-2 pt-1">
            <button type="submit" disabled={saving} className="btn-primary flex-1">{saving ? 'Saving…' : 'Save Changes'}</button>
            <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
