'use client';
import { useEffect, useState } from 'react';
import { X, Users, List } from 'lucide-react';
import { ROLE_COLOR, ROLE_BG } from '@/lib/utils';
import EditUserModal from '@/components/shared/EditUserModal';
import type { SessionUser, Employee } from '@/types';

interface EnrichedEmployee extends Employee {
  active_tasks:    number;
  completed_tasks: number;
  team_members:    string[];
  lead_id:         string | null;
}

export default function TeamView({ user }: { user: SessionUser }) {
  const [users, setUsers]         = useState<EnrichedEmployee[]>([]);
  const [allUsers, setAllUsers]   = useState<Employee[]>([]);
  const [selected, setSelected]   = useState<EnrichedEmployee | null>(null);
  const [editing, setEditing]     = useState<Employee | null>(null);
  const [tab, setTab]             = useState<'hierarchy'|'table'>('hierarchy');
  const [loading, setLoading]     = useState(true);

  const fetchTeam = () => {
    fetch('/api/team').then(r => r.json())
      .then(d => { setUsers(d.users ?? []); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => {
    fetchTeam();
    fetch('/api/users').then(r => r.json()).then(d => setAllUsers(d.users ?? []));
  }, []);

  const superMaster = users.find(u => u.role === 'Super Master');
  const admins      = users.filter(u => u.role === 'Admin');
  const leads       = users.filter(u => u.role === 'Team Lead');
  const employees   = users.filter(u => u.role === 'Employee');

  function getUser(id: string) { return users.find(u => u.id === id) ?? null; }

  const UserCard = ({ u, indent = 0 }: { u: EnrichedEmployee; indent?: number }) => {
    const active = selected?.id === u.id;
    return (
      <div style={{ marginLeft: indent * 20 }} className="mb-1">
        <div onClick={() => setSelected(active ? null : u)}
          className="flex items-center gap-2.5 px-3 py-2 rounded-xl cursor-pointer border transition-all"
          style={{
            border:     active ? '1.5px solid #1D4ED8' : '1px solid #E2E8F0',
            background: active ? '#EFF6FF' : '#fff',
          }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0"
            style={{ background: ROLE_COLOR[u.role] }}>
            {u.avatar}
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-semibold text-xs text-slate-900 truncate">{u.full_name}</div>
            <div className="text-[10px] text-slate-400">{u.departments?.join(', ') || u.role}</div>
          </div>
          <span className="px-2 py-0.5 rounded-full text-[9px] font-bold flex-shrink-0"
            style={{ background: ROLE_BG[u.role], color: ROLE_COLOR[u.role] }}>
            {u.role}
          </span>
          <div className="flex gap-2 text-[10px] flex-shrink-0">
            <span className="font-bold text-amber-500">{u.active_tasks} active</span>
            <span className="font-bold text-emerald-500">{u.completed_tasks} done</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-50">
      {/* Tab Bar */}
      <div className="flex gap-0 bg-white border-b border-slate-200 px-4 flex-shrink-0">
        {([['hierarchy','⎇  Hierarchy View', Users],['table','☰  Table View', List]] as const).map(([id,label]) => (
          <button key={id} onClick={() => setTab(id as any)}
            className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold transition-colors"
            style={{
              color:       tab === id ? '#1D4ED8' : '#64748B',
              borderBottom: tab === id ? '2px solid #1D4ED8' : '2px solid transparent',
            }}>
            {label}
          </button>
        ))}
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Main content */}
        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <div className="text-slate-400 text-sm animate-pulse">Loading team…</div>
          ) : tab === 'hierarchy' ? (
            <div>
              {superMaster && <UserCard u={superMaster} />}
              <div className="ml-4 pl-4 border-l-2 border-dashed border-slate-200 mt-2">
                {admins.map(admin => (
                  <div key={admin.id} className="mb-4">
                    <UserCard u={admin} />
                    <div className="ml-4 pl-4 border-l-2 border-dashed border-slate-200 mt-1">
                      {leads.map(lead => (
                        <div key={lead.id} className="mb-2">
                          <UserCard u={lead} />
                          <div className="ml-3">
                            {lead.team_members.map(mid => {
                              const emp = getUser(mid);
                              return emp ? <UserCard key={mid} u={emp} indent={1} /> : null;
                            })}
                          </div>
                        </div>
                      ))}
                      {/* Direct employees not under any lead */}
                      {employees.filter(e =>
                        !leads.some(l => l.team_members.includes(e.id))
                      ).map(emp => <UserCard key={emp.id} u={emp} indent={1} />)}
                    </div>
                  </div>
                ))}
                {/* Employees not under any lead and not already shown */}
                {employees.filter(e =>
                  !leads.some(l => l.team_members.includes(e.id)) && admins.length === 0
                ).map(emp => (
                  <UserCard key={emp.id} u={emp} />
                ))}
              </div>
            </div>
          ) : (
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  {['Name','Role','Department','Active Tasks','Completed','Team Lead',''].map(h => (
                    <th key={h} className="th">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {users.map(u => {
                  const lead = u.lead_id ? getUser(u.lead_id) : null;
                  return (
                    <tr key={u.id} onClick={() => setSelected(selected?.id === u.id ? null : u)}
                      className="border-b border-slate-100 cursor-pointer hover:bg-slate-50"
                      style={{ background: selected?.id === u.id ? '#EFF6FF' : undefined }}>
                      <td className="td">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-[9px] font-bold"
                            style={{ background: ROLE_COLOR[u.role] }}>{u.avatar}</div>
                          <span className="font-semibold text-xs">{u.full_name}</span>
                        </div>
                      </td>
                      <td className="td">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold"
                          style={{ background: ROLE_BG[u.role], color: ROLE_COLOR[u.role] }}>{u.role}</span>
                      </td>
                      <td className="td text-xs">{u.departments?.join(', ') || '—'}</td>
                      <td className="td font-bold text-amber-500">{u.active_tasks}</td>
                      <td className="td font-bold text-emerald-500">{u.completed_tasks}</td>
                      <td className="td text-xs">{lead ? lead.full_name : <span className="text-slate-300">—</span>}</td>
                      <td className="td" onClick={e => e.stopPropagation()}>
                        {user.role === 'Super Master' && (
                          <button onClick={e => { e.stopPropagation(); setEditing(u); }}
                            className="btn-secondary py-0.5 px-2 text-[10px]">Edit</button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Detail panel */}
        {selected && (
          <div className="w-72 border-l border-slate-200 bg-white flex-shrink-0 overflow-y-auto">
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-200 bg-slate-50">
              <div className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold"
                style={{ background: ROLE_COLOR[selected.role] }}>
                {selected.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-sm text-slate-900 truncate">{selected.full_name}</div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold"
                  style={{ background: ROLE_BG[selected.role], color: ROLE_COLOR[selected.role] }}>
                  {selected.role}
                </span>
              </div>
              <button onClick={() => setSelected(null)} className="text-slate-400 hover:text-slate-600"><X size={14} /></button>
            </div>

            <div className="p-4 flex flex-col gap-3">
              {[
                ['Department',      selected.departments?.join(', ') || '—'],
                ['Employee ID',     selected.id],
                ['Username',        selected.username],
                ['Active Tasks',    String(selected.active_tasks)],
                ['Completed Tasks', String(selected.completed_tasks)],
                ['Status',          selected.status],
                ['Joined',          selected.date_of_joining ?? '—'],
              ].map(([l,v]) => (
                <div key={l} className="flex justify-between py-1.5 border-b border-slate-100 last:border-0">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">{l}</span>
                  <span className="text-xs font-semibold text-slate-700">{v}</span>
                </div>
              ))}

              {selected.team_members.length > 0 && (
                <div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-2">Team Members</div>
                  {selected.team_members.map(mid => {
                    const e = getUser(mid);
                    return e ? (
                      <div key={mid} className="flex items-center gap-2 py-1.5 border-b border-slate-100 last:border-0">
                        <div className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[8px] font-bold flex items-center justify-center">{e.avatar}</div>
                        <span className="text-xs text-slate-700">{e.full_name}</span>
                      </div>
                    ) : null;
                  })}
                </div>
              )}

              {user.role === 'Super Master' && (
                <div className="flex flex-col gap-2 pt-2">
                  <button onClick={() => setEditing(selected)} className="btn-primary">Edit Profile</button>
                  <button onClick={async () => {
                    await fetch(`/api/users/${selected.id}`, {
                      method: 'PATCH',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ action: 'deactivate' }),
                    });
                    fetchTeam();
                    setSelected(null);
                  }} className="btn-danger">
                    {selected.status === 'Active' ? 'Deactivate User' : 'Activate User'}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {editing && (
        <EditUserModal
          user={user}
          target={editing}
          allUsers={allUsers}
          onClose={() => setEditing(null)}
          onRefresh={() => { fetchTeam(); fetch('/api/users').then(r => r.json()).then(d => setAllUsers(d.users ?? [])); }}
        />
      )}
    </div>
  );
}
