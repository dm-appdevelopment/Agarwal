'use client';
import { useEffect, useState } from 'react';
import { TrendingUp, Clock, AlertTriangle, Zap, CheckCircle } from 'lucide-react';
import { DEPT_BG, DEPT_COLOR, STATUS_COLOR, STATUS_LABEL, PRIO_COLOR, daysUntil, formatDate } from '@/lib/utils';
import type { SessionUser } from '@/types';

interface DashData {
  total: number; pending: number; overdue: number; highPrio: number; doneToday: number;
  deptStats: { dept: string; total: number; done: number; wip: number; pending: number }[];
  compliance: any[];
  recent: any[];
}

export default function HomeContent({ user }: { user: SessionUser }) {
  const [data, setData] = useState<DashData | null>(null);

  useEffect(() => {
    fetch('/api/dashboard').then(r => r.json()).then(setData).catch(() => {});
  }, []);

  if (!data) return (
    <div className="flex items-center justify-center h-full text-slate-400 text-sm">
      <span className="animate-pulse">Loading dashboard…</span>
    </div>
  );

  const kpis = [
    { label:'Total Tasks',    value: data.total,     icon: TrendingUp,    color:'#1D4ED8', bg:'#EFF6FF' },
    { label:'Pending',        value: data.pending,   icon: Clock,         color:'#F59E0B', bg:'#FFFBEB' },
    { label:'Overdue',        value: data.overdue,   icon: AlertTriangle, color:'#EF4444', bg:'#FEF2F2' },
    { label:'High Priority',  value: data.highPrio,  icon: Zap,           color:'#DC2626', bg:'#FEF2F2' },
    { label:'Approved Today', value: data.doneToday, icon: CheckCircle,   color:'#10B981', bg:'#F0FDF4' },
  ];

  return (
    <div className="flex flex-col gap-4 p-5 overflow-y-auto h-full">
      {/* KPI Row */}
      <div className="grid grid-cols-5 gap-3">
        {kpis.map(k => {
          const Icon = k.icon;
          return (
            <div key={k.label} className="rounded-xl border border-slate-200 p-4 flex flex-col gap-2" style={{ background: k.bg }}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{k.label}</span>
                <Icon size={14} style={{ color: k.color }} />
              </div>
              <div className="text-3xl font-black leading-none" style={{ color: k.color }}>{k.value}</div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Department Workload */}
        <div className="card">
          <div className="card-header">Department Workload</div>
          <table className="w-full border-collapse">
            <thead>
              <tr>
                {['Department','Total','Pending','In Progress','Approved'].map(h => (
                  <th key={h} className="th">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.deptStats.map(d => (
                <tr key={d.dept} className="border-b border-slate-100">
                  <td className="td">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold text-slate-700"
                      style={{ background: DEPT_BG[d.dept] }}>
                      {d.dept}
                    </span>
                  </td>
                  <td className="td text-center font-bold">{d.total}</td>
                  <td className="td text-center font-semibold text-amber-500">{d.pending}</td>
                  <td className="td text-center font-semibold text-blue-500">{d.wip}</td>
                  <td className="td text-center font-semibold text-emerald-500">{d.done}</td>
                </tr>
              ))}
              {data.deptStats.length === 0 && (
                <tr><td colSpan={5} className="td text-center text-slate-400 py-6">No tasks yet</td></tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Upcoming Deadlines */}
        <div className="card">
          <div className="card-header">Upcoming Deadlines</div>
          <div className="overflow-y-auto max-h-64">
            {(data.compliance ?? []).map((c: any) => {
              const du = daysUntil(c.due_date);
              const deptC = DEPT_COLOR[c.dept] ?? '#64748B';
              return (
                <div key={c.id} className="flex items-center px-3.5 py-2.5 border-b border-slate-100 last:border-0">
                  <div className="w-1 h-8 rounded-full mr-3 flex-shrink-0" style={{ background: deptC }} />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold text-slate-800 truncate">{c.filing_type ?? c.period}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{c.client_name ?? ''} · {c.dept}</div>
                  </div>
                  <div className="text-right flex-shrink-0 ml-3">
                    <div className="text-xs font-bold" style={{ color: du.color }}>{du.label}</div>
                    <div className="text-[10px] text-slate-400">{formatDate(c.due_date)}</div>
                  </div>
                </div>
              );
            })}
            {data.compliance?.length === 0 && (
              <div className="td text-center text-slate-400 py-6">No upcoming deadlines</div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Task Activity */}
      <div className="card">
        <div className="card-header">Recent Task Activity</div>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                {['Client','Task Type','Department','Assigned To','Priority','Status','Due Date'].map(h => (
                  <th key={h} className="th">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.recent.map(t => {
                const du = daysUntil(t.due);
                return (
                  <tr key={t.id} className="tr">
                    <td className="td font-medium truncate max-w-[160px]">{t.client_name}</td>
                    <td className="td">{t.type}</td>
                    <td className="td">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold text-slate-700" style={{ background: DEPT_BG[t.dept] }}>{t.dept}</span>
                    </td>
                    <td className="td">{t.assigned_to_name ?? '—'}</td>
                    <td className="td">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold" style={{ background: PRIO_COLOR[t.priority]+'22', color: PRIO_COLOR[t.priority] }}>{t.priority}</span>
                    </td>
                    <td className="td">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold border" style={{ background: STATUS_COLOR[t.status]+'18', color: STATUS_COLOR[t.status], borderColor: STATUS_COLOR[t.status]+'44' }}>
                        {t.status} · {STATUS_LABEL[t.status]}
                      </span>
                    </td>
                    <td className="td font-bold text-[11px]" style={{ color: du.color }}>{du.label}</td>
                  </tr>
                );
              })}
              {data.recent.length === 0 && (
                <tr><td colSpan={7} className="td text-center text-slate-400 py-8">No recent tasks</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
