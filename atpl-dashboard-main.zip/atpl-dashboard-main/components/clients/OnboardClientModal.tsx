'use client';
import { useState } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import { useDepartments } from '@/lib/hooks';
import { GSTIN_REG_TYPES, GSTIN_RETURN_FREQS, GSTIN_STATUSES, stateFromGstin, validateGstin } from '@/lib/gstin';
import type { SessionUser } from '@/types';

interface GstinRow {
  gstin: string;
  state: string;
  registration_type: string;
  return_frequency: string;
  gst_status: string;
  error: string;
}

function blankGstin(): GstinRow {
  return { gstin: '', state: '', registration_type: 'Regular', return_frequency: 'Monthly', gst_status: 'Active', error: '' };
}

export default function OnboardClientModal({
  user, onClose, onRefresh,
}: { user: SessionUser; onClose: () => void; onRefresh: () => void }) {
  const { departments } = useDepartments();
  const [form, setForm] = useState({
    code: '', name: '', pan: '', tan: '', cin: '',
    client_group: '', constitution: 'Pvt Ltd', status: 'Active',
    pan_status: 'Confirmed', departments: [] as string[],
  });
  const [gstins, setGstins] = useState<GstinRow[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState('');

  function set(key: string, val: string) { setForm(f => ({ ...f, [key]: val })); }

  function toggleDept(d: string) {
    setForm(f => ({
      ...f,
      departments: f.departments.includes(d) ? f.departments.filter(x => x !== d) : [...f.departments, d],
    }));
  }

  function addGstin() { setGstins(g => [...g, blankGstin()]); }
  function removeGstin(i: number) { setGstins(g => g.filter((_, idx) => idx !== i)); }

  function setGstinField(i: number, key: keyof GstinRow, val: string) {
    setGstins(g => g.map((row, idx) => {
      if (idx !== i) return row;
      const updated = { ...row, [key]: val };
      if (key === 'gstin') {
        updated.state = val.length >= 2 ? stateFromGstin(val) : row.state;
        updated.error = val.length === 15 ? validateGstin(val) : '';
      }
      return updated;
    }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.code || !form.name) { setError('Client Code and Name are required'); return; }
    const gstinErrors = gstins.filter(g => g.error || (g.gstin && validateGstin(g.gstin)));
    if (gstinErrors.length) { setError('Fix GSTIN validation errors before saving'); return; }

    setSaving(true);
    const res = await fetch('/api/clients', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...form,
        gstins: gstins.filter(g => g.gstin.trim()).map(({ error: _e, ...g }) => g),
      }),
    });
    const data = await res.json();
    if (!res.ok) { setError(data.error); setSaving(false); return; }
    onRefresh();
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[580px] max-h-[90vh] overflow-y-auto shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div className="font-bold text-sm text-slate-900">Onboard New Client</div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={16} /></button>
        </div>

        <form onSubmit={submit} className="p-5 flex flex-col gap-4">

          {/* Basic identifiers */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label:'Client Code *', key:'code',         placeholder:'e.g. GRP-MEHTA-01' },
              { label:'Client Name *', key:'name',         placeholder:'Full legal name' },
              { label:'PAN',           key:'pan',          placeholder:'AAAAA1234A' },
              { label:'TAN',           key:'tan',          placeholder:'AAAA12345A' },
              { label:'CIN / LLPIN',   key:'cin',          placeholder:'U74999MH2010PTC200123' },
              { label:'Client Group',  key:'client_group', placeholder:'e.g. Mehta Group' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">{f.label}</label>
                <input type="text" className="input-base" placeholder={f.placeholder}
                  value={(form as any)[f.key]} onChange={e => set(f.key, e.target.value)} />
              </div>
            ))}
          </div>

          {/* Dropdowns */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Constitution</label>
              <select className="input-base" value={form.constitution} onChange={e => set('constitution', e.target.value)}>
                {['Pvt Ltd','LLP','Partnership','Proprietorship','Individual','HUF','Trust','Section 8','Other'].map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Status</label>
              <select className="input-base" value={form.status} onChange={e => set('status', e.target.value)}>
                {['Active','Inactive','On Hold','New (Pre-PAN)'].map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">PAN Status</label>
              <select className="input-base" value={form.pan_status} onChange={e => set('pan_status', e.target.value)}>
                <option>Confirmed</option><option>Awaited</option>
              </select>
            </div>
          </div>

          {/* Departments */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Departments</label>
            <div className="flex flex-wrap gap-2">
              {departments.map(d => (
                <button type="button" key={d} onClick={() => toggleDept(d)}
                  className="px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all"
                  style={{
                    background:  form.departments.includes(d) ? '#1D4ED8' : '#F8FAFC',
                    color:       form.departments.includes(d) ? '#fff'    : '#64748B',
                    borderColor: form.departments.includes(d) ? '#1D4ED8' : '#E2E8F0',
                  }}>
                  {d}
                </button>
              ))}
            </div>
          </div>

          {/* GSTINs */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                GST Registrations <span className="font-normal normal-case text-slate-400">(optional)</span>
              </label>
              <button type="button" onClick={addGstin}
                className="flex items-center gap-1 text-[10px] font-semibold text-blue-600 hover:text-blue-800">
                <Plus size={11} /> Add GSTIN
              </button>
            </div>

            {gstins.length === 0 && (
              <div className="text-[11px] text-slate-400 border border-dashed border-slate-200 rounded-xl px-4 py-3 text-center">
                No GSTINs added yet — click "Add GSTIN" to register one
              </div>
            )}

            <div className="flex flex-col gap-3">
              {gstins.map((g, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-3 flex flex-col gap-2 bg-slate-50/50">
                  <div className="flex items-start gap-2">
                    {/* GSTIN number */}
                    <div className="flex-1">
                      <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">GSTIN *</label>
                      <input type="text" maxLength={15} placeholder="27AAAAA1234A1Z5"
                        className={`input-base font-mono text-xs ${g.error ? 'border-red-300' : ''}`}
                        value={g.gstin}
                        onChange={e => setGstinField(i, 'gstin', e.target.value.toUpperCase())} />
                      {g.error && <div className="text-[9px] text-red-500 mt-0.5">{g.error}</div>}
                    </div>
                    {/* State — auto-filled, read-only */}
                    <div className="w-40">
                      <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">State (auto)</label>
                      <input type="text" className="input-base text-xs bg-slate-100" readOnly
                        value={g.state} placeholder="Auto-filled from GSTIN" />
                    </div>
                    <button type="button" onClick={() => removeGstin(i)}
                      className="mt-5 text-slate-400 hover:text-red-500 transition-colors flex-shrink-0">
                      <Trash2 size={14} />
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">Registration Type</label>
                      <select className="input-base text-xs" value={g.registration_type}
                        onChange={e => setGstinField(i, 'registration_type', e.target.value)}>
                        {GSTIN_REG_TYPES.map(t => <option key={t}>{t}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">Return Frequency</label>
                      <select className="input-base text-xs" value={g.return_frequency}
                        onChange={e => setGstinField(i, 'return_frequency', e.target.value)}>
                        {GSTIN_RETURN_FREQS.map(f => <option key={f}>{f}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">GST Status</label>
                      <select className="input-base text-xs" value={g.gst_status}
                        onChange={e => setGstinField(i, 'gst_status', e.target.value)}>
                        {GSTIN_STATUSES.map(s => <option key={s}>{s}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {error && <div className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</div>}

          <div className="flex gap-2 pt-1">
            <button type="submit" disabled={saving} className="btn-primary flex-1">
              {saving ? 'Onboarding…' : 'Onboard Client'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
