'use client';
import { useEffect, useState, useCallback } from 'react';
import { Search, Plus, X, Download, Upload } from 'lucide-react';
import { DEPT_BG, STATUS_COLOR, STATUS_LABEL, DEPARTMENTS, daysUntil } from '@/lib/utils';
import { useDepartments } from '@/lib/hooks';
import OnboardClientModal from './OnboardClientModal';
import EditClientModal from './EditClientModal';
import ImportClientsModal from './ImportClientsModal';
import ImportGstinsModal from './ImportGstinsModal';
import ManageGstinsModal from './ManageGstinsModal';
import RequestClientModal from '@/components/requests/RequestClientModal';
import type { SessionUser, Client, Task, Gstin, ClientRequest } from '@/types';

const CSV_TEMPLATE_HEADERS = ['code','name','pan','tan','cin','client_group','constitution','status','pan_status','departments'];
const CSV_SAMPLE_ROW = ['GRP-MEHTA-01','Mehta Enterprises Pvt Ltd','AAAAA1234A','AAAA12345A','U74999MH2010PTC200123','Mehta Group','Pvt Ltd','Active','Confirmed','GST;Income Tax'];

function exportGstinTemplate() {
  const notes = [
    '# GSTIN IMPORT TEMPLATE — lines starting with # are ignored during import',
    '#',
    '# REQUIRED COLUMNS:',
    '#   client_code       - Must exactly match an existing client code in the system. Example: GRP-MEHTA-01',
    '#   gstin             - 15-character GSTIN. Example: 27AAAAA1234A1Z5',
    '#                       State is auto-derived from the first 2 digits — do not add a separate state column.',
    '#',
    '# OPTIONAL COLUMNS (defaults applied if left blank):',
    '#   registration_type - Regular | Composition | SEZ Developer | SEZ Unit | ISD | Non-Resident | OIDAR | Other',
    '#                       Default if blank: Regular',
    '#   return_frequency  - Monthly | Quarterly',
    '#                       Default if blank: Monthly',
    '#                       Use Quarterly for clients on the QRMP scheme.',
    '#   gst_status        - Active | Cancelled | Suspended',
    '#                       Default if blank: Active',
    '#',
    '# NOTE: Import clients first using the client template, then import GSTINs using this file.',
  ].join('\n');
  const header = 'client_code,gstin,registration_type,return_frequency,gst_status';
  const sample = 'GRP-MEHTA-01,27AAAAA1234A1Z5,Regular,Monthly,Active';
  const csv    = `${notes}\n${header}\n${sample}\n`;
  const blob   = new Blob([csv], { type: 'text/csv' });
  const url    = URL.createObjectURL(blob);
  const a      = document.createElement('a');
  a.href       = url;
  a.download   = 'gstin_import_template.csv';
  a.click();
  URL.revokeObjectURL(url);
}

function exportTemplate() {
  const header = CSV_TEMPLATE_HEADERS.join(',');
  const sample = CSV_SAMPLE_ROW.join(',');
  const notes  = [
    '# INSTRUCTIONS (lines starting with # are ignored during import):',
    '#',
    '# REQUIRED COLUMNS:',
    '#   code        - Unique client code. Example: GRP-MEHTA-01',
    '#   name        - Full legal name of the client. Example: Mehta Enterprises Pvt Ltd',
    '#',
    '# OPTIONAL COLUMNS:',
    '#   pan         - 10-character PAN. Example: AAAAA1234A  (leave blank if unknown)',
    '#   tan         - 10-character TAN. Example: AAAA12345A  (leave blank if not applicable)',
    '#   cin         - Company Identification Number or LLPIN. Example: U74999MH2010PTC200123',
    '#   client_group- Group name if client belongs to a business group. Example: Mehta Group',
    '#',
    '# FIXED-VALUE COLUMNS (must use one of the listed options exactly):',
    '#   constitution - Pvt Ltd | LLP | Partnership | Proprietorship | Individual | HUF | Trust | Section 8 | Other',
    '#                  Default if blank: Pvt Ltd',
    '#   status       - Active | Inactive | On Hold | New (Pre-PAN)',
    '#                  Default if blank: Active',
    '#   pan_status   - Confirmed | Awaited',
    '#                  Default if blank: Confirmed',
    '#',
    '# MULTI-VALUE COLUMN:',
    '#   departments  - Separate multiple departments with semicolons (;). Do NOT use commas.',
    '#                  Allowed values: GST | Income Tax | Audit | TDS | Company Law | NGO | Accounts',
    '#                  Example (single):   GST',
    '#                  Example (multiple): GST;Income Tax;TDS',
    '#                  Leave blank if no department is assigned yet.',
  ].join('\n');
  const csv  = `${notes}\n${header}\n${sample}\n`;
  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'client_import_template.csv';
  a.click();
  URL.revokeObjectURL(url);
}

export default function ClientMaster({ user }: { user: SessionUser }) {
  const [clients, setClients]   = useState<Client[]>([]);
  const [selected, setSelected] = useState<Client | null>(null);
  const [clientTasks, setClientTasks] = useState<Task[]>([]);
  const [showNew, setShowNew]                   = useState(false);
  const [editing, setEditing]                   = useState<Client | null>(null);
  const [showImport, setShowImport]             = useState(false);
  const [showImportGstins, setShowImportGstins] = useState(false);
  const [managingGstins, setManagingGstins]     = useState<Client | null>(null);
  const [showRequest, setShowRequest]           = useState(false);
  const [resubmitRequest, setResubmitRequest]   = useState<ClientRequest | null>(null);
  const [myRequests, setMyRequests]             = useState<ClientRequest[]>([]);

  const canRequestOnly = !user.can_onboard_clients; // Team Lead + Employee

  const fetchMyRequests = () => {
    if (!canRequestOnly) return;
    fetch('/api/requests').then(r => r.json()).then(d => setMyRequests(d.client_requests ?? []));
  };
  useEffect(fetchMyRequests, []);
  const { deptBg } = useDepartments();
  const [search, setSearch]     = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [loading, setLoading]   = useState(true);

  const fetchClients = useCallback(async () => {
    setLoading(true);
    const p = new URLSearchParams();
    if (search)     p.set('search', search);
    if (deptFilter) p.set('dept', deptFilter);
    const res = await fetch(`/api/clients?${p}`);
    const data = await res.json();
    setClients(data.clients ?? []);
    setLoading(false);
  }, [search, deptFilter]);

  useEffect(() => { fetchClients(); }, [fetchClients]);

  async function selectClient(c: Client) {
    if (selected?.id === c.id) { setSelected(null); setClientTasks([]); return; }
    setSelected(c);
    const res  = await fetch(`/api/clients/${c.id}`);
    const data = await res.json();
    setClientTasks(data.tasks ?? []);
    setSelected({ ...c, ...(data.client ?? {}) });
  }

  return (
    <div className="flex flex-col h-full bg-slate-50">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-4 py-2.5 bg-white border-b border-slate-200 flex-shrink-0">
        <div className="relative w-64">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="w-full border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs outline-none focus:border-blue-400 bg-slate-50"
            placeholder="Search by name, code or PAN…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 bg-white outline-none"
          value={deptFilter} onChange={e => setDeptFilter(e.target.value)}>
          <option value="">All Departments</option>
          {DEPARTMENTS.map(d => <option key={d}>{d}</option>)}
        </select>
        <div className="flex-1" />
        <span className="text-xs text-slate-400 font-semibold">{clients.length} clients</span>
        {canRequestOnly && (
          <button onClick={() => { setResubmitRequest(null); setShowRequest(true); }}
            className="btn-primary flex items-center gap-1.5">
            <Plus size={13} /> Request Client Addition
          </button>
        )}
        {user.can_onboard_clients && (
          <>
            <button onClick={exportTemplate} className="btn-secondary flex items-center gap-1.5">
              <Download size={13} /> Client Template
            </button>
            <button onClick={() => setShowImport(true)} className="btn-secondary flex items-center gap-1.5">
              <Upload size={13} /> Import Clients
            </button>
            {/* divider */}
            <div className="w-px h-5 bg-slate-200 flex-shrink-0" />
            <button onClick={exportGstinTemplate} className="btn-secondary flex items-center gap-1.5">
              <Download size={13} /> GSTIN Template
            </button>
            <button onClick={() => setShowImportGstins(true)} className="btn-secondary flex items-center gap-1.5">
              <Upload size={13} /> Import GSTINs
            </button>
            {/* divider */}
            <div className="w-px h-5 bg-slate-200 flex-shrink-0" />
            <button onClick={() => setShowNew(true)} className="btn-primary flex items-center gap-1.5">
              <Plus size={13} /> Onboard Client
            </button>
          </>
        )}
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Table + my-requests */}
        <div className="flex-1 overflow-y-auto">

          {/* My Requests panel — Team Lead / Employee only */}
          {canRequestOnly && myRequests.length > 0 && (
            <div className="p-4 border-b border-slate-200 bg-slate-50">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">My Client Requests</div>
              <div className="flex flex-col gap-2">
                {myRequests.map(r => (
                  <div key={r.id} className="flex items-start gap-3 bg-white border border-slate-200 rounded-xl px-4 py-3">
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-xs text-slate-800">{r.name} <span className="font-mono text-slate-400">({r.code})</span></div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{r.constitution} · {r.departments?.join(', ') || 'No departments'}</div>
                      {r.request_status === 'Rejected' && r.rejection_remarks && (
                        <div className="mt-1.5 text-[10px] text-red-600 bg-red-50 border border-red-200 rounded px-2 py-1">
                          Rejected: {r.rejection_remarks}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                        r.request_status === 'Pending'
                          ? 'bg-amber-50 text-amber-700'
                          : 'bg-red-50 text-red-600'
                      }`}>{r.request_status}</span>
                      {r.request_status === 'Rejected' && (
                        <button onClick={() => { setResubmitRequest(r); setShowRequest(true); }}
                          className="btn-secondary py-0.5 px-2 text-[10px]">
                          Resubmit
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {loading ? (
            <div className="flex items-center justify-center h-32 text-slate-400 text-sm animate-pulse">Loading…</div>
          ) : (
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  {['Code','Client Name','PAN','GSTIN','TAN','CIN / LLPIN','Departments','Active Tasks','Status',''].map(h => (
                    <th key={h} className="th">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {clients.map(c => {
                  const isSelected = selected?.id === c.id;
                  const activeTasks = clientTasks.filter(t => t.status !== 'T3').length;
                  return (
                    <tr key={c.id} onClick={() => selectClient(c)}
                      className="border-b border-slate-100 cursor-pointer hover:bg-slate-50 transition-colors"
                      style={{ background: isSelected ? '#EFF6FF' : undefined }}>
                      <td className="td font-mono text-[11px] text-blue-700 font-semibold">{c.code}</td>
                      <td className="td">
                        <div className="font-semibold text-xs">{c.name}</div>
                        {c.client_group && <div className="text-[10px] text-slate-400">{c.client_group}</div>}
                      </td>
                      <td className="td font-mono text-[11px]">{c.pan ?? <span className="text-slate-300">—</span>}</td>
                      <td className="td font-mono text-[10px] max-w-[120px] truncate">
                        {(c.gstins as any)?.[0]?.gstin ?? <span className="text-slate-300">—</span>}
                      </td>
                      <td className="td font-mono text-[11px]">{c.tan ?? <span className="text-slate-300">—</span>}</td>
                      <td className="td font-mono text-[10px]">{c.cin ?? <span className="text-slate-300">—</span>}</td>
                      <td className="td">
                        <div className="flex flex-wrap gap-1">
                          {(c.departments ?? []).map(d => (
                            <span key={d} className="px-1 py-0.5 rounded text-[9px] font-semibold text-slate-700" style={{ background: DEPT_BG[d] }}>{d}</span>
                          ))}
                        </div>
                      </td>
                      <td className="td text-center">
                        <span className="font-bold text-sm" style={{ color: isSelected && activeTasks > 0 ? '#1D4ED8' : activeTasks > 0 ? '#1D4ED8' : '#94A3B8' }}>
                          {isSelected ? activeTasks || '—' : '—'}
                        </span>
                      </td>
                      <td className="td">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold"
                          style={{ background: c.status === 'Active' ? '#D1FAE5' : '#F1F5F9', color: c.status === 'Active' ? '#065F46' : '#94A3B8' }}>
                          {c.status}
                        </span>
                      </td>
                      <td className="td" onClick={e => e.stopPropagation()}>
                        {user.role !== 'Employee' && (
                          <button onClick={() => setEditing(c)}
                            className="btn-secondary py-0.5 px-2 text-[10px]">Edit</button>
                        )}
                      </td>
                    </tr>
                  );
                })}
                {clients.length === 0 && (
                  <tr><td colSpan={10} className="td text-center text-slate-400 py-12">No clients found.</td></tr>
                )}
              </tbody>
            </table>
          )}
        </div>

        {/* Detail Sidebar */}
        {selected && (
          <div className="w-72 border-l border-slate-200 bg-white flex-shrink-0 flex flex-col overflow-y-auto">
            <div className="flex items-start justify-between px-4 py-3 border-b border-slate-200 bg-slate-50">
              <div>
                <div className="font-bold text-sm text-slate-900 leading-tight">{selected.name}</div>
                <div className="font-mono text-[10px] text-blue-600 mt-0.5">{selected.code}</div>
              </div>
              <button onClick={() => { setSelected(null); setClientTasks([]); }} className="text-slate-400 hover:text-slate-600"><X size={14} /></button>
            </div>

            <div className="p-4 flex flex-col gap-4">
              {/* Identifiers */}
              <section>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Identifiers</div>
                {[['PAN', selected.pan], ['TAN', selected.tan], ['CIN / LLPIN', selected.cin]].map(([l,v]) => (
                  <div key={l} className="flex justify-between py-1.5 border-b border-slate-100 last:border-0">
                    <span className="text-xs font-semibold text-slate-500">{l}</span>
                    <span className="font-mono text-[11px] text-slate-700">{v || '—'}</span>
                  </div>
                ))}
                {(selected.gstins as any[])?.length > 0 && (
                  <div className="py-1.5 border-b border-slate-100">
                    <div className="text-xs font-semibold text-slate-500 mb-1">GSTINs</div>
                    {(selected.gstins as any[]).map((g: any) => (
                      <div key={g.id} className="font-mono text-[10px] text-slate-600 py-0.5">{g.gstin}</div>
                    ))}
                  </div>
                )}
              </section>

              {/* Group */}
              {selected.client_group && (
                <section>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Group</div>
                  <div className="text-xs text-slate-700">{selected.client_group}</div>
                </section>
              )}

              {/* Departments */}
              <section>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Active Departments</div>
                <div className="flex flex-wrap gap-1.5">
                  {(selected.departments ?? []).map(d => (
                    <span key={d} className="px-2 py-0.5 rounded text-xs font-semibold text-slate-700"
                      style={{ background: deptBg[d] ?? DEPT_BG[d] ?? '#F1F5F9' }}>{d}</span>
                  ))}
                </div>
              </section>

              {/* GSTINs */}
              <section>
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    GST Registrations ({(selected.gstins as Gstin[])?.length ?? 0})
                  </div>
                  {user.can_onboard_clients && (
                    <button onClick={() => setManagingGstins(selected)}
                      className="text-[10px] font-semibold text-blue-600 hover:text-blue-800">
                      Manage
                    </button>
                  )}
                </div>
                {((selected.gstins as Gstin[]) ?? []).length === 0 ? (
                  <div className="text-xs text-slate-300">No GSTINs registered</div>
                ) : (
                  <div className="flex flex-col gap-2">
                    {((selected.gstins as Gstin[]) ?? []).map(g => {
                      const statusStyle = g.gst_status === 'Active'
                        ? { bg: '#D1FAE5', color: '#065F46' }
                        : g.gst_status === 'Cancelled'
                        ? { bg: '#FEE2E2', color: '#991B1B' }
                        : { bg: '#FEF3C7', color: '#92400E' };
                      return (
                        <div key={g.id} className="border border-slate-100 rounded-lg px-3 py-2 bg-slate-50">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-mono text-[11px] font-bold text-slate-800">{g.gstin}</span>
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                              style={{ background: statusStyle.bg, color: statusStyle.color }}>
                              {g.gst_status}
                            </span>
                          </div>
                          <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
                            {[
                              ['State',    g.state ?? '—'],
                              ['Type',     g.registration_type],
                              ['Freq.',    g.return_frequency],
                              ['ID',       g.id],
                            ].map(([l, v]) => (
                              <div key={l} className="flex gap-1">
                                <span className="text-[9px] text-slate-400 w-8 flex-shrink-0">{l}</span>
                                <span className="text-[9px] text-slate-600 font-medium truncate">{v}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>

              {/* Tasks */}
              <section>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Tasks ({clientTasks.length})</div>
                {clientTasks.slice(0, 6).map(t => {
                  const du = daysUntil(t.due);
                  return (
                    <div key={t.id} className="flex items-center py-2 border-b border-slate-100 last:border-0 gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-semibold text-slate-800 truncate">{t.type}</div>
                        <div className="text-[10px] text-slate-400">{t.dept} · <span style={{ color: du.color }}>{du.label}</span></div>
                      </div>
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold border flex-shrink-0"
                        style={{ background: STATUS_COLOR[t.status]+'18', color: STATUS_COLOR[t.status], borderColor: STATUS_COLOR[t.status]+'44' }}>
                        {t.status}
                      </span>
                    </div>
                  );
                })}
                {clientTasks.length === 0 && <div className="text-xs text-slate-400">No tasks yet</div>}
              </section>

              {user.role !== 'Employee' && (
                <button className="btn-primary w-full text-center">+ Assign Task to Client</button>
              )}
            </div>
          </div>
        )}
      </div>

      {showRequest && (
        <RequestClientModal
          prefill={resubmitRequest}
          onClose={() => { setShowRequest(false); setResubmitRequest(null); }}
          onRefresh={fetchMyRequests}
        />
      )}
      {showNew && (
        <OnboardClientModal user={user} onClose={() => setShowNew(false)} onRefresh={fetchClients} />
      )}
      {editing && (
        <EditClientModal client={editing} onClose={() => setEditing(null)} onRefresh={fetchClients} />
      )}
      {showImport && (
        <ImportClientsModal onClose={() => setShowImport(false)} onRefresh={fetchClients} />
      )}
      {showImportGstins && (
        <ImportGstinsModal onClose={() => setShowImportGstins(false)} onRefresh={fetchClients} />
      )}
      {managingGstins && (
        <ManageGstinsModal
          clientId={managingGstins.id}
          clientName={managingGstins.name}
          gstins={(managingGstins.gstins as Gstin[]) ?? []}
          onClose={() => setManagingGstins(null)}
          onRefresh={() => { fetchClients(); selectClient(managingGstins); }}
        />
      )}
    </div>
  );
}
