'use client';
import { useRef, useState } from 'react';
import { X, Upload, CheckCircle, AlertCircle } from 'lucide-react';

const HEADERS = ['code','name','pan','tan','cin','client_group','constitution','status','pan_status','departments'];

function parseCSV(text: string): Record<string, string>[] {
  const lines = text.trim().split(/\r?\n/).filter(l => !l.trimStart().startsWith('#'));
  if (lines.length < 2) return [];

  // Parse a single CSV line respecting quoted fields
  function parseLine(line: string): string[] {
    const fields: string[] = [];
    let cur = '', inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') { inQ = !inQ; }
      else if (ch === ',' && !inQ) { fields.push(cur.trim()); cur = ''; }
      else cur += ch;
    }
    fields.push(cur.trim());
    return fields;
  }

  const headers = parseLine(lines[0]).map(h => h.toLowerCase().replace(/\s+/g, '_'));
  return lines.slice(1).filter(l => l.trim()).map(line => {
    const vals = parseLine(line);
    const row: Record<string, string> = {};
    headers.forEach((h, i) => { row[h] = vals[i] ?? ''; });
    return row;
  });
}

export default function ImportClientsModal({
  onClose, onRefresh,
}: { onClose: () => void; onRefresh: () => void }) {
  const fileRef                   = useRef<HTMLInputElement>(null);
  const [rows, setRows]           = useState<Record<string, string>[] | null>(null);
  const [fileName, setFileName]   = useState('');
  const [parseError, setParseError] = useState('');
  const [importing, setImporting] = useState(false);
  const [results, setResults]     = useState<{ imported: number; failed: number; results: { row: number; code: string; status: string; error?: string }[] } | null>(null);

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setParseError('');
    setResults(null);

    const reader = new FileReader();
    reader.onload = ev => {
      const text = ev.target?.result as string;
      const parsed = parseCSV(text);
      if (parsed.length === 0) { setParseError('No data rows found. Check your file has a header row and at least one data row.'); return; }
      if (!parsed[0].hasOwnProperty('code') && !parsed[0].hasOwnProperty('name')) {
        setParseError('Header row not recognised. Make sure you are using the exported template.'); return;
      }
      setRows(parsed);
    };
    reader.readAsText(file);
  }

  async function doImport() {
    if (!rows) return;
    setImporting(true);
    const res  = await fetch('/api/clients/bulk', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ rows }),
    });
    const data = await res.json();
    setImporting(false);
    setResults(data);
    if (data.imported > 0) onRefresh();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[600px] max-h-[85vh] overflow-y-auto shadow-2xl flex flex-col"
        onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 flex-shrink-0">
          <div>
            <div className="font-bold text-sm text-slate-900">Import Clients</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Upload a CSV using the exported template</div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
        </div>

        <div className="p-5 flex flex-col gap-4">

          {/* Results view */}
          {results ? (
            <div className="flex flex-col gap-3">
              <div className="flex gap-3">
                <div className="flex-1 bg-green-50 border border-green-200 rounded-xl px-4 py-3 flex items-center gap-2">
                  <CheckCircle size={16} className="text-green-600 flex-shrink-0" />
                  <div>
                    <div className="font-bold text-sm text-green-700">{results.imported}</div>
                    <div className="text-[10px] text-green-600">Imported successfully</div>
                  </div>
                </div>
                <div className="flex-1 bg-red-50 border border-red-200 rounded-xl px-4 py-3 flex items-center gap-2">
                  <AlertCircle size={16} className="text-red-500 flex-shrink-0" />
                  <div>
                    <div className="font-bold text-sm text-red-600">{results.failed}</div>
                    <div className="text-[10px] text-red-500">Failed</div>
                  </div>
                </div>
              </div>

              {results.failed > 0 && (
                <div className="border border-red-200 rounded-xl overflow-hidden">
                  <div className="px-3 py-2 bg-red-50 text-[10px] font-bold text-red-600 uppercase tracking-wider">Failed rows</div>
                  <div className="divide-y divide-red-100 max-h-48 overflow-y-auto">
                    {results.results.filter(r => r.status === 'error').map(r => (
                      <div key={r.row} className="flex items-start gap-2 px-3 py-2 text-xs">
                        <span className="text-slate-400 flex-shrink-0 w-12">Row {r.row}</span>
                        <span className="font-semibold text-slate-700 flex-shrink-0 w-28 truncate">{r.code || '(no code)'}</span>
                        <span className="text-red-500">{r.error}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-1">
                <button onClick={onClose} className="btn-primary flex-1">Done</button>
                {results.failed > 0 && (
                  <button onClick={() => { setResults(null); setRows(null); setFileName(''); }}
                    className="btn-secondary">Import Again</button>
                )}
              </div>
            </div>

          ) : (
            <>
              {/* Drop / pick zone */}
              <div
                onClick={() => fileRef.current?.click()}
                className="border-2 border-dashed border-slate-200 rounded-xl py-8 flex flex-col items-center gap-2 cursor-pointer hover:border-blue-400 hover:bg-blue-50/30 transition-all">
                <Upload size={22} className="text-slate-400" />
                <div className="text-sm font-semibold text-slate-600">
                  {fileName || 'Click to select a CSV file'}
                </div>
                {fileName && <div className="text-[10px] text-slate-400">Click to change file</div>}
                {!fileName && <div className="text-[10px] text-slate-400">Use the exported template for correct formatting</div>}
              </div>
              <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleFile} />

              {parseError && (
                <div className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{parseError}</div>
              )}

              {/* Preview */}
              {rows && !parseError && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-slate-700">{rows.length} rows detected</span>
                    <span className="text-[10px] text-slate-400">Showing first 5</span>
                  </div>
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <div className="overflow-x-auto max-h-48">
                      <table className="w-full border-collapse text-[10px]">
                        <thead>
                          <tr className="bg-slate-50">
                            {HEADERS.map(h => <th key={h} className="px-2 py-1.5 text-left font-bold text-slate-500 uppercase border-b border-slate-200 whitespace-nowrap">{h}</th>)}
                          </tr>
                        </thead>
                        <tbody>
                          {rows.slice(0, 5).map((r, i) => (
                            <tr key={i} className="border-b border-slate-100 last:border-0">
                              {HEADERS.map(h => (
                                <td key={h} className="px-2 py-1.5 text-slate-700 max-w-[80px] truncate">{r[h] || <span className="text-slate-300">—</span>}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* Note about departments */}
              {rows && (
                <div className="text-[10px] text-slate-400 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                  Departments should be separated by <code className="font-mono bg-slate-200 px-1 rounded">;</code> in the CSV — e.g. <code className="font-mono bg-slate-200 px-1 rounded">GST;Income Tax</code>
                </div>
              )}

              <div className="flex gap-2 pt-1">
                <button onClick={doImport} disabled={!rows || importing}
                  className="btn-primary flex-1">
                  {importing ? `Importing ${rows?.length} clients…` : `Import ${rows?.length ?? 0} Clients`}
                </button>
                <button onClick={onClose} className="btn-secondary">Cancel</button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
