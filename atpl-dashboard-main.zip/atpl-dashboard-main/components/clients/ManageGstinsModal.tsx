'use client';
import { useState } from 'react';
import { X, Plus, Pencil, Check } from 'lucide-react';
import { GSTIN_REG_TYPES, GSTIN_RETURN_FREQS, GSTIN_STATUSES, stateFromGstin, validateGstin } from '@/lib/gstin';
import type { Gstin } from '@/types';

interface Props {
  clientId:   string;
  clientName: string;
  gstins:     Gstin[];
  onClose:    () => void;
  onRefresh:  () => void;
}

const STATUS_STYLE: Record<string, { bg: string; color: string }> = {
  Active:    { bg: '#D1FAE5', color: '#065F46' },
  Cancelled: { bg: '#FEE2E2', color: '#991B1B' },
  Suspended: { bg: '#FEF3C7', color: '#92400E' },
};

function GstinRow({ gstin, clientId, onSaved }: { gstin: Gstin; clientId: string; onSaved: () => void }) {
  const [editing, setEditing]   = useState(false);
  const [form, setForm]         = useState({
    registration_type: gstin.registration_type,
    return_frequency:  gstin.return_frequency,
    gst_status:        gstin.gst_status,
  });
  const [saving, setSaving]     = useState(false);

  async function save() {
    setSaving(true);
    await fetch(`/api/clients/${clientId}`, {
      method:  'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ action: 'update_gstin', gstin_id: gstin.id, ...form }),
    });
    setSaving(false);
    setEditing(false);
    onSaved();
  }

  const s = STATUS_STYLE[gstin.gst_status] ?? STATUS_STYLE.Active;

  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden">
      {/* Header row */}
      <div className="flex items-center gap-3 px-4 py-3 bg-slate-50">
        <div className="font-mono text-sm font-bold text-slate-800 flex-1">{gstin.gstin}</div>
        <span className="text-[10px] text-slate-500">{gstin.state ?? '—'}</span>
        <span className="px-1.5 py-0.5 rounded-full text-[9px] font-bold" style={{ background: s.bg, color: s.color }}>
          {gstin.gst_status}
        </span>
        <button onClick={() => setEditing(e => !e)}
          className={`p-1 rounded transition-colors ${editing ? 'text-blue-600' : 'text-slate-400 hover:text-blue-600'}`}>
          <Pencil size={12} />
        </button>
      </div>

      {/* Detail / edit row */}
      <div className="px-4 py-2.5 grid grid-cols-3 gap-3">
        {editing ? (
          <>
            <div>
              <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">Reg. Type</label>
              <select className="input-base text-xs" value={form.registration_type}
                onChange={e => setForm(f => ({ ...f, registration_type: e.target.value }))}>
                {GSTIN_REG_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">Return Freq.</label>
              <select className="input-base text-xs" value={form.return_frequency}
                onChange={e => setForm(f => ({ ...f, return_frequency: e.target.value }))}>
                {GSTIN_RETURN_FREQS.map(f => <option key={f}>{f}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">GST Status</label>
              <select className="input-base text-xs" value={form.gst_status}
                onChange={e => setForm(f => ({ ...f, gst_status: e.target.value }))}>
                {GSTIN_STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="col-span-3 flex gap-2 pt-1">
              <button onClick={save} disabled={saving}
                className="btn-primary flex items-center gap-1.5 text-xs py-1">
                <Check size={12} /> {saving ? 'Saving…' : 'Save'}
              </button>
              <button onClick={() => setEditing(false)} className="btn-secondary text-xs py-1">Cancel</button>
            </div>
          </>
        ) : (
          <>
            <div>
              <div className="text-[9px] text-slate-400 uppercase font-bold mb-0.5">Reg. Type</div>
              <div className="text-xs text-slate-700">{gstin.registration_type}</div>
            </div>
            <div>
              <div className="text-[9px] text-slate-400 uppercase font-bold mb-0.5">Return Freq.</div>
              <div className="text-xs text-slate-700">{gstin.return_frequency}</div>
            </div>
            <div>
              <div className="text-[9px] text-slate-400 uppercase font-bold mb-0.5">ID</div>
              <div className="text-[10px] font-mono text-slate-500">{gstin.id}</div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default function ManageGstinsModal({ clientId, clientName, gstins: initial, onClose, onRefresh }: Props) {
  const [gstins, setGstins]   = useState<Gstin[]>(initial);
  const [showAdd, setShowAdd] = useState(false);
  const [newRow, setNewRow]   = useState({ gstin: '', state: '', registration_type: 'Regular', return_frequency: 'Monthly', gst_status: 'Active' });
  const [newErr, setNewErr]   = useState('');
  const [saving, setSaving]   = useState(false);

  async function refreshGstins() {
    const res  = await fetch(`/api/clients/${clientId}`);
    const data = await res.json();
    setGstins((data.client?.gstins ?? []) as Gstin[]);
    onRefresh();
  }

  function handleGstinInput(val: string) {
    const upper = val.toUpperCase();
    const state = upper.length >= 2 ? stateFromGstin(upper) : newRow.state;
    const err   = upper.length === 15 ? validateGstin(upper) : '';
    setNewRow(r => ({ ...r, gstin: upper, state }));
    setNewErr(err);
  }

  async function addGstin(e: React.FormEvent) {
    e.preventDefault();
    const err = validateGstin(newRow.gstin);
    if (err) { setNewErr(err); return; }
    setSaving(true);
    const res = await fetch(`/api/clients/${clientId}`, {
      method:  'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ action: 'add_gstin', ...newRow }),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) { setNewErr(data.error ?? 'Failed to add GSTIN'); return; }
    setShowAdd(false);
    setNewRow({ gstin: '', state: '', registration_type: 'Regular', return_frequency: 'Monthly', gst_status: 'Active' });
    setNewErr('');
    refreshGstins();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[560px] max-h-[85vh] overflow-y-auto shadow-2xl"
        onClick={e => e.stopPropagation()}>

        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div>
            <div className="font-bold text-sm text-slate-900">GST Registrations</div>
            <div className="text-[10px] text-slate-400 mt-0.5">{clientName}</div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
        </div>

        <div className="p-5 flex flex-col gap-3">

          {/* Existing GSTINs */}
          {gstins.length === 0 && !showAdd && (
            <div className="text-sm text-slate-400 text-center py-6 border border-dashed border-slate-200 rounded-xl">
              No GSTINs registered for this client yet.
            </div>
          )}
          {gstins.map(g => (
            <GstinRow key={g.id} gstin={g} clientId={clientId} onSaved={refreshGstins} />
          ))}

          {/* Add new GSTIN form */}
          {showAdd && (
            <form onSubmit={addGstin}
              className="border border-blue-200 rounded-xl p-4 bg-blue-50/30 flex flex-col gap-3">
              <div className="font-semibold text-xs text-slate-700">Add New GSTIN</div>

              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">GSTIN *</label>
                  <input type="text" maxLength={15} placeholder="27AAAAA1234A1Z5"
                    className={`input-base font-mono text-xs ${newErr ? 'border-red-300' : ''}`}
                    value={newRow.gstin} onChange={e => handleGstinInput(e.target.value)} />
                  {newErr && <div className="text-[9px] text-red-500 mt-0.5">{newErr}</div>}
                </div>
                <div className="w-44">
                  <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">State (auto)</label>
                  <input type="text" className="input-base text-xs bg-slate-100" readOnly
                    value={newRow.state} placeholder="Auto-filled" />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">Reg. Type</label>
                  <select className="input-base text-xs" value={newRow.registration_type}
                    onChange={e => setNewRow(r => ({ ...r, registration_type: e.target.value }))}>
                    {GSTIN_REG_TYPES.map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">Return Freq.</label>
                  <select className="input-base text-xs" value={newRow.return_frequency}
                    onChange={e => setNewRow(r => ({ ...r, return_frequency: e.target.value }))}>
                    {GSTIN_RETURN_FREQS.map(f => <option key={f}>{f}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[9px] font-bold text-slate-400 uppercase mb-0.5">GST Status</label>
                  <select className="input-base text-xs" value={newRow.gst_status}
                    onChange={e => setNewRow(r => ({ ...r, gst_status: e.target.value }))}>
                    {GSTIN_STATUSES.map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              <div className="flex gap-2">
                <button type="submit" disabled={saving} className="btn-primary text-xs">
                  {saving ? 'Adding…' : 'Add GSTIN'}
                </button>
                <button type="button" onClick={() => { setShowAdd(false); setNewErr(''); }}
                  className="btn-secondary text-xs">Cancel</button>
              </div>
            </form>
          )}

          {!showAdd && (
            <button onClick={() => setShowAdd(true)}
              className="btn-secondary flex items-center justify-center gap-1.5 w-full">
              <Plus size={13} /> Add GSTIN
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
