'use client';
import { useState } from 'react';
import { X } from 'lucide-react';
import { useDepartments } from '@/lib/hooks';
import type { Client } from '@/types';

export default function EditClientModal({
  client, onClose, onRefresh,
}: { client: Client; onClose: () => void; onRefresh: () => void }) {
  const { departments } = useDepartments();
  const [form, setForm] = useState({
    name:         client.name,
    pan:          client.pan          ?? '',
    tan:          client.tan          ?? '',
    cin:          client.cin          ?? '',
    client_group: client.client_group ?? '',
    constitution: client.constitution ?? 'Pvt Ltd',
    status:       client.status       ?? 'Active',
    pan_status:   client.pan_status   ?? 'Confirmed',
    departments:  client.departments  ?? [],
  });
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState('');
  const [success, setSuccess] = useState('');

  function set(key: string, val: string) { setForm(f => ({ ...f, [key]: val })); }

  function toggleDept(d: string) {
    setForm(f => ({
      ...f,
      departments: f.departments.includes(d)
        ? f.departments.filter(x => x !== d)
        : [...f.departments, d],
    }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) { setError('Client name is required'); return; }
    setSaving(true); setError('');
    const res = await fetch(`/api/clients/${client.id}`, {
      method:  'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(form),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) { setError(data.error ?? 'Update failed'); return; }
    setSuccess('Client updated successfully');
    onRefresh();
    setTimeout(onClose, 800);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={onClose}>
      <div className="bg-white rounded-2xl w-[560px] max-h-[90vh] overflow-y-auto shadow-2xl"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div>
            <div className="font-bold text-sm text-slate-900">Edit Client</div>
            <div className="text-[10px] text-slate-400 mt-0.5">{client.code} · {client.id}</div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
        </div>

        <form onSubmit={submit} className="p-5 flex flex-col gap-4">

          {/* Code — read-only */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Client Code <span className="font-normal normal-case text-slate-400">(cannot be changed)</span>
            </label>
            <input type="text" className="input-base bg-slate-100 text-slate-500 cursor-not-allowed"
              value={client.code} readOnly />
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Client Name *',  key: 'name',         placeholder: 'Full legal name' },
              { label: 'PAN',            key: 'pan',          placeholder: 'AAAAA1234A' },
              { label: 'TAN',            key: 'tan',          placeholder: 'AAAA12345A' },
              { label: 'CIN / LLPIN',    key: 'cin',          placeholder: 'U74999MH2010PTC200123' },
              { label: 'Client Group',   key: 'client_group', placeholder: 'e.g. Mehta Group' },
            ].map(f => (
              <div key={f.key} className={f.key === 'name' ? 'col-span-2' : ''}>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">{f.label}</label>
                <input type="text" className="input-base" placeholder={f.placeholder}
                  value={(form as any)[f.key]} onChange={e => set(f.key, e.target.value)} />
              </div>
            ))}
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Constitution</label>
              <select className="input-base" value={form.constitution} onChange={e => set('constitution', e.target.value)}>
                {['Pvt Ltd','LLP','Partnership','Proprietorship','Individual','HUF','Trust','Section 8','Other'].map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Status</label>
              <select className="input-base" value={form.status} onChange={e => set('status', e.target.value)}>
                {['Active','Inactive','On Hold','New (Pre-PAN)'].map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">PAN Status</label>
              <select className="input-base" value={form.pan_status} onChange={e => set('pan_status', e.target.value)}>
                <option>Confirmed</option><option>Awaited</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Departments</label>
            <div className="flex flex-wrap gap-2">
              {departments.map(d => (
                <button type="button" key={d} onClick={() => toggleDept(d)}
                  className="px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all"
                  style={{
                    background:  form.departments.includes(d) ? '#1D4ED8' : '#F8FAFC',
                    color:       form.departments.includes(d) ? '#fff'    : '#64748B',
                    borderColor: form.departments.includes(d) ? '#1D4ED8' : '#E2E8F0',
                  }}>
                  {d}
                </button>
              ))}
            </div>
          </div>

          {error   && <div className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</div>}
          {success && <div className="text-xs text-green-600 bg-green-50 border border-green-200 rounded-lg px-3 py-2">{success}</div>}

          <div className="flex gap-2 pt-1">
            <button type="submit" disabled={saving} className="btn-primary flex-1">
              {saving ? 'Saving…' : 'Save Changes'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
