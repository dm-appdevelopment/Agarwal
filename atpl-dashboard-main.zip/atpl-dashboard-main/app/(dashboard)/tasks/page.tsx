import { getSession } from '@/lib/auth';
import TaskManager from '@/components/tasks/TaskManager';

export default async function TasksPage() {
  const session = await getSession();
  return <TaskManager user={session!} />;
}
