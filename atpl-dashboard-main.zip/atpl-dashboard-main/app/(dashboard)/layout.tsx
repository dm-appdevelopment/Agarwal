import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';
import Sidebar from '@/components/layout/Sidebar';
import TopBar from '@/components/layout/TopBar';
import InactivityGuard from '@/components/InactivityGuard';

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session) redirect('/login');

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar user={session} />
      <div className="flex flex-col flex-1 overflow-hidden bg-slate-100">
        <TopBar user={session} />
        <main className="flex-1 overflow-hidden flex flex-col">
          <InactivityGuard>
            {children}
          </InactivityGuard>
        </main>
      </div>
    </div>
  );
}
