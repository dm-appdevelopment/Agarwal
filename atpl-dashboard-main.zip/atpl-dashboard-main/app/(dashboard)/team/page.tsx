import { getSession } from '@/lib/auth';
import TeamView from '@/components/team/TeamView';

export default async function TeamPage() {
  const session = await getSession();
  return <TeamView user={session!} />;
}
