import { getSession } from '@/lib/auth';
import ClientMaster from '@/components/clients/ClientMaster';

export default async function ClientsPage() {
  const session = await getSession();
  return <ClientMaster user={session!} />;
}
