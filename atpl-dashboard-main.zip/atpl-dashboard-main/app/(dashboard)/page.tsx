import { getSession } from '@/lib/auth';
import HomeContent from '@/components/dashboard/HomeContent';

export default async function DashboardPage() {
  const session = await getSession();
  return <HomeContent user={session!} />;
}
