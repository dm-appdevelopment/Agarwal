import { getSession } from '@/lib/auth';
import SettingsView from '@/components/settings/SettingsView';

export default async function SettingsPage() {
  const session = await getSession();
  return <SettingsView user={session!} />;
}
