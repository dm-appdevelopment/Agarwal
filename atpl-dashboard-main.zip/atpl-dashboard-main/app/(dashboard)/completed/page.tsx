import { getSession } from '@/lib/auth';
import CompletedView from '@/components/completed/CompletedView';

export default async function CompletedPage() {
  const session = await getSession();
  return <CompletedView user={session!} />;
}
