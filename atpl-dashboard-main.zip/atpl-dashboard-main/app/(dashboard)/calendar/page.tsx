import { getSession } from '@/lib/auth';
import CalendarView from '@/components/calendar/CalendarView';

export default async function CalendarPage() {
  const session = await getSession();
  return <CalendarView user={session!} />;
}
