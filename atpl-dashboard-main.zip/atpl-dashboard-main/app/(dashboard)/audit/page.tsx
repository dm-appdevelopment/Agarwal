import { getSession } from '@/lib/auth';
import AuditView from '@/components/audit/AuditView';

export default async function AuditPage() {
  const session = await getSession();
  return <AuditView user={session!} />;
}
