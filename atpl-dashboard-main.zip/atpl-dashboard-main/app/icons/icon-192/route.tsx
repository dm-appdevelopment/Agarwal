import { ImageResponse } from 'next/og';

export const runtime = 'edge';

export function GET() {
  return new ImageResponse(
    (
      <div
        style={{
          width: 192,
          height: 192,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#0A1628',
          borderRadius: 32,
        }}
      >
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 0,
          }}
        >
          <span style={{ color: '#1d4ed8', fontSize: 64, fontWeight: 800, lineHeight: 1, letterSpacing: -2 }}>
            AT
          </span>
          <span style={{ color: '#94a3b8', fontSize: 16, fontWeight: 600, letterSpacing: 3 }}>
            PL
          </span>
        </div>
      </div>
    ),
    { width: 192, height: 192 }
  );
}
