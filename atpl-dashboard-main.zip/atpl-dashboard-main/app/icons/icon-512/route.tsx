import { ImageResponse } from 'next/og';

export const runtime = 'edge';

export function GET() {
  return new ImageResponse(
    (
      <div
        style={{
          width: 512,
          height: 512,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#0A1628',
          borderRadius: 80,
        }}
      >
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 0,
          }}
        >
          <span style={{ color: '#1d4ed8', fontSize: 172, fontWeight: 800, lineHeight: 1, letterSpacing: -6 }}>
            AT
          </span>
          <span style={{ color: '#94a3b8', fontSize: 44, fontWeight: 600, letterSpacing: 10 }}>
            PL
          </span>
        </div>
      </div>
    ),
    { width: 512, height: 512 }
  );
}
