import type { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'ATPL Workflow Dashboard',
    short_name: 'ATPL',
    description: 'Internal practice management system for Agarwal Taxcon',
    start_url: '/',
    display: 'standalone',
    background_color: '#0A1628',
    theme_color: '#1d4ed8',
    orientation: 'portrait',
    categories: ['business', 'productivity'],
    icons: [
      {
        src: '/icons/icon-192',
        sizes: '192x192',
        type: 'image/png',
        purpose: 'maskable',
      },
      {
        src: '/icons/icon-512',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'any',
      },
    ],
  };
}
