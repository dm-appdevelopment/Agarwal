import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

function stateFromGstin(gstin: string): string {
  const STATE_CODES: Record<string, string> = {
    '01':'Jammu & Kashmir',   '02':'Himachal Pradesh',  '03':'Punjab',
    '04':'Chandigarh',        '05':'Uttarakhand',       '06':'Haryana',
    '07':'Delhi',             '08':'Rajasthan',         '09':'Uttar Pradesh',
    '10':'Bihar',             '11':'Sikkim',            '12':'Arunachal Pradesh',
    '13':'Nagaland',          '14':'Manipur',           '15':'Mizoram',
    '16':'Tripura',           '17':'Meghalaya',         '18':'Assam',
    '19':'West Bengal',       '20':'Jharkhand',         '21':'Odisha',
    '22':'Chhattisgarh',      '23':'Madhya Pradesh',    '24':'Gujarat',
    '26':'Dadra & NH / D&D',  '27':'Maharashtra',       '28':'Andhra Pradesh (old)',
    '29':'Karnataka',         '30':'Goa',               '31':'Lakshadweep',
    '32':'Kerala',            '33':'Tamil Nadu',        '34':'Puducherry',
    '35':'Andaman & Nicobar', '36':'Telangana',         '37':'Andhra Pradesh',
    '38':'Ladakh',            '96':'Foreign',           '97':'Other Territory',
    '99':'Centre Jurisdiction',
  };
  return STATE_CODES[gstin.slice(0, 2)] ?? '';
}

function validateGstin(gstin: string): string {
  if (gstin.length !== 15) return 'Must be 15 characters';
  if (!/^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]$/.test(gstin)) return 'Invalid GSTIN format';
  return '';
}

const VALID_REG_TYPES   = ['Regular','Composition','SEZ Developer','SEZ Unit','ISD','Non-Resident','OIDAR','Other'];
const VALID_FREQUENCIES = ['Monthly','Quarterly'];
const VALID_STATUSES    = ['Active','Cancelled','Suspended'];

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || !session.can_onboard_clients) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db   = createServerClient();
  const body = await req.json() as { rows: Record<string, string>[] };
  const rows = body.rows ?? [];

  if (rows.length === 0)   return NextResponse.json({ error: 'No rows provided' }, { status: 400 });
  if (rows.length > 1000) return NextResponse.json({ error: 'Maximum 1000 GSTINs per import' }, { status: 400 });

  // Build client_code → id lookup map
  const { data: allClients } = await db.from('clients').select('id, code');
  const codeToId = Object.fromEntries((allClients ?? []).map((c: any) => [c.code, c.id]));

  // Get max existing GSTIN seq
  const { data: existingGstins } = await db.from('gstins').select('id');
  let maxSeq = (existingGstins ?? []).reduce((max: number, row: any) => {
    const n = parseInt((row.id as string).replace('GST', ''), 10);
    return isNaN(n) ? max : Math.max(max, n);
  }, 0);

  const results: { row: number; gstin: string; status: 'ok' | 'error'; error?: string }[] = [];

  for (let i = 0; i < rows.length; i++) {
    const r      = rows[i];
    const rowNum = i + 1;
    const gstinRaw = (r.gstin ?? '').trim().toUpperCase();

    if (!r.client_code?.trim()) {
      results.push({ row: rowNum, gstin: gstinRaw, status: 'error', error: 'client_code is required' }); continue;
    }
    if (!gstinRaw) {
      results.push({ row: rowNum, gstin: '', status: 'error', error: 'gstin is required' }); continue;
    }

    const clientId = codeToId[r.client_code.trim()];
    if (!clientId) {
      results.push({ row: rowNum, gstin: gstinRaw, status: 'error', error: `Client code "${r.client_code}" not found` }); continue;
    }

    const fmtErr = validateGstin(gstinRaw);
    if (fmtErr) {
      results.push({ row: rowNum, gstin: gstinRaw, status: 'error', error: fmtErr }); continue;
    }

    const registration_type = VALID_REG_TYPES.includes(r.registration_type)   ? r.registration_type   : 'Regular';
    const return_frequency  = VALID_FREQUENCIES.includes(r.return_frequency)  ? r.return_frequency    : 'Monthly';
    const gst_status        = VALID_STATUSES.includes(r.gst_status)           ? r.gst_status          : 'Active';

    maxSeq++;
    const id = `GST${String(maxSeq).padStart(3, '0')}`;

    const { error: insertErr } = await db.from('gstins').insert({
      id, client_id: clientId,
      gstin: gstinRaw,
      state: stateFromGstin(gstinRaw),
      registration_type, return_frequency, gst_status,
    });

    if (insertErr) {
      results.push({ row: rowNum, gstin: gstinRaw, status: 'error', error: insertErr.message });
      maxSeq--;
      continue;
    }

    results.push({ row: rowNum, gstin: gstinRaw, status: 'ok' });
  }

  const imported = results.filter(r => r.status === 'ok').length;
  const failed   = results.filter(r => r.status === 'error').length;

  await writeAuditLog({
    actor: session, actionType: 'Bulk Operation',
    targetEntityType: 'Client', targetEntityId: 'BULK',
    description: `Bulk GSTIN import: ${imported} GSTINs imported, ${failed} failed`,
  });

  return NextResponse.json({ imported, failed, results });
}
