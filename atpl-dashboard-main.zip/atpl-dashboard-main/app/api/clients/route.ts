import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();
  const sp = req.nextUrl.searchParams;
  const search = sp.get('search') ?? '';
  const dept   = sp.get('dept') ?? '';

  let query = db.from('clients').select('*, client_departments(department), gstins(*)').order('name');

  // Employees only see clients they have tasks for
  if (session.role === 'Employee') {
    const { data: myTasks } = await db.from('tasks').select('client_id').eq('assigned_to', session.id);
    const clientIds = [...new Set((myTasks ?? []).map(t => t.client_id))];
    if (clientIds.length === 0) return NextResponse.json({ clients: [] });
    query = query.in('id', clientIds);
  }

  if (search) query = query.or(`name.ilike.%${search}%,code.ilike.%${search}%,pan.ilike.%${search}%`);

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  let clients = (data ?? []).map(c => ({
    ...c,
    departments: (c.client_departments as any[])?.map(d => d.department) ?? [],
  }));

  if (dept) clients = clients.filter(c => c.departments.includes(dept));

  return NextResponse.json({ clients });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });
  if (!session.can_onboard_clients) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  const db   = createServerClient();
  const body = await req.json();

  const { count } = await db.from('clients').select('*', { count: 'exact', head: true });
  const id = `CL${String((count ?? 0) + 1).padStart(3, '0')}`;

  const client = {
    id, code: body.code, name: body.name, pan: body.pan ?? null,
    tan: body.tan ?? null, cin: body.cin ?? null,
    client_group: body.client_group ?? null, constitution: body.constitution ?? 'Pvt Ltd',
    status: body.status ?? 'Active', pan_status: body.pan_status ?? 'Confirmed',
    transition_trigger: 'Not Triggered', created_by: session.id,
  };

  const { error } = await db.from('clients').insert(client);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  // Insert departments
  if (body.departments?.length) {
    await db.from('client_departments').insert(
      body.departments.map((d: string) => ({ client_id: id, department: d }))
    );
  }

  // Insert GSTINs
  if (body.gstins?.length) {
    const { data: existingGstins } = await db.from('gstins').select('id');
    const maxGstinSeq = (existingGstins ?? []).reduce((max: number, row: any) => {
      const n = parseInt((row.id as string).replace('GST', ''), 10);
      return isNaN(n) ? max : Math.max(max, n);
    }, 0);
    await db.from('gstins').insert(
      body.gstins.map((g: any, i: number) => ({
        id:                `GST${String(maxGstinSeq + i + 1).padStart(3, '0')}`,
        client_id:         id,
        gstin:             g.gstin.trim().toUpperCase(),
        state:             g.state ?? null,
        registration_type: g.registration_type ?? 'Regular',
        return_frequency:  g.return_frequency  ?? 'Monthly',
        gst_status:        g.gst_status        ?? 'Active',
      }))
    );
  }

  await writeAuditLog({
    actor: session, actionType: 'Client Onboarded',
    targetEntityType: 'Client', targetEntityId: id,
    description: `Client "${body.name}" (${body.code}) onboarded`,
  });

  return NextResponse.json({ id });
}
