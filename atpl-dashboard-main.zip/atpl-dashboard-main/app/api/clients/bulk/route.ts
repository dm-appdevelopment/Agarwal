import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

const VALID_CONSTITUTIONS = ['Pvt Ltd','LLP','Partnership','Proprietorship','Individual','HUF','Trust','Section 8','Other'];
const VALID_STATUSES      = ['Active','Inactive','On Hold','New (Pre-PAN)'];
const VALID_PAN_STATUSES  = ['Confirmed','Awaited'];

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || !session.can_onboard_clients) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db   = createServerClient();
  const body = await req.json() as { rows: Record<string, string>[] };
  const rows = body.rows ?? [];

  if (rows.length === 0) return NextResponse.json({ error: 'No rows provided' }, { status: 400 });
  if (rows.length > 500) return NextResponse.json({ error: 'Maximum 500 clients per import' }, { status: 400 });

  // Get max existing client ID to avoid primary key conflicts
  const { data: existingClients } = await db.from('clients').select('id');
  let maxSeq = (existingClients ?? []).reduce((max, row) => {
    const n = parseInt((row.id as string).replace('CL', ''), 10);
    return isNaN(n) ? max : Math.max(max, n);
  }, 0);

  const results: { row: number; code: string; status: 'ok' | 'error'; error?: string }[] = [];

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const rowNum = i + 1;

    // Validate required fields
    if (!r.code?.trim())  { results.push({ row: rowNum, code: r.code ?? '', status: 'error', error: 'code is required' }); continue; }
    if (!r.name?.trim())  { results.push({ row: rowNum, code: r.code, status: 'error', error: 'name is required' }); continue; }

    // Normalise optional enums
    const constitution = VALID_CONSTITUTIONS.includes(r.constitution) ? r.constitution : 'Pvt Ltd';
    const status       = VALID_STATUSES.includes(r.status) ? r.status : 'Active';
    const pan_status   = VALID_PAN_STATUSES.includes(r.pan_status) ? r.pan_status : 'Confirmed';

    // Parse departments — semicolon or pipe separated (commas conflict with CSV)
    const departments  = r.departments
      ? r.departments.split(/[;|]/).map(d => d.trim()).filter(Boolean)
      : [];

    maxSeq++;
    const id = `CL${String(maxSeq).padStart(3, '0')}`;

    const { error: insertErr } = await db.from('clients').insert({
      id,
      code:               r.code.trim(),
      name:               r.name.trim(),
      pan:                r.pan?.trim()          || null,
      tan:                r.tan?.trim()          || null,
      cin:                r.cin?.trim()          || null,
      client_group:       r.client_group?.trim() || null,
      constitution,
      status,
      pan_status,
      transition_trigger: 'Not Triggered',
      created_by:         session.id,
    });

    if (insertErr) {
      results.push({ row: rowNum, code: r.code, status: 'error', error: insertErr.message });
      maxSeq--; // roll back seq increment on failure
      continue;
    }

    if (departments.length) {
      await db.from('client_departments').insert(
        departments.map(d => ({ client_id: id, department: d }))
      );
    }

    results.push({ row: rowNum, code: r.code, status: 'ok' });
  }

  const imported = results.filter(r => r.status === 'ok').length;
  const failed   = results.filter(r => r.status === 'error').length;

  await writeAuditLog({
    actor: session, actionType: 'Bulk Operation',
    targetEntityType: 'Client', targetEntityId: 'BULK',
    description: `Bulk import: ${imported} clients imported, ${failed} failed`,
  });

  return NextResponse.json({ imported, failed, results });
}
