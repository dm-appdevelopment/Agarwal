import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();
  const { data, error } = await db.from('clients')
    .select('*, client_departments(department), gstins(*)')
    .eq('id', params.id).single();

  if (error) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  const { data: tasks } = await db.from('tasks')
    .select('*, assigned_emp:employees!tasks_assigned_to_fkey(full_name)')
    .eq('client_id', params.id).order('created_at', { ascending: false });

  return NextResponse.json({
    client: {
      ...data,
      departments: (data.client_departments as any[])?.map(d => d.department) ?? [],
    },
    tasks: tasks ?? [],
  });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session || !['Super Master','Admin'].includes(session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db   = createServerClient();
  const body = await req.json();

  // ── GSTIN: add a new registration ────────────────────────
  if (body.action === 'add_gstin') {
    const { data: existingGstins } = await db.from('gstins').select('id');
    const maxSeq = (existingGstins ?? []).reduce((max: number, row: any) => {
      const n = parseInt((row.id as string).replace('GST', ''), 10);
      return isNaN(n) ? max : Math.max(max, n);
    }, 0);
    const gid = `GST${String(maxSeq + 1).padStart(3, '0')}`;
    const { error } = await db.from('gstins').insert({
      id: gid, client_id: params.id,
      gstin:             body.gstin.trim().toUpperCase(),
      state:             body.state             ?? null,
      registration_type: body.registration_type ?? 'Regular',
      return_frequency:  body.return_frequency  ?? 'Monthly',
      gst_status:        body.gst_status        ?? 'Active',
    });
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    await writeAuditLog({ actor: session, actionType: 'Client Modified', targetEntityType: 'Client', targetEntityId: params.id, description: `GSTIN ${body.gstin} added to client ${params.id}` });
    return NextResponse.json({ id: gid });
  }

  // ── GSTIN: update an existing registration ────────────────
  if (body.action === 'update_gstin') {
    const { gstin_id, ...fields } = body;
    const { error } = await db.from('gstins').update(fields).eq('id', gstin_id).eq('client_id', params.id);
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    await writeAuditLog({ actor: session, actionType: 'Client Modified', targetEntityType: 'Client', targetEntityId: params.id, description: `GSTIN ${gstin_id} updated on client ${params.id}` });
    return NextResponse.json({ ok: true });
  }

  // ── Regular client field update ───────────────────────────
  const { departments, ...fields } = body;
  const { error } = await db.from('clients').update(fields).eq('id', params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  if (departments) {
    await db.from('client_departments').delete().eq('client_id', params.id);
    await db.from('client_departments').insert(
      departments.map((d: string) => ({ client_id: params.id, department: d }))
    );
  }

  await writeAuditLog({
    actor: session, actionType: 'Client Modified',
    targetEntityType: 'Client', targetEntityId: params.id,
    description: `Client ${params.id} updated`,
  });

  return NextResponse.json({ ok: true });
}
