import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';

// Compute the due date for a compliance type in a given calendar month.
// Returns ISO date string or null if the rule doesn't apply to that month.
function computeDueDate(rule: string, year: number, month: number): string | null {
  const pad = (n: number) => String(n).padStart(2, '0');

  // "20th of following month" or "20 of following month"
  const followMatch = rule.match(/^(\d+)(?:st|nd|rd|th)? of following month$/i);
  if (followMatch) {
    const day = Math.min(parseInt(followMatch[1]), 28);
    return `${year}-${pad(month + 1)}-${pad(day)}`;
  }

  // "15th of same month"
  const sameMatch = rule.match(/^(\d+)(?:st|nd|rd|th)? of same month$/i);
  if (sameMatch) {
    const day = Math.min(parseInt(sameMatch[1]), 28);
    return `${year}-${pad(month + 1)}-${pad(day)}`;
  }

  // "31st December of the following financial year"
  const finYearMatch = rule.match(/^(\d+)(?:st|nd|rd|th)? (\w+) of the following financial year$/i);
  if (finYearMatch) {
    const MONTHS = ['january','february','march','april','may','june','july','august','september','october','november','december'];
    const ruleMonth = MONTHS.indexOf(finYearMatch[2].toLowerCase());
    if (ruleMonth !== month) return null;
    const day = Math.min(parseInt(finYearMatch[1]), 31);
    return `${year}-${pad(month + 1)}-${pad(day)}`;
  }

  // "31st July of the assessment year" / "31st July of the year"
  const yearMatch = rule.match(/^(\d+)(?:st|nd|rd|th)? (\w+) of the (?:assessment )?year$/i);
  if (yearMatch) {
    const MONTHS = ['january','february','march','april','may','june','july','august','september','october','november','december'];
    const ruleMonth = MONTHS.indexOf(yearMatch[2].toLowerCase());
    if (ruleMonth !== month) return null;
    const day = Math.min(parseInt(yearMatch[1]), 28);
    return `${year}-${pad(month + 1)}-${pad(day)}`;
  }

  return null;
}

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db    = createServerClient();
  const sp    = req.nextUrl.searchParams;
  const month = sp.get('month'); // YYYY-MM

  // ── Fetch client-specific schedule items (existing) ──────────
  let query = db.from('compliance_schedule').select(`
    *,
    clients(name, code),
    compliance_types(filing_type, filing_category)
  `).order('due_date', { ascending: true });

  if (month) {
    query = query.gte('due_date', `${month}-01`).lte('due_date', `${month}-31`);
  }

  const { data: scheduleData, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const scheduleItems = (scheduleData ?? []).map(c => ({
    ...c,
    client_name:  (c.clients as any)?.name,
    filing_type:  (c.compliance_types as any)?.filing_type,
    dept:         (c.compliance_types as any)?.filing_category,
    item_source:  'schedule',
  }));

  // ── Fetch generic compliance-type deadlines for the month ─────
  const genericItems: any[] = [];
  if (month) {
    const [yearStr, monthStr] = month.split('-');
    const year     = parseInt(yearStr);
    const monthIdx = parseInt(monthStr) - 1; // 0-based

    const { data: compTypes } = await db
      .from('compliance_types')
      .select('id, filing_type, filing_category, frequency, due_date_rule')
      .eq('status', 'Active');

    // Track which compliance_type_ids are already covered by specific schedule items
    const coveredTypeIds = new Set(scheduleItems.map((s: any) => s.compliance_type_id).filter(Boolean));

    for (const ct of compTypes ?? []) {
      if (coveredTypeIds.has(ct.id)) continue;
      const due_date = computeDueDate(ct.due_date_rule ?? '', year, monthIdx);
      if (!due_date) continue;
      genericItems.push({
        id:                 `GENERIC_${ct.id}_${month}`,
        client_name:        '(General Deadline)',
        filing_type:        ct.filing_type,
        dept:               ct.filing_category,
        due_date,
        period:             month,
        status:             'General',
        item_source:        'compliance_type',
        compliance_type_id: ct.id,
      });
    }
  }

  return NextResponse.json({ items: [...scheduleItems, ...genericItems] });
}
