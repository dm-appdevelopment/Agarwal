import { NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ overdue: [], dueToday: [] });

  const db = createServerClient();
  const today = new Date().toISOString().split('T')[0];

  let query = db.from('tasks').select('*, clients(name)').neq('status','T3');

  if (session.role === 'Employee') query = query.eq('assigned_to', session.id);
  else if (session.role === 'Team Lead') {
    const { data: tc } = await db.from('team_composition').select('member_id').eq('team_lead_id', session.id).eq('status','Active');
    const ids = [session.id, ...(tc?.map(r=>r.member_id)??[])];
    query = query.in('assigned_to', ids);
  } else if (session.role === 'Admin') {
    query = query.in('dept', session.departments);
  }

  const { data } = await query;
  const tasks = (data ?? []).map(t => ({ ...t, client_name: (t.clients as any)?.name }));

  return NextResponse.json({
    overdue:  tasks.filter(t => t.due && t.due < today),
    dueToday: tasks.filter(t => t.due === today),
  });
}
