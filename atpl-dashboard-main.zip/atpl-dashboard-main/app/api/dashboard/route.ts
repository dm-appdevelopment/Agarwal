import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();
  const today = new Date().toISOString().split('T')[0];

  // Fetch tasks visible to this user
  let query = db.from('tasks').select(`
    *,
    clients(name, code),
    assigned_emp:employees!tasks_assigned_to_fkey(full_name, avatar),
    assigned_by_emp:employees!tasks_assigned_by_fkey(full_name)
  `);

  if (session.role === 'Employee') {
    query = query.eq('assigned_to', session.id);
  } else if (session.role === 'Team Lead') {
    // Fetch team members
    const { data: tc } = await db.from('team_composition')
      .select('member_id').eq('team_lead_id', session.id).eq('status', 'Active');
    const memberIds = [session.id, ...(tc?.map(r => r.member_id) ?? [])];
    query = query.in('assigned_to', memberIds);
  } else if (session.role === 'Admin') {
    query = query.in('dept', session.departments);
  }

  const { data: tasks } = await query;
  const t = tasks ?? [];

  const total     = t.length;
  const pending   = t.filter(x => x.status !== 'T3').length;
  const overdue   = t.filter(x => x.status !== 'T3' && x.due && x.due < today).length;
  const highPrio  = t.filter(x => x.priority === 'High' && x.status !== 'T3').length;
  const doneToday = t.filter(x => x.status === 'T3' && x.t3?.startsWith(today)).length;

  // Dept breakdown
  const depts = ['GST','Income Tax','Audit','TDS','Company Law','NGO','Accounts'];
  const deptStats = depts.map(dept => {
    const dt = t.filter(x => x.dept === dept);
    return { dept, total: dt.length, done: dt.filter(x=>x.status==='T3').length, wip: dt.filter(x=>x.status==='T2').length, pending: dt.filter(x=>x.status==='T0'||x.status==='T1').length };
  }).filter(d => d.total > 0);

  // Upcoming compliance deadlines
  const { data: compliance } = await db.from('compliance_schedule')
    .select('*, clients(name), compliance_types(filing_type, filing_category)')
    .gte('due_date', today)
    .order('due_date', { ascending: true })
    .limit(10);

  // Recent tasks
  const recent = [...t]
    .sort((a,b) => (b.t1||b.created_at||'').localeCompare(a.t1||a.created_at||''))
    .slice(0, 8)
    .map(x => ({
      ...x,
      client_name: (x.clients as any)?.name,
      assigned_to_name: (x.assigned_emp as any)?.full_name,
    }));

  return NextResponse.json({ total, pending, overdue, highPrio, doneToday, deptStats, compliance, recent });
}
