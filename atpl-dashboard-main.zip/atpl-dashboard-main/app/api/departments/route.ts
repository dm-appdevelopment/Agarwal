import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();
  const { data, error } = await db.from('departments').select('*').order('name');
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ departments: data });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== 'Super Master') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db   = createServerClient();
  const body = await req.json();
  const { data: existingDepts } = await db.from('departments').select('id');
  const maxDeptSeq = (existingDepts ?? []).reduce((max, row) => {
    const n = parseInt((row.id as string).replace('DEPT', ''), 10);
    return isNaN(n) ? max : Math.max(max, n);
  }, 0);
  const id = `DEPT${String(maxDeptSeq + 1).padStart(3, '0')}`;

  const { error } = await db.from('departments').insert({
    id,
    name:       body.name,
    color_bg:   body.color_bg   ?? '#F1F5F9',
    color_text: body.color_text ?? '#64748B',
    status:     'Active',
  });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await writeAuditLog({
    actor: session, actionType: 'Configuration Change',
    targetEntityType: 'Department', targetEntityId: id,
    description: `Added department: ${body.name}`,
  });
  return NextResponse.json({ id });
}

export async function PATCH(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== 'Super Master') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db = createServerClient();
  const { id, ...fields } = await req.json();
  const { error } = await db.from('departments').update(fields).eq('id', id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await writeAuditLog({
    actor: session, actionType: 'Configuration Change',
    targetEntityType: 'Department', targetEntityId: id,
    description: `Updated department ${id}`,
    newValue: JSON.stringify(fields),
  });
  return NextResponse.json({ ok: true });
}
