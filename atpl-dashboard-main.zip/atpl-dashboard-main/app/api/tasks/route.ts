import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();
  const sp = req.nextUrl.searchParams;
  const dept     = sp.get('dept') ?? '';
  const priority = sp.get('priority') ?? '';
  const status   = sp.get('status') ?? '';
  const search   = sp.get('search') ?? '';
  const clientId = sp.get('client_id') ?? '';

  let query = db.from('tasks').select(`
    *,
    clients(name, code),
    assigned_emp:employees!tasks_assigned_to_fkey(full_name, avatar, id),
    assigned_by_emp:employees!tasks_assigned_by_fkey(full_name, role),
    sub_assigned_by_emp:employees!tasks_sub_assigned_by_fkey(full_name),
    task_gstin:gstins(gstin, state, return_frequency)
  `).order('created_at', { ascending: false });

  if (session.role === 'Employee') {
    query = query.eq('assigned_to', session.id);
  } else if (session.role === 'Team Lead') {
    const { data: tc } = await db.from('team_composition')
      .select('member_id').eq('team_lead_id', session.id).eq('status','Active');
    const memberIds    = tc?.map(r => r.member_id) ?? [];
    const assignedIds  = [session.id, ...memberIds];
    // Also include tasks sub-assigned by this TL (cross-lead delegations they need to review)
    query = query.or(`assigned_to.in.(${assignedIds.join(',')}),sub_assigned_by.eq.${session.id}`);
  } else if (session.role === 'Admin') {
    // Show tasks in their departments OR directly assigned to them
    const deptList = session.departments.join(',');
    query = query.or(`dept.in.(${deptList}),assigned_to.eq.${session.id}`);
  }

  const dateFrom = sp.get('date_from') ?? '';
  const dateTo   = sp.get('date_to')   ?? '';

  if (dept)     query = query.eq('dept', dept);
  if (priority) query = query.eq('priority', priority);
  if (status)   query = query.eq('status', status);
  if (clientId) query = query.eq('client_id', clientId);
  if (search)   query = query.or(`type.ilike.%${search}%`);
  if (dateFrom) query = query.gte('t3', `${dateFrom}T00:00:00Z`);
  if (dateTo)   query = query.lte('t3', `${dateTo}T23:59:59Z`);

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const tasks = (data ?? []).map(t => ({
    ...t,
    client_name:      (t.clients as any)?.name,
    client_code:      (t.clients as any)?.code,
    assigned_to_name: (t.assigned_emp as any)?.full_name,
    assigned_to_avatar:(t.assigned_emp as any)?.avatar,
    assigned_by_name:       (t.assigned_by_emp as any)?.full_name,
    assigned_by_role:       (t.assigned_by_emp as any)?.role,
    sub_assigned_by_name:   (t.sub_assigned_by_emp as any)?.full_name,
    gstin_number:              (t.task_gstin as any)?.gstin,
    gstin_state:               (t.task_gstin as any)?.state,
    gstin_return_frequency:    (t.task_gstin as any)?.return_frequency,
  }));

  return NextResponse.json({ tasks });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const body = await req.json();

  // Regular assign: Team Lead+. Self-assign: any role assigning themselves with a chosen supervisor.
  const isSelfAssign = body.self_assign === true && body.assigned_to === session.id;
  const canAssign    = ['Super Master','Admin','Team Lead'].includes(session.role);
  if (!canAssign && !isSelfAssign) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }
  if (isSelfAssign && !body.supervisor_id) {
    return NextResponse.json({ error: 'A supervisor is required for self-assigned tasks' }, { status: 400 });
  }

  const db = createServerClient();
  const { data: existingTasks } = await db.from('tasks').select('id');
  const maxTaskSeq = (existingTasks ?? []).reduce((max, row) => {
    const n = parseInt((row.id as string).replace('TASK', ''), 10);
    return isNaN(n) ? max : Math.max(max, n);
  }, 0);
  const id = `TASK${String(maxTaskSeq + 1).padStart(5, '0')}`;
  const now = new Date().toISOString();

  const task = {
    id,
    client_id:           body.client_id,
    compliance_type_id:  body.compliance_type_id ?? null,
    gstin_id:            body.gstin_id            ?? null,
    dept:                body.dept,
    type:                body.type,
    period:              body.period ?? null,
    assigned_to:         body.assigned_to ?? null,
    // For self-assign, the supervisor becomes assigned_by so they retain T2→T3 approval rights.
    assigned_by:         isSelfAssign ? body.supervisor_id : session.id,
    parent_task_id:      body.parent_task_id ?? null,
    priority:            body.priority ?? 'Medium',
    status:              body.assigned_to ? 'T1' : 'T0',
    t0:                  body.t0 ?? null,
    t1:                  body.assigned_to ? now : null,
    t2:                  null,
    t3:                  null,
    due:                 body.due ?? null,
    pending_from_client: false,
    remarks:             body.remarks ?? '',
    recurring:           body.recurring ?? false,
  };

  const { error } = await db.from('tasks').insert(task);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await writeAuditLog({
    actor: session,
    actionType: 'Task Created',
    targetEntityType: 'Task',
    targetEntityId: id,
    description: `Task "${body.type}" ${isSelfAssign ? 'self-assigned by' : 'assigned to'} ${body.assigned_to ?? 'Unassigned'} for client ${body.client_id}`,
  });

  return NextResponse.json({ task });
}
