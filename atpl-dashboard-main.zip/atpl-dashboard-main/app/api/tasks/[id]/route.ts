import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();
  const { data, error } = await db.from('tasks').select(`
    *,
    clients(name, code),
    assigned_emp:employees!tasks_assigned_to_fkey(full_name, avatar, role),
    assigned_by_emp:employees!tasks_assigned_by_fkey(full_name, role),
    sub_assigned_by_emp:employees!tasks_sub_assigned_by_fkey(full_name),
    task_gstin:gstins(gstin, state, return_frequency),
    subtask_checklist(*)
  `).eq('id', params.id).single();

  if (error) return NextResponse.json({ error: error.message }, { status: 404 });
  return NextResponse.json({ task: data });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db   = createServerClient();
  const body = await req.json();
  const action = body.action as string;

  const { data: existing } = await db.from('tasks').select('*').eq('id', params.id).single();
  if (!existing) return NextResponse.json({ error: 'Task not found' }, { status: 404 });

  const now = new Date().toISOString();
  let update: Record<string, unknown> = {};
  let auditDesc = '';

  switch (action) {
    case 'advance': {
      const next: Record<string, string> = { T0:'T1', T1:'T2', T2:'T3' };
      const newStatus = next[existing.status as string];
      if (!newStatus) return NextResponse.json({ error: 'Already at final status' }, { status: 400 });

      const isReviewer = ['Super Master','Admin','Team Lead'].includes(session.role);

      // T1→T2: only the assigned person can mark work as started/done
      if (existing.status === 'T1' && existing.assigned_to !== session.id) {
        return NextResponse.json({ error: 'Only the assigned employee can advance from T1 to T2' }, { status: 403 });
      }

      // T0→T1: only reviewers can allocate
      if (existing.status === 'T0' && !isReviewer) {
        return NextResponse.json({ error: 'Only Admin/Team Lead/Super Master can allocate tasks' }, { status: 403 });
      }

      // T2→T3 (Approval): only the original assigner or Super Master can approve
      if (existing.status === 'T2') {
        const isOriginalAssigner = existing.assigned_by === session.id;
        if (!isOriginalAssigner && session.role !== 'Super Master') {
          return NextResponse.json({ error: 'Only the original task assigner or Super Master can give final approval (T3)' }, { status: 403 });
        }
        // Two-stage gate: if sub-assigned, TL review must be completed first
        const needsTLReview = existing.sub_assigned_by
          && existing.sub_assigned_by !== existing.assigned_by
          && !existing.tl_reviewed;
        if (needsTLReview && session.role !== 'Super Master') {
          return NextResponse.json({ error: 'TL review pending — the sub-assigning Team Lead must review before final approval' }, { status: 403 });
        }
      }

      update = { status: newStatus };
      if (newStatus === 'T1') update.t1 = now;
      if (newStatus === 'T2') update.t2 = now;
      if (newStatus === 'T3') update.t3 = now;
      auditDesc = `Task ${params.id} advanced to ${newStatus} (${existing.type})`;
      break;
    }
    case 'revert': {
      if (!body.remarks) return NextResponse.json({ error: 'Remarks required for revert' }, { status: 400 });
      const canManage = existing.assigned_by === session.id || session.role === 'Super Master';
      if (!canManage) return NextResponse.json({ error: 'Only the task assigner or Super Master can revert' }, { status: 403 });
      const prev: Record<string, string> = { T2:'T1', T1:'T0' };
      const prevStatus = prev[existing.status as string];
      if (!prevStatus) return NextResponse.json({ error: 'Cannot revert from this status' }, { status: 400 });
      update = {
        status:       prevStatus,
        t3:           null,
        t2:           prevStatus === 'T1' ? null : existing.t2,
        tl_reviewed:  false,
        remarks:      body.remarks,
        revert_count: (existing.revert_count ?? 0) + 1,
      };
      auditDesc = `Task ${params.id} reverted to ${prevStatus} with remark: "${body.remarks}"`;
      break;
    }
    case 'toggle_pending': {
      update = { pending_from_client: !existing.pending_from_client };
      auditDesc = `Task ${params.id} pending_from_client set to ${!existing.pending_from_client}`;
      break;
    }
    case 'transfer': {
      // Assigner, Super Master, Admin can always reassign.
      // A Team Lead who is the current assignee can sub-assign to their team.
      const isAssignedTL = session.role === 'Team Lead' && existing.assigned_to === session.id;
      const canManage    = existing.assigned_by === session.id
        || ['Super Master','Admin'].includes(session.role)
        || isAssignedTL;
      if (!canManage) return NextResponse.json({ error: 'Only the task assigner, Admin, Super Master, or the assigned Team Lead can reassign' }, { status: 403 });

      // Cross-lead tasks cannot be sub-assigned by a Team Lead — Super Master/Admin can override
      if (!['Super Master','Admin'].includes(session.role)) {
        const { data: assigner } = await db.from('employees').select('role').eq('id', existing.assigned_by).single();
        if (assigner?.role === 'Team Lead') {
          return NextResponse.json({ error: 'Cross-lead tasks cannot be further reassigned' }, { status: 403 });
        }
      }

      update = {
        assigned_to:      body.assigned_to,
        sub_assigned_by:  session.id,
        tl_reviewed:      false,
        t1:               now,
      };
      auditDesc = `Task ${params.id} transferred from ${existing.assigned_to} to ${body.assigned_to} by ${session.id}`;
      break;
    }
    case 'undo_t2': {
      // Only the assignee can undo their own T2 advancement — no remarks required
      if (existing.status !== 'T2') {
        return NextResponse.json({ error: 'Task is not at T2' }, { status: 400 });
      }
      if (existing.assigned_to !== session.id && session.role !== 'Super Master') {
        return NextResponse.json({ error: 'Only the assignee can undo their own T2 submission' }, { status: 403 });
      }
      update = { status: 'T1', t2: null, tl_reviewed: false };
      auditDesc = `Task ${params.id} T2 undone by assignee ${session.id}`;
      break;
    }
    case 'tl_review': {
      // Only the sub-assigner can mark as TL reviewed
      if (existing.sub_assigned_by !== session.id && session.role !== 'Super Master') {
        return NextResponse.json({ error: 'Only the sub-assigning Team Lead can mark as reviewed' }, { status: 403 });
      }
      if (existing.status !== 'T2') {
        return NextResponse.json({ error: 'TL review only applies to tasks at T2' }, { status: 400 });
      }
      update = { tl_reviewed: true };
      auditDesc = `Task ${params.id} marked as TL reviewed by ${session.id}`;
      break;
    }
    case 'set_priority': {
      update = { priority: body.priority };
      auditDesc = `Task ${params.id} priority set to ${body.priority}`;
      break;
    }
    default:
      // Generic field update
      update = body.fields ?? {};
      auditDesc = `Task ${params.id} updated`;
  }

  const { error } = await db.from('tasks').update(update).eq('id', params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await writeAuditLog({
    actor: session,
    actionType: action === 'advance' ? 'Task Advanced' : action === 'revert' ? 'Task Reverted' : action === 'transfer' ? 'Task Transferred' : action === 'tl_review' ? 'Task Advanced' : 'Task Advanced',
    targetEntityType: 'Task',
    targetEntityId: params.id,
    description: auditDesc,
    previousValue: JSON.stringify({ status: existing.status }),
    newValue: JSON.stringify(update),
  });

  return NextResponse.json({ ok: true });
}
