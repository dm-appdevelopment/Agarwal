import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { createServerClient } from '@/lib/supabase-server';
import { signToken, cookieName } from '@/lib/auth';
import { writeAuditLog } from '@/lib/audit';
import type { SessionUser } from '@/types';

export async function POST(req: NextRequest) {
  const { username, password } = await req.json();

  if (!username || !password) {
    return NextResponse.json({ error: 'Username and password required' }, { status: 400 });
  }

  const db = createServerClient();

  // Fetch login registry row
  const { data: lr, error: lrErr } = await db
    .from('login_registry')
    .select('*, employees!login_registry_employee_id_fkey(*)')
    .ilike('username', username.trim())
    .single();

  if (lrErr || !lr) {
    console.error('LOGIN DB ERROR:', JSON.stringify(lrErr));
    return NextResponse.json({ error: 'Invalid username or password' }, { status: 401 });
  }

  if (lr.account_status === 'Locked') {
    return NextResponse.json({ error: `Account locked. ${lr.lock_reason || 'Contact administrator.'}` }, { status: 403 });
  }
  if (lr.account_status === 'Suspended') {
    return NextResponse.json({ error: 'Account suspended. Contact administrator.' }, { status: 403 });
  }

  const valid = await bcrypt.compare(password, lr.password_hash);

  if (!valid) {
    // Increment failed attempts
    const attempts = lr.failed_login_attempts + 1;
    const locked = attempts >= 5;
    await db.from('login_registry').update({
      failed_login_attempts: attempts,
      account_status: locked ? 'Locked' : lr.account_status,
      lock_reason: locked ? `Exceeded 5 failed login attempts on ${new Date().toISOString().split('T')[0]}` : lr.lock_reason,
    }).eq('employee_id', lr.employee_id);

    return NextResponse.json({
      error: locked
        ? 'Account locked after 5 failed attempts. Contact administrator.'
        : `Invalid username or password. ${5 - attempts} attempt(s) remaining.`
    }, { status: 401 });
  }

  // Reset failed attempts + update last login
  await db.from('login_registry').update({
    failed_login_attempts: 0,
    last_login_date: new Date().toISOString(),
  }).eq('employee_id', lr.employee_id);

  const emp = (lr as any).employees as any;

  const session: SessionUser = {
    id:                         emp.id,
    username:                   lr.username,
    full_name:                  emp.full_name,
    role:                       lr.role,
    departments:                lr.department_access,
    avatar:                     emp.avatar,
    client_visibility:          lr.client_visibility,
    can_onboard_clients:        lr.can_onboard_clients,
    can_edit_compliance_master: lr.can_edit_compliance_master,
    can_generate_reports:       lr.can_generate_reports,
    can_export_data:            lr.can_export_data,
    dashboard_my_tasks:         lr.dashboard_my_tasks,
    dashboard_my_team:          lr.dashboard_my_team,
    dashboard_dept_overview:    lr.dashboard_dept_overview,
    dashboard_firm_wide:        lr.dashboard_firm_wide,
    force_password_reset:       lr.force_password_reset,
  };

  const token = await signToken(session);

  // Write audit log
  await writeAuditLog({
    actor: session,
    actionType: 'Login',
    description: `User ${lr.username} logged in`,
    ipAddress: req.headers.get('x-forwarded-for') ?? 'unknown',
  });

  const res = NextResponse.json({ ok: true, user: session });
  res.cookies.set(cookieName(), token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 8 * 60 * 60,
    path: '/',
  });
  return res;
}
