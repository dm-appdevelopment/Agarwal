import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session || !['Super Master','Admin'].includes(session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db = createServerClient();
  const sp = req.nextUrl.searchParams;
  const role   = sp.get('role') ?? '';
  const module = sp.get('module') ?? '';
  const search = sp.get('search') ?? '';

  let query = db.from('audit_log').select('*').order('timestamp', { ascending: false }).limit(200);

  if (role)   query = query.eq('actor_role', role);
  if (module) query = query.eq('action_type', module);
  if (search) query = query.or(`action_description.ilike.%${search}%,actor_name.ilike.%${search}%`);

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ logs: data });
}
