import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();
  const { data: users } = await db.from('employees').select('*').order('role').order('full_name');
  const { data: tc }    = await db.from('team_composition').select('*').eq('status','Active');

  // Task counts
  const { data: tasks } = await db.from('tasks').select('assigned_to, status');
  const activeCount  = (uid: string) => (tasks??[]).filter(t=>t.assigned_to===uid&&t.status!=='T3').length;
  const doneCount    = (uid: string) => (tasks??[]).filter(t=>t.assigned_to===uid&&t.status==='T3').length;

  const enriched = (users??[]).map(u => ({
    ...u,
    active_tasks:    activeCount(u.id),
    completed_tasks: doneCount(u.id),
    team_members:    (tc??[]).filter(r=>r.team_lead_id===u.id).map(r=>r.member_id),
    lead_id:         (tc??[]).find(r=>r.member_id===u.id)?.team_lead_id ?? null,
  }));

  return NextResponse.json({ users: enriched });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== 'Super Master') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db   = createServerClient();
  const body = await req.json();

  if (body.action === 'designate_team_lead') {
    // Deactivate old composition
    await db.from('team_composition').update({ status:'Historical', effective_to: new Date().toISOString().split('T')[0] })
      .eq('team_lead_id', body.lead_id).eq('status','Active');

    // Insert new members
    const { count } = await db.from('team_composition').select('*', { count:'exact', head:true });
    let seq = count ?? 0;
    for (const memberId of body.member_ids) {
      const id = `TC${String(++seq).padStart(3,'0')}`;
      await db.from('team_composition').insert({
        id, team_lead_id: body.lead_id, member_id: memberId,
        effective_from: new Date().toISOString().split('T')[0],
        status: 'Active', designated_by: session.id,
      });
    }

    // Update employee scope
    await db.from('employees').update({ team_lead_scope: body.member_ids, is_team_lead: true }).eq('id', body.lead_id);

    await writeAuditLog({
      actor: session, actionType: 'Team Lead Designated',
      targetEntityType: 'Employee', targetEntityId: body.lead_id,
      description: `Team Lead scope for ${body.lead_id} set to [${body.member_ids.join(', ')}]`,
    });
  }

  return NextResponse.json({ ok: true });
}
