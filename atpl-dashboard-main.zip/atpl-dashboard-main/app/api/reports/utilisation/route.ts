import { NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';

export async function GET() {
  const session = await getSession();
  if (!session || !session.can_generate_reports) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db = createServerClient();

  const { data: tasks } = await db.from('tasks').select(`
    *,
    clients(name, code),
    assigned_emp:employees!tasks_assigned_to_fkey(full_name, role),
    assigned_by_emp:employees!tasks_assigned_by_fkey(full_name)
  `).order('created_at', { ascending: false });

  const { data: users } = await db.from('employees').select('*').eq('status','Active');

  // Build per-employee stats
  const stats = (users ?? []).map(u => {
    const myTasks = (tasks ?? []).filter(t => t.assigned_to === u.id);
    const completed = myTasks.filter(t => t.status === 'T3');
    const pending   = myTasks.filter(t => t.status !== 'T3');

    const avgT1toT3 = completed.filter(t => t.t1 && t.t3).reduce((acc, t) => {
      const diff = (new Date(t.t3).getTime() - new Date(t.t1).getTime()) / 86400000;
      return acc + diff;
    }, 0) / (completed.length || 1);

    return {
      employee:        u.full_name,
      role:            u.role,
      dept:            u.departments?.[0] ?? '',
      total_tasks:     myTasks.length,
      completed:       completed.length,
      pending:         pending.length,
      high_priority:   myTasks.filter(t => t.priority === 'High').length,
      pending_client:  myTasks.filter(t => t.pending_from_client).length,
      avg_days_t1_t3:  Math.round(avgT1toT3 * 10) / 10,
    };
  });

  return NextResponse.json({ stats, tasks });
}
