import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });
  if (['Super Master', 'Admin'].includes(session.role)) {
    return NextResponse.json({ error: 'Use the direct onboard endpoint instead' }, { status: 400 });
  }

  const db   = createServerClient();
  const body = await req.json();
  if (!body.code?.trim() || !body.name?.trim()) {
    return NextResponse.json({ error: 'Client code and name are required' }, { status: 400 });
  }

  const { data: existing } = await db.from('client_requests').select('id');
  const maxSeq = (existing ?? []).reduce((max: number, row: any) => {
    const n = parseInt((row.id as string).replace('CREQ', ''), 10);
    return isNaN(n) ? max : Math.max(max, n);
  }, 0);
  const id = `CREQ${String(maxSeq + 1).padStart(3, '0')}`;

  const { error } = await db.from('client_requests').insert({
    id, requested_by: session.id, request_status: 'Pending',
    code: body.code.trim(), name: body.name.trim(),
    pan: body.pan || null, tan: body.tan || null, cin: body.cin || null,
    client_group: body.client_group || null,
    constitution:  body.constitution  ?? 'Pvt Ltd',
    client_status: body.status        ?? 'Active',
    pan_status:    body.pan_status    ?? 'Confirmed',
    departments:   body.departments   ?? [],
  });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await writeAuditLog({
    actor: session, actionType: 'Client Onboarded',
    targetEntityType: 'ClientRequest', targetEntityId: id,
    description: `Client addition request "${body.name}" (${body.code}) submitted`,
  });
  return NextResponse.json({ id });
}
