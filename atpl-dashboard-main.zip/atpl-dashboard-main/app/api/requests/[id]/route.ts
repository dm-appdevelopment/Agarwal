import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session || session.role !== 'Super Master') {
    return NextResponse.json({ error: 'Only Super Master can approve or reject requests' }, { status: 403 });
  }

  const db   = createServerClient();
  const body = await req.json();
  const { action, type, rejection_remarks } = body;
  // type: 'client' | 'compliance'

  const table = type === 'client' ? 'client_requests' : 'compliance_type_requests';
  const { data: request } = await db.from(table).select('*').eq('id', params.id).single();
  if (!request) return NextResponse.json({ error: 'Request not found' }, { status: 404 });

  // ── Reject ────────────────────────────────────────────────
  if (action === 'reject') {
    if (!rejection_remarks?.trim()) {
      return NextResponse.json({ error: 'Rejection remarks are required' }, { status: 400 });
    }
    await db.from(table).update({ request_status: 'Rejected', rejection_remarks: rejection_remarks.trim() }).eq('id', params.id);
    await writeAuditLog({
      actor: session, actionType: type === 'client' ? 'Client Onboarded' : 'Compliance Master Edited',
      targetEntityType: table, targetEntityId: params.id,
      description: `Request ${params.id} rejected: "${rejection_remarks.trim()}"`,
    });
    return NextResponse.json({ ok: true });
  }

  // ── Approve ───────────────────────────────────────────────
  if (action === 'approve') {
    if (type === 'client') {
      const { data: existingClients } = await db.from('clients').select('id');
      const maxSeq = (existingClients ?? []).reduce((max: number, row: any) => {
        const n = parseInt((row.id as string).replace('CL', ''), 10);
        return isNaN(n) ? max : Math.max(max, n);
      }, 0);
      const clientId = `CL${String(maxSeq + 1).padStart(3, '0')}`;

      const { error: clientErr } = await db.from('clients').insert({
        id: clientId, code: request.code, name: request.name,
        pan: request.pan, tan: request.tan, cin: request.cin,
        client_group: request.client_group, constitution: request.constitution,
        status: request.client_status, pan_status: request.pan_status,
        transition_trigger: 'Not Triggered', created_by: session.id,
      });
      if (clientErr) return NextResponse.json({ error: clientErr.message }, { status: 500 });

      const departments: string[] = Array.isArray(request.departments) ? request.departments : [];
      if (departments.length) {
        await db.from('client_departments').insert(
          departments.map((d: string) => ({ client_id: clientId, department: d }))
        );
      }

      await db.from('client_requests').delete().eq('id', params.id);
      await writeAuditLog({
        actor: session, actionType: 'Client Onboarded',
        targetEntityType: 'Client', targetEntityId: clientId,
        description: `Client "${request.name}" (${request.code}) approved from request ${params.id}`,
      });
      return NextResponse.json({ id: clientId });
    }

    if (type === 'compliance') {
      const { data: existingComp } = await db.from('compliance_types').select('id');
      const maxSeq = (existingComp ?? []).reduce((max: number, row: any) => {
        const n = parseInt((row.id as string).replace('COMP', ''), 10);
        return isNaN(n) ? max : Math.max(max, n);
      }, 0);
      const compId = `COMP${String(maxSeq + 1).padStart(3, '0')}`;

      const { error: compErr } = await db.from('compliance_types').insert({
        id: compId, status: 'Active',
        filing_category:     request.filing_category,
        filing_type:         request.filing_type,
        frequency:           request.frequency,
        due_date_rule:       request.due_date_rule,
        applicability_rules: request.applicability_rules,
      });
      if (compErr) return NextResponse.json({ error: compErr.message }, { status: 500 });

      await db.from('compliance_type_requests').delete().eq('id', params.id);
      await writeAuditLog({
        actor: session, actionType: 'Compliance Master Edited',
        targetEntityType: 'ComplianceType', targetEntityId: compId,
        description: `Compliance type "${request.filing_type}" approved from request ${params.id}`,
      });
      return NextResponse.json({ id: compId });
    }
  }

  return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
}
