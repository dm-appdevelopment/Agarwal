import { NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();

  if (session.role === 'Super Master') {
    const [{ data: clientReqs }, { data: compReqs }] = await Promise.all([
      db.from('client_requests')
        .select('*, requester:employees!client_requests_requested_by_fkey(full_name)')
        .eq('request_status', 'Pending')
        .order('requested_at'),
      db.from('compliance_type_requests')
        .select('*, requester:employees!compliance_type_requests_requested_by_fkey(full_name)')
        .eq('request_status', 'Pending')
        .order('requested_at'),
    ]);
    return NextResponse.json({
      client_requests:      (clientReqs ?? []).map((r: any) => ({ ...r, requester_name: r.requester?.full_name })),
      compliance_requests:  (compReqs  ?? []).map((r: any) => ({ ...r, requester_name: r.requester?.full_name })),
    });
  }

  // Other roles: own requests only (pending + rejected so they can see rejection reasons)
  const [{ data: clientReqs }, { data: compReqs }] = await Promise.all([
    db.from('client_requests').select('*')
      .eq('requested_by', session.id).order('requested_at', { ascending: false }),
    db.from('compliance_type_requests').select('*')
      .eq('requested_by', session.id).order('requested_at', { ascending: false }),
  ]);
  return NextResponse.json({
    client_requests:     clientReqs  ?? [],
    compliance_requests: compReqs    ?? [],
  });
}
