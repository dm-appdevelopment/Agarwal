import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });
  if (session.role === 'Super Master') {
    return NextResponse.json({ error: 'Use the direct compliance-types endpoint instead' }, { status: 400 });
  }

  const db   = createServerClient();
  const body = await req.json();
  if (!body.filing_category || !body.filing_type?.trim()) {
    return NextResponse.json({ error: 'Filing category and type are required' }, { status: 400 });
  }

  const { data: existing } = await db.from('compliance_type_requests').select('id');
  const maxSeq = (existing ?? []).reduce((max: number, row: any) => {
    const n = parseInt((row.id as string).replace('CPREQ', ''), 10);
    return isNaN(n) ? max : Math.max(max, n);
  }, 0);
  const id = `CPREQ${String(maxSeq + 1).padStart(3, '0')}`;

  const { error } = await db.from('compliance_type_requests').insert({
    id, requested_by: session.id, request_status: 'Pending',
    filing_category:     body.filing_category,
    filing_type:         body.filing_type.trim(),
    frequency:           body.frequency           ?? 'Monthly',
    due_date_rule:       body.due_date_rule        ?? '',
    applicability_rules: body.applicability_rules  || null,
  });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await writeAuditLog({
    actor: session, actionType: 'Compliance Master Edited',
    targetEntityType: 'ComplianceTypeRequest', targetEntityId: id,
    description: `Compliance type suggestion "${body.filing_type}" (${body.filing_category}) submitted`,
  });
  return NextResponse.json({ id });
}
