import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import { writeAuditLog } from '@/lib/audit';

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();
  const { data, error } = await db.from('compliance_types').select('*').order('filing_category').order('filing_type');
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ types: data });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || !session.can_edit_compliance_master) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db   = createServerClient();
  const body = await req.json();

  // Derive next ID from the highest existing numeric suffix, not row count,
  // so deleted rows don't cause primary-key conflicts.
  const { data: existing } = await db.from('compliance_types').select('id');
  const maxSeq = (existing ?? []).reduce((max, row) => {
    const n = parseInt((row.id as string).replace('COMP', ''), 10);
    return isNaN(n) ? max : Math.max(max, n);
  }, 0);
  const id = `COMP${String(maxSeq + 1).padStart(3, '0')}`;

  const { error } = await db.from('compliance_types').insert({ id, ...body });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await writeAuditLog({
    actor: session, actionType: 'Compliance Master Edited',
    targetEntityType: 'ComplianceType', targetEntityId: id,
    description: `Added compliance type: ${body.filing_type} (${body.filing_category})`,
  });

  return NextResponse.json({ id });
}

export async function PATCH(req: NextRequest) {
  const session = await getSession();
  if (!session || !session.can_edit_compliance_master) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db = createServerClient();
  const { id, ...fields } = await req.json();
  const { error } = await db.from('compliance_types').update(fields).eq('id', id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await writeAuditLog({
    actor: session, actionType: 'Compliance Master Edited',
    targetEntityType: 'ComplianceType', targetEntityId: id,
    description: `Updated compliance type ${id}`,
    newValue: JSON.stringify(fields),
  });

  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest) {
  const session = await getSession();
  if (!session || !session.can_edit_compliance_master) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const { id } = await req.json();
  if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });

  const db = createServerClient();
  const { error } = await db.from('compliance_types').delete().eq('id', id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await writeAuditLog({
    actor: session, actionType: 'Compliance Master Edited',
    targetEntityType: 'ComplianceType', targetEntityId: id,
    description: `Deleted compliance type ${id}`,
  });

  return NextResponse.json({ ok: true });
}
