import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import bcrypt from 'bcryptjs';
import { writeAuditLog } from '@/lib/audit';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session || !['Super Master', 'Admin'].includes(session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db   = createServerClient();
  const body = await req.json();

  // ── Reset password ────────────────────────────────────────
  if (body.action === 'reset_password') {
    const hash = await bcrypt.hash(body.password, 12);
    await db.from('login_registry').update({
      password_hash:          hash,
      password_last_changed:  new Date().toISOString(),
      force_password_reset:   true,
    }).eq('employee_id', params.id);

    await writeAuditLog({ actor: session, actionType: 'Password Reset', targetEntityType: 'Employee', targetEntityId: params.id, description: `Password reset for employee ${params.id}` });
    return NextResponse.json({ ok: true });
  }

  // ── Deactivate / Enable ───────────────────────────────────
  if (body.action === 'deactivate') {
    const { data: emp } = await db.from('employees').select('status').eq('id', params.id).single();
    const isActive = emp?.status === 'Active';

    await db.from('employees').update({ status: isActive ? 'Inactive' : 'Active' }).eq('id', params.id);
    await db.from('login_registry').update({
      account_status: isActive ? 'Suspended' : 'Active',
      lock_reason: isActive ? (body.reason ?? 'Deactivated by administrator') : null,
    }).eq('employee_id', params.id);

    await writeAuditLog({
      actor: session, actionType: 'Profile Modified', targetEntityType: 'Employee', targetEntityId: params.id,
      description: `Employee ${params.id} ${isActive ? 'deactivated' : 'reactivated'}`,
    });
    return NextResponse.json({ ok: true });
  }

  // ── Update profile ────────────────────────────────────────
  if (body.action === 'update_profile') {
    const { full_name, role, departments, status, new_password, team_members } = body;

    // Generate avatar from name
    const avatar = full_name
      ? full_name.split(' ').slice(0, 2).map((w: string) => w[0]).join('').toUpperCase()
      : undefined;

    // Update employees table
    const empUpdate: any = { full_name, departments, status };
    if (role)   empUpdate.role   = role;
    if (avatar) empUpdate.avatar = avatar;
    await db.from('employees').update(empUpdate).eq('id', params.id);

    // Update login_registry
    const lrUpdate: any = { department_access: departments };
    if (role) {
      lrUpdate.role         = role;
      lrUpdate.is_team_lead = role === 'Team Lead';
      lrUpdate.can_onboard_clients        = ['Admin','Super Master'].includes(role);
      lrUpdate.can_edit_compliance_master = role === 'Super Master';
      lrUpdate.can_generate_reports       = ['Admin','Super Master'].includes(role);
      lrUpdate.dashboard_my_team          = role === 'Team Lead';
      lrUpdate.dashboard_dept_overview    = ['Admin','Super Master'].includes(role);
      lrUpdate.dashboard_firm_wide        = role === 'Super Master';
      lrUpdate.client_visibility          = role === 'Employee' ? 'Assigned Clients Only' : role === 'Team Lead' ? 'Team Scope Only' : 'All Clients';
    }
    if (status === 'Inactive') lrUpdate.account_status = 'Suspended';
    if (status === 'Active')   lrUpdate.account_status = 'Active';
    await db.from('login_registry').update(lrUpdate).eq('employee_id', params.id);

    // Update team members if this is (or becomes) a Team Lead
    if (Array.isArray(team_members)) {
      const { data: existing } = await db
        .from('team_composition')
        .select('id, member_id')
        .eq('team_lead_id', params.id)
        .eq('status', 'Active');

      const existingIds: string[] = (existing ?? []).map((r: any) => r.member_id);
      const toRemove = existingIds.filter((id: string) => !team_members.includes(id));
      const toAdd    = team_members.filter((id: string) => !existingIds.includes(id));

      for (const memberId of toRemove) {
        await db.from('team_composition')
          .update({ status: 'Historical', effective_to: new Date().toISOString().split('T')[0] })
          .eq('team_lead_id', params.id).eq('member_id', memberId).eq('status', 'Active');
        await db.from('employees').update({ reporting_to: null }).eq('id', memberId);
      }

      if (toAdd.length > 0) {
        const { count: tcCount } = await db.from('team_composition').select('*', { count: 'exact', head: true });
        const tcRows = toAdd.map((memberId: string, i: number) => ({
          id:             `TC${String((tcCount ?? 0) + i + 1).padStart(3, '0')}`,
          team_lead_id:   params.id,
          member_id:      memberId,
          effective_from: new Date().toISOString().split('T')[0],
          status:         'Active',
          designated_by:  session.id,
        }));
        await db.from('team_composition').insert(tcRows);
        for (const memberId of toAdd) {
          await db.from('employees').update({ reporting_to: params.id }).eq('id', memberId);
        }
      }

      await db.from('employees').update({ team_lead_scope: team_members }).eq('id', params.id);
    }

    // Reset password if provided
    if (new_password) {
      const hash = await bcrypt.hash(new_password, 12);
      await db.from('login_registry').update({
        password_hash:         hash,
        password_last_changed: new Date().toISOString(),
        force_password_reset:  true,
      }).eq('employee_id', params.id);
    }

    await writeAuditLog({
      actor: session, actionType: 'Profile Modified', targetEntityType: 'Employee', targetEntityId: params.id,
      description: `Profile updated for ${full_name} (${params.id})${new_password ? ' including password reset' : ''}`,
    });
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
}
