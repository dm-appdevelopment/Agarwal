import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { createServerClient } from '@/lib/supabase-server';
import bcrypt from 'bcryptjs';
import { writeAuditLog } from '@/lib/audit';

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const db = createServerClient();
  const { data, error } = await db.from('employees').select('*').order('full_name');
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ users: data });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || !['Super Master', 'Admin'].includes(session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const db   = createServerClient();
  const body = await req.json();

  const { data: existingEmps } = await db.from('employees').select('id');
  const maxEmpSeq = (existingEmps ?? []).reduce((max, row) => {
    const n = parseInt((row.id as string).replace('EMP', ''), 10);
    return isNaN(n) ? max : Math.max(max, n);
  }, 0);
  const empId = `EMP${String(maxEmpSeq + 1).padStart(3, '0')}`;
  const initials = body.full_name.split(' ').map((p: string) => p[0]).join('').slice(0,2).toUpperCase();

  const employee = {
    id: empId,
    full_name:     body.full_name,
    username:      body.username.toLowerCase(),
    role:          body.role,
    is_team_lead:  body.role === 'Team Lead',
    team_lead_scope: [],
    departments:   body.departments ?? [],
    avatar:        initials,
    status:        'Active',
  };

  const { error: empErr } = await db.from('employees').insert(employee);
  if (empErr) return NextResponse.json({ error: empErr.message }, { status: 500 });

  // Create login registry
  const hash = await bcrypt.hash(body.password ?? 'Change@123', 12);
  const permissions = getRolePermissions(body.role);

  const { error: lrErr } = await db.from('login_registry').insert({
    employee_id:    empId,
    username:       body.username.toLowerCase(),
    password_hash:  hash,
    force_password_reset: true,
    role:           body.role,
    is_team_lead:   body.role === 'Team Lead',
    department_access: body.departments ?? [],
    access_granted_by: session.id,
    ...permissions,
  });
  if (lrErr) return NextResponse.json({ error: lrErr.message }, { status: 500 });

  // If Team Lead, insert team_composition rows for selected members
  if (body.role === 'Team Lead' && Array.isArray(body.team_members) && body.team_members.length > 0) {
    const { count: tcCount } = await db.from('team_composition').select('*', { count: 'exact', head: true });
    const tcRows = body.team_members.map((memberId: string, i: number) => ({
      id:              `TC${String((tcCount ?? 0) + i + 1).padStart(3, '0')}`,
      team_lead_id:    empId,
      member_id:       memberId,
      effective_from:  new Date().toISOString().split('T')[0],
      status:          'Active',
      designated_by:   session.id,
    }));
    await db.from('team_composition').insert(tcRows);

    // Update team_lead_scope on the new employee record
    await db.from('employees').update({ team_lead_scope: body.team_members }).eq('id', empId);

    // Set reporting_to on each member
    for (const memberId of body.team_members) {
      await db.from('employees').update({ reporting_to: empId }).eq('id', memberId);
    }
  }

  await writeAuditLog({
    actor: session, actionType: 'Profile Created',
    targetEntityType: 'Employee', targetEntityId: empId,
    description: `Created employee profile: ${body.full_name} (${empId}) with role ${body.role}`,
  });

  return NextResponse.json({ id: empId });
}

function getRolePermissions(role: string) {
  return {
    client_visibility:          role === 'Employee' ? 'Assigned Clients Only' : role === 'Team Lead' ? 'Team Scope Only' : 'All Clients',
    dashboard_my_tasks:         true,
    dashboard_my_team:          role === 'Team Lead',
    dashboard_dept_overview:    ['Admin','Super Master'].includes(role),
    dashboard_firm_wide:        role === 'Super Master',
    can_onboard_clients:        ['Admin','Super Master'].includes(role),
    can_edit_compliance_master: role === 'Super Master',
    can_generate_reports:       ['Admin','Super Master'].includes(role),
    can_export_data:            role === 'Super Master',
    account_status:             'Active',
  };
}
