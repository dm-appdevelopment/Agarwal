-- ============================================================
-- Agarwal Taxcon Workflow Dashboard — Supabase Schema
-- Run this entire file in Supabase SQL Editor
-- ============================================================

-- ── Employees (File 1 S8) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS employees (
  id              TEXT PRIMARY KEY,           -- EMP001, EMP002 …
  full_name       TEXT NOT NULL,
  username        TEXT UNIQUE NOT NULL,       -- login handle, lowercase
  role            TEXT NOT NULL CHECK (role IN ('Super Master','Admin','Team Lead','Employee')),
  is_team_lead    BOOLEAN DEFAULT FALSE,
  team_lead_scope TEXT[] DEFAULT '{}',        -- array of employee IDs
  reporting_to    TEXT REFERENCES employees(id),
  departments     TEXT[] DEFAULT '{}',
  personal_email  TEXT,
  phone           TEXT,
  date_of_joining DATE,
  task_capacity   INTEGER DEFAULT 10,
  status          TEXT DEFAULT 'Active' CHECK (status IN ('Active','Inactive','Offboarded')),
  offboarding_date    DATE,
  offboarding_remarks TEXT,
  avatar          TEXT NOT NULL,              -- initials e.g. VA
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Login Registry (File 2 S1) ──────────────────────────────
CREATE TABLE IF NOT EXISTS login_registry (
  employee_id             TEXT PRIMARY KEY REFERENCES employees(id),
  username                TEXT UNIQUE NOT NULL,
  password_hash           TEXT NOT NULL,
  password_last_changed   TIMESTAMPTZ,
  force_password_reset    BOOLEAN DEFAULT TRUE,
  role                    TEXT NOT NULL,
  is_team_lead            BOOLEAN DEFAULT FALSE,
  department_access       TEXT[] DEFAULT '{}',
  client_visibility       TEXT DEFAULT 'Assigned Clients Only',
  dashboard_my_tasks      BOOLEAN DEFAULT TRUE,
  dashboard_my_team       BOOLEAN DEFAULT FALSE,
  dashboard_dept_overview BOOLEAN DEFAULT FALSE,
  dashboard_firm_wide     BOOLEAN DEFAULT FALSE,
  can_onboard_clients     BOOLEAN DEFAULT FALSE,
  can_edit_compliance_master BOOLEAN DEFAULT FALSE,
  can_generate_reports    BOOLEAN DEFAULT FALSE,
  can_export_data         BOOLEAN DEFAULT FALSE,
  account_status          TEXT DEFAULT 'Active' CHECK (account_status IN ('Active','Suspended','Locked')),
  lock_reason             TEXT,
  failed_login_attempts   INTEGER DEFAULT 0,
  last_login_date         TIMESTAMPTZ,
  access_granted_by       TEXT REFERENCES employees(id),
  access_grant_date       TIMESTAMPTZ DEFAULT NOW(),
  notes                   TEXT
);

-- ── Clients (File 1 S1 — CML) ───────────────────────────────
CREATE TABLE IF NOT EXISTS clients (
  id                  TEXT PRIMARY KEY,       -- CL001 …
  code                TEXT UNIQUE NOT NULL,   -- GRP-MEHTA-01
  name                TEXT NOT NULL,
  pan                 TEXT,
  tan                 TEXT,
  cin                 TEXT,
  client_group        TEXT,
  constitution        TEXT DEFAULT 'Pvt Ltd',
  status              TEXT DEFAULT 'Active' CHECK (status IN ('Active','Inactive','On Hold','New (Pre-PAN)')),
  pan_status          TEXT DEFAULT 'Confirmed' CHECK (pan_status IN ('Confirmed','Awaited')),
  transition_trigger  TEXT DEFAULT 'Not Triggered',
  ao_code             TEXT,
  jurisdiction        TEXT,
  created_by          TEXT REFERENCES employees(id),
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Client → Departments (many-to-many)
CREATE TABLE IF NOT EXISTS client_departments (
  client_id   TEXT REFERENCES clients(id) ON DELETE CASCADE,
  department  TEXT NOT NULL,
  PRIMARY KEY (client_id, department)
);

-- ── GSTINs (File 1 S2) ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS gstins (
  id                  TEXT PRIMARY KEY,       -- GST001 …
  client_id           TEXT REFERENCES clients(id) ON DELETE CASCADE,
  gstin               TEXT NOT NULL,
  state               TEXT,
  registration_type   TEXT DEFAULT 'Regular',
  return_frequency    TEXT DEFAULT 'Monthly',
  gst_status          TEXT DEFAULT 'Active',
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ── Compliance Types (File 1 S3) ─────────────────────────────
CREATE TABLE IF NOT EXISTS compliance_types (
  id                  TEXT PRIMARY KEY,       -- COMP001 …
  filing_category     TEXT NOT NULL,
  filing_type         TEXT NOT NULL,
  frequency           TEXT NOT NULL,
  due_date_rule       TEXT NOT NULL,
  applicability_rules TEXT,
  status              TEXT DEFAULT 'Active' CHECK (status IN ('Active','Deactivated')),
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ── Team Composition (File 2 S2) ────────────────────────────
CREATE TABLE IF NOT EXISTS team_composition (
  id              TEXT PRIMARY KEY,           -- TC001 …
  team_lead_id    TEXT REFERENCES employees(id),
  member_id       TEXT REFERENCES employees(id),
  effective_from  DATE NOT NULL,
  effective_to    DATE,
  status          TEXT DEFAULT 'Active' CHECK (status IN ('Active','Historical')),
  designated_by   TEXT REFERENCES employees(id),
  designation_date DATE DEFAULT CURRENT_DATE
);

-- ── Tasks (File 1 S5) ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS tasks (
  id                  TEXT PRIMARY KEY,       -- TASK00001 …
  client_id           TEXT REFERENCES clients(id),
  compliance_type_id  TEXT REFERENCES compliance_types(id),
  dept                TEXT NOT NULL,
  type                TEXT NOT NULL,
  period              TEXT,
  assigned_to         TEXT REFERENCES employees(id),
  assigned_by         TEXT REFERENCES employees(id),
  parent_task_id      TEXT REFERENCES tasks(id),
  priority            TEXT DEFAULT 'Medium' CHECK (priority IN ('High','Medium','Low')),
  status              TEXT DEFAULT 'T0' CHECK (status IN ('T0','T1','T2','T3')),
  t0                  DATE,
  t1                  TIMESTAMPTZ,
  t2                  TIMESTAMPTZ,
  t3                  TIMESTAMPTZ,
  due                 DATE,
  pending_from_client BOOLEAN DEFAULT FALSE,
  remarks             TEXT DEFAULT '',
  revert_count        INTEGER DEFAULT 0,
  recurring           BOOLEAN DEFAULT FALSE,
  recurring_prompt_status TEXT DEFAULT 'Not Prompted',
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ── Sub-Task Checklist (File 1 S6) ──────────────────────────
CREATE TABLE IF NOT EXISTS subtask_checklist (
  id          TEXT PRIMARY KEY,               -- CHK00001 …
  task_id     TEXT REFERENCES tasks(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  status      TEXT DEFAULT 'Pending' CHECK (status IN ('Pending','In Progress','Done')),
  assigned_to TEXT REFERENCES employees(id),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Notice & Litigation Tracker (File 1 S7) ─────────────────
CREATE TABLE IF NOT EXISTS notices (
  id              TEXT PRIMARY KEY,           -- NOT00001 …
  client_id       TEXT REFERENCES clients(id),
  dept            TEXT,
  notice_type     TEXT,
  notice_date     DATE,
  due_date        DATE,
  status          TEXT DEFAULT 'Received',
  assigned_to     TEXT REFERENCES employees(id),
  drive_link      TEXT,
  remarks         TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Compliance Schedule (File 1 S4) ─────────────────────────
CREATE TABLE IF NOT EXISTS compliance_schedule (
  id                      TEXT PRIMARY KEY,   -- SCH00001 …
  client_id               TEXT REFERENCES clients(id),
  compliance_type_id      TEXT REFERENCES compliance_types(id),
  gstin_id                TEXT REFERENCES gstins(id),
  period                  TEXT NOT NULL,
  due_date                DATE,
  assigned_employee       TEXT REFERENCES employees(id),
  status                  TEXT DEFAULT 'Unassigned',
  task_id                 TEXT REFERENCES tasks(id),
  recurring_prompt_status TEXT DEFAULT 'Not Prompted',
  created_at              TIMESTAMPTZ DEFAULT NOW()
);

-- ── Audit Log (File 1 S9) ───────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
  id                  TEXT PRIMARY KEY,       -- LOG00001 …
  timestamp           TIMESTAMPTZ DEFAULT NOW(),
  actor_employee_id   TEXT REFERENCES employees(id),
  actor_name          TEXT NOT NULL,
  actor_role          TEXT NOT NULL,
  action_type         TEXT NOT NULL,
  target_entity_type  TEXT,
  target_entity_id    TEXT,
  action_description  TEXT NOT NULL,
  previous_value      TEXT,
  new_value           TEXT,
  ip_address          TEXT,
  session_id          TEXT
);

-- ============================================================
-- Row Level Security
-- Disable for now — app enforces RBAC via JWT + API routes
-- ============================================================
ALTER TABLE employees          DISABLE ROW LEVEL SECURITY;
ALTER TABLE login_registry     DISABLE ROW LEVEL SECURITY;
ALTER TABLE clients            DISABLE ROW LEVEL SECURITY;
ALTER TABLE client_departments DISABLE ROW LEVEL SECURITY;
ALTER TABLE gstins             DISABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_types   DISABLE ROW LEVEL SECURITY;
ALTER TABLE team_composition   DISABLE ROW LEVEL SECURITY;
ALTER TABLE tasks              DISABLE ROW LEVEL SECURITY;
ALTER TABLE subtask_checklist  DISABLE ROW LEVEL SECURITY;
ALTER TABLE notices            DISABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_schedule DISABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log          DISABLE ROW LEVEL SECURITY;

-- ============================================================
-- Indexes for common queries
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_tasks_assigned_to     ON tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_tasks_client_id       ON tasks(client_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status          ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_due             ON tasks(due);
CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp   ON audit_log(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_compliance_schedule_due ON compliance_schedule(due_date);
CREATE INDEX IF NOT EXISTS idx_team_composition_lead ON team_composition(team_lead_id, status);
